/**
 * @file customer/Edit.js
 * @author wangjunjun
 */

import React, { PureComponent, PropTypes } from 'react';
import { routerRedux, withRouter } from 'dva/router';
import { connect } from 'react-redux';
import { autobind } from 'core-decorators';
import preventDefaultAction from '../../components/common/preventDefaultAction';
import EditIput from '../../components/common/EditInput';

const mapStateToProps = () => ({
});

const mapDispatchToProps = {
  goBack: routerRedux.goBack,
  push: routerRedux.push,
};

@connect(mapStateToProps, mapDispatchToProps)
@withRouter
@preventDefaultAction()
export default class EditInputPage extends PureComponent {

  static propTypes = {
    location: PropTypes.object.isRequired,
    goBack: PropTypes.func.isRequired,
    push: PropTypes.func.isRequired,
  }

  static defaultProps = {
  }

  @autobind
  rightClick(value) {
    const {
      location: { query: { opObj, option }, state: { onSave } },
    } = this.props;
    if (option === 'add') {
      onSave({
        name: opObj,
        value,
      });
    } else {
      onSave(value);
    }
  }

  render() {
    return (
      <div>
        <EditIput
          rightClick={this.rightClick}
          {...this.props}
        />
      </div>
    );
  }
}
