/**
 * @file product/Detail.js
 *  产品详情-私募
 * @author xuxiaoqin
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'react-redux';
import { autobind } from 'core-decorators';
import { routerRedux } from 'dva/router';
import _ from 'lodash';

import withNavBar from '../../components/common/withNavBar';
import PullToRefreshable from '../../components/common/PullToRefreshable';
import DetailHeader from '../../components/product/DetailHeader';
import DetailContent from '../../components/product/DetailContent';

const getDataFunction = (query, loading = true) => ({
  type: 'product/fetchProductDetail',
  payload: query || {},
  loading,
});

const mapStateToProps = state => ({
  detailInfo: state.product.detailInfo,
  isLoading: state.loading.models.product,
});

const mapDispatchToProps = {
  // 提供给下拉刷新组件
  refresh: getDataFunction,
  push: routerRedux.push,
  init: getDataFunction,
  // 上传刷新页面log
  reportRefresh: query => ({
    type: 'global/refreshPage',
    payload: query,
  }),
};

const mergeProps = (stateProps, dispatchProps, ownProps) => {
  const { location: { query } } = ownProps;
  return {
    refreshData: query,
    ...stateProps,
    ...dispatchProps,
    ...ownProps,
  };
};

// const EMPTY_OBJECT = {};
// const EMPTY_LIST = [];

@connect(mapStateToProps, mapDispatchToProps, mergeProps)
@withNavBar({ title: '产品详情-私募', hasBack: true })
@PullToRefreshable
export default class ProductDetail extends PureComponent {
  static propTypes = {
    detailInfo: PropTypes.object.isRequired,
    refresh: PropTypes.func.isRequired,
    refreshData: PropTypes.object.isRequired,
    push: PropTypes.func,
    location: PropTypes.object.isRequired,
    init: PropTypes.func.isRequired,
    reportRefresh: PropTypes.func.isRequired,
    eventEmitter: PropTypes.object.isRequired,
  }

  static defaultProps = {
    push: () => { },
  };

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  componentWillMount() {
    const {
      init,
      refreshData,
      detailInfo,
      location: { query: { productCode, directoryCode } },
      eventEmitter,
       } = this.props;
    if (_.isEmpty(detailInfo[`${productCode}_${directoryCode}`])) {
      init(refreshData);
    }
    eventEmitter.on('reportRefresh', this.handleEventEmitter);
  }

  componentWillUnmount() {
    const { eventEmitter } = this.props;
    eventEmitter.removeListener('reportRefresh', this.handleEventEmitter);
  }

  @autobind
  handleEventEmitter() {
    const { reportRefresh } = this.props;
    reportRefresh({
      actionSource: '产品详情',
    });
  }

  render() {
    const {
      push,
      detailInfo,
      location,
      location:
      { query: { productCode, directoryCode } } } = this.props;
    const detailData = detailInfo[`${productCode}_${directoryCode}`] || {};
    const {
      // 产品名称
      prdtName = '',
      // 产品代码
      prdtCode = '',
      // 产品类型
      categoryName = '',
      // 首次购买金额
      firistParticipation = '',
      // 风险等级
      riskLevel = '',
      // 净值
      unitNav = 0.1,
      // 净值更新时间
      netDate = '',
      sipInfo = {},
      startSalesDate = '',
      endSalesDate = '',
     } = detailData;
    const detailHeaderData = {
      prdtName,
      prdtCode,
      categoryName,
      firistParticipation,
      riskLevel,
      unitNav,
      netDate,
    };

    return (
      <div className="productDetailSection">
        <DetailHeader
          data={detailHeaderData}
        />
        <DetailContent
          data={{ ...sipInfo, startSalesDate, endSalesDate }}
          push={push}
          location={location}
        />
      </div>
    );
  }
}
