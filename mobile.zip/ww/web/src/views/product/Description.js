/**
 * @file product/Description.js
 *  产品描述
 * @author xuxiaoqin
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'react-redux';
// import { routerRedux } from 'dva/router';
// import _ from 'lodash';

import withNavBar from '../../components/common/withNavBar';
import './description.less';

const mapStateToProps = state => ({
  data: state.product.detailInfo,
  isLoading: state.loading.models.product,
});

const mapDispatchToProps = {
  //   push: routerRedux.push,
};

const EMPTY_OBJECT = {};
// const EMPTY_LIST = [];

@connect(mapStateToProps, mapDispatchToProps)
@withNavBar({ title: '产品详情-私募', hasBack: true, layout: false })
export default class ProductDescription extends PureComponent {
  static propTypes = {
    location: PropTypes.object.isRequired,
    data: PropTypes.object,
  }

  static defaultProps = {
    data: {},
  };

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  render() {
    const { data, location: { query: { productCode, directoryCode, investType } } } = this.props;
    const productDetailData = data[`${productCode}_${directoryCode}`] || EMPTY_OBJECT;
    let { sipInfo = {} } = productDetailData;
    if (sipInfo === null) {
      sipInfo = {};
    }

    const {
      investArea = '',
      investLimit = '',
      investObjective = '',
      investStrategy = '',
     } = sipInfo;

    const investData = {
      investArea,
      investLimit,
      investObjective,
      investStrategy,
    };

    let typeName = '';
    switch (investType) {
      case 'investArea':
        typeName = '投资范围';
        break;
      case 'investLimit':
        typeName = '投资限制';
        break;
      case 'investObjective':
        typeName = '投资目标';
        break;
      case 'investStrategy':
        typeName = '投资策略';
        break;
      default:
        typeName = '- -';
    }
    return (
      <div className="productDescription">
        <div className="productProperty">{typeName}</div>
        <div className="descriptionContent" dangerouslySetInnerHTML={{ __html: investData[investType] || '' }} />
      </div>
    );
  }
}
