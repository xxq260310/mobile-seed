import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'dva';
import { withRouter, routerRedux } from 'dva/router';
import _ from 'lodash';

import Searchable from '../../components/product/Searchable';
import SearchList from '../../components/product/SearchList';

const EMPTY_INFO = { page: {}, list: [] };

const mapStateToProps = state => ({
  searchInfo: state.search.product,
  loading: state.loading.models.search,
  queryInfo: state.search.productQuery,
});

const mapDispatchToProps = {
  doSearch: query => ({
    type: 'search/product',
    payload: query,
  }),
  saveQuery: queryInfo => ({
    type: 'search/saveQuery',
    payload: queryInfo,
  }),
  push: routerRedux.push,
  replace: routerRedux.replace,
  goBack: routerRedux.goBack,
};

@connect(mapStateToProps, mapDispatchToProps)
@withRouter
@Searchable
export default class SearchResult extends PureComponent {

  static propTypes = {
    doSearch: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    searchInfo: PropTypes.object.isRequired,
    queryInfo: PropTypes.object.isRequired,
    saveQuery: PropTypes.func.isRequired,
  };

  constructor(props) {
    super(props);
    this.state = {
      searchInfo: props.searchInfo,
      isLoaded: false,
    };
  }

  componentWillMount() {
    const { location: { query }, queryInfo } = this.props;
    if (!_.isEqual(queryInfo, query)) {
      this.doSearch({ ...query, pageNum: 1 });
    }
  }

  componentWillReceiveProps(nextProps) {
    const { location: { query }, searchInfo } = nextProps;
    const { location: preLocation } = this.props;
    // 如果url上关键词发生变化，则触发新的搜索请求
    if (!_.isEqual(query, preLocation.query)) {
      this.doSearch({ ...query, pageNum: 1 });
    }
    if (searchInfo !== this.props.searchInfo) {
      this.setState({
        searchInfo,
        isLoaded: true,
      });
    }
  }

  doSearch(query) {
    this.setState({
      searchInfo: EMPTY_INFO,
      isLoaded: false,
    });
    const params = { ...query, keywords: decodeURIComponent(query.keywords) };
    this.props.doSearch(params);
  }

  render() {
    return (
      <SearchList
        {...this.props}
        searchInfo={this.state.searchInfo}
        isLoaded={this.state.isLoaded}
        saveQuery={this.props.saveQuery}
      />
    );
  }

}
