/**
 * @file product/DetailWithMenu.js
 *  产品详情下方菜单按钮
 * @author xuxiaoqin
 */
import React, { PropTypes, PureComponent } from 'react';
import { routerRedux } from 'dva/router';
import { connect } from 'react-redux';
// import _ from 'lodash';
import TargetCustomer from '../../components/product/TargetCustomer';
import Detail from './Detail';

const mapStateToProps = () => ({
  // data: state.customer.custBriefContact,
});

const mapDispatchToProps = {
  push: routerRedux.push,
};

@connect(mapStateToProps, mapDispatchToProps)
export default class MenuBarComponent extends PureComponent {
  static propTypes = {
    push: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
  }

  static defaultProps = {
  }

  render() {
    /* eslint-disable */
    const { ...others } = this.props;
    /* eslint-enable */
    // const { dataSource = {} } = this.state;

    return (
      <div>
        <Detail {...others} />
        <TargetCustomer
          push={this.props.push}
          location={this.props.location}
        />
      </div>
    );
  }
}
