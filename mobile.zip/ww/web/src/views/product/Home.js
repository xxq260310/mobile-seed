/**
 * @file product/Home.js
 * @author fwc
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'dva';
import { withRouter, routerRedux } from 'dva/router';
import { autobind } from 'core-decorators';
import { Drawer } from 'antd-mobile';
import _ from 'lodash';
import {
  addBackbuttonListener,
  removeBackbuttonListener,
} from '../../utils/cordova';
import PopMask from '../../components/common/PopMask';
import Searchable from '../../components/product/Searchable';
import ProductList from '../../components/product/List';
import ProductHeader from '../../components/product/ListHeader';
import Filter from '../../components/product/Filter';
import './home.less';

const actionType = 'product/getProList';

const mapStateToProps = state => ({
  list: state.product.list,
  isLoading: state.loading.effects[actionType] || false,
});

const getListFunction = loading => query => ({
  type: actionType,
  payload: query || {},
  loading,
});

const mapDispatchToProps = {
  getList: getListFunction(true),
  // 提供给下拉刷新组件
  refresh: getListFunction(false),
  push: routerRedux.push,
  replace: routerRedux.replace,
  // 产品详情有部分跳到涨乐页面了，所以要人肉记一下日志
  reportDetail: query => ({
    type: 'product/reportDetail',
    payload: query,
  }),
  // 上传刷新页面log
  reportRefresh: query => ({
    type: 'global/refreshPage',
    payload: query,
  }),
  openFilter: query => ({
    type: 'product/openFilter',
    payload: query,
  }),
};

const appContainer = document.querySelector('#app');

@connect(mapStateToProps, mapDispatchToProps)
@withRouter
@Searchable
export default class ProductHome extends PureComponent {
  static propTypes = {
    getList: PropTypes.func.isRequired,
    refresh: PropTypes.func.isRequired,
    reportDetail: PropTypes.func.isRequired,
    list: PropTypes.object,
    location: PropTypes.object.isRequired,
    replace: PropTypes.func.isRequired,
    push: PropTypes.func.isRequired,
    isLoading: PropTypes.bool.isRequired,
    reportRefresh: PropTypes.func.isRequired,
    openFilter: PropTypes.func.isRequired,
  }

  static defaultProps = {
    list: {},
  }

  constructor(props) {
    super(props);

    this.state = {
      open: false,
      position: 'right',
      maskShow: false,
    };
  }

  componentWillMount() {
    const { list: { resultList }, location: { query } } = this.props;
    if (_.isEmpty(resultList)) {
      this.props.getList({
        ...query,
        pageNum: 1,
      });
    }
    appContainer.addEventListener('touchmove', this.handleTouch, false);
  }

  componentDidMount() {
    const popMask = document.querySelector('#select-pop-mask');
    popMask.addEventListener('touchstart', this.handlePopMaskClick, false);
  }

  componentWillReceiveProps(nextProps) {
    const { location: { query } } = nextProps;
    const { location: { query: preQuery } } = this.props;
    // 条件变化
    if (!_.isEqual(query, preQuery)) {
      this.props.getList({
        ...query,
        pageNum: 1,
      });
      // 如果列表滚动了很远，这时候切换列表数据源，
      // scrollTop不会自己恢复,需要手动搞一下
      this.resetScroll();
    }
  }

  componentWillUnmount() {
    const popMask = document.querySelector('#select-pop-mask');
    // 添加的针对Android虚拟Backbutton事件的处理
    removeBackbuttonListener();
    appContainer.removeEventListener('touchmove', this.handleTouch, false);
    popMask.removeEventListener('touchstart', this.handlePopMaskClick, false);
  }

  @autobind
  onOpenChange() {
    const { open } = this.state;
    const { openFilter } = this.props;
    this.setState(
      { open: !open },
      () => {
        if (open) {
          // 此时是指的是需要关闭筛选功能
          // open = true
          removeBackbuttonListener();
        } else {
          openFilter({
            actionSource: '产品列表',
          });
          // 打开抽屉的时候状态open = false
          addBackbuttonListener(this.handleBackbutton);
        }
      },
    );
  }

  @autobind
  handleBackbutton() {
    const { open } = this.state;
    if (open) {
      this.setState({ open: !open });
    }
  }

  @autobind
  handleTouch(event) {
    const { open } = this.state;
    if (open) {
      event.preventDefault();
    }
  }

  resetScroll() {
    if (this.listElem) {
      this.listElem.scrollTo(0);
    }
  }

  // 下拉选项框的蒙层
  @autobind
  popMaskShow(flag) {
    this.setState({
      maskShow: flag,
    });
  }

  // 添加点击PopMask事件
  @autobind
  handlePopMaskClick(event) {
    event.preventDefault();
    this.popMaskShow(false);
  }

  render() {
    const {
      list,
      refresh,
      location,
      replace,
      push,
      reportDetail,
      isLoading,
      reportRefresh,
    } = this.props;
    const { maskShow } = this.state;
    const sidebar = (
      <Filter
        onOpenChange={this.onOpenChange}
        location={location}
        replace={replace}
      />
    );
    const drawerProps = {
      open: this.state.open,
      position: this.state.position,
      onOpenChange: this.onOpenChange,
    };
    const bar = document.querySelector('.am-tab-bar-bar');
    const footerHeight = bar ? bar.offsetHeight : 0;

    return (
      <section className="page-product">
        <PopMask
          height={document.documentElement.clientHeight - footerHeight}
          show={maskShow}
        />
        <ProductHeader
          onOpenChange={this.onOpenChange}
          location={location}
          replace={replace}
          maskShow={maskShow}
          popMaskShow={this.popMaskShow}
        />
        <ProductList
          ref={ref => (this.listElem = ref)}
          list={list}
          getList={refresh}
          reportDetail={reportDetail}
          location={location}
          replace={replace}
          push={push}
          isFetching={isLoading}
          reportRefresh={reportRefresh}
        />
        <Drawer
          className="my-drawer"
          sidebar={sidebar}
          style={{ maxHeight: document.documentElement.clientHeight - footerHeight }}
          dragHandleStyle={{ display: 'none' }}
          touch={false}
          {...drawerProps}
        >
          .
        </Drawer>
      </section>
    );
  }
}
