/**
 * @file product/MoreInfo.js
 *  更多信息
 * @author xuxiaoqin
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'react-redux';
import { routerRedux } from 'dva/router';
// import _ from 'lodash';

import withNavBar from '../../components/common/withNavBar';
import DetailMoreInfo from '../../components/product/DetailMoreInfo';

const mapStateToProps = state => ({
  data: state.product.detailInfo,
  isLoading: state.loading.models.product,
});

const mapDispatchToProps = {
  push: routerRedux.push,
};

// const EMPTY_OBJECT = {};
// const EMPTY_LIST = [];

@connect(mapStateToProps, mapDispatchToProps)
@withNavBar({ title: '更多信息', hasBack: true })
export default class ProductDetailMoreInfo extends PureComponent {
  static propTypes = {
    // data: PropTypes.object.isRequired,
    push: PropTypes.func,
    location: PropTypes.object.isRequired,
    data: PropTypes.object,
  }

  static defaultProps = {
    push: () => { },
    data: {},
  };

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  render() {
    const { push, location, data } = this.props;
    return (
      <DetailMoreInfo
        push={push}
        location={location}
        data={data}
      />
    );
  }
}
