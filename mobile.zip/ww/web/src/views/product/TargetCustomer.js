/**
 * @file product/TargetCustomer.js
 * @author xuxiaoqin
 */

import React, { PureComponent, PropTypes } from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
// import { autobind } from 'core-decorators';
import _ from 'lodash';
import withNavBar from '../../components/common/withNavBar';
import TargetCustList from '../../components/product/TargetList';
import { nativeGoBack } from '../../utils/cordova';

const actionType = 'product/fetchTargetCustomer';

const mapStateToProps = state => ({
  list: state.product.targetCustList,
  empInfoData: state.global.empInfo,
  ignoreCustomerResult: state.product.ignoreCustomerResult,
  isLoading: state.loading.effects[actionType] || false,
});

const getListFunction = loading => query => ({
  type: actionType,
  payload: query || {},
  loading,
});

const mapDispatchToProps = {
  getList: getListFunction(true),
  // 提供给下拉刷新组件
  refresh: getListFunction(false),
  goLastPage: nativeGoBack,
  push: routerRedux.push,
  // 不推荐客户
  ignoreRecommendCustomer: query => ({
    type: 'product/ignoreCustomer',
    payload: query,
  }),
  getServiceList: query => ({
    type: 'customer/getServiceList',
    payload: query,
  }),
  changeSendEmailResult: query => ({
    type: 'product/changeSendEmailResult',
    payload: query,
  }),
  changeIgnoreResult: query => ({
    type: 'product/changeIgnoreResult',
    payload: query,
  }),
  // 上传刷新页面log
  reportRefresh: query => ({
    type: 'global/refreshPage',
    payload: query,
  }),
};

const mergeProps = (stateProps, dispatchProps, ownProps) => {
  const { location: { query } } = ownProps;
  return {
    queryData: query,
    ...stateProps,
    ...dispatchProps,
    ...ownProps,
  };
};

const EMPTY_OBJECT = {};
const EMPTY_LIST = [];

@connect(mapStateToProps, mapDispatchToProps, mergeProps)
@withNavBar({ title: '目标客户', hasBack: true, isHidden: false })
export default class TargetCustomerList extends PureComponent {
  static propTypes = {
    getList: PropTypes.func.isRequired,
    refresh: PropTypes.func.isRequired,
    list: PropTypes.object,
    location: PropTypes.object.isRequired,
    push: PropTypes.func.isRequired,
    ignoreRecommendCustomer: PropTypes.func,
    empInfoData: PropTypes.object.isRequired,
    changeSendEmailResult: PropTypes.func,
    queryData: PropTypes.object,
    getServiceList: PropTypes.func,
    ignoreCustomerResult: PropTypes.object,
    changeIgnoreResult: PropTypes.func,
    isLoading: PropTypes.bool.isRequired,
    reportRefresh: PropTypes.func.isRequired,
  }

  static defaultProps = {
    list: {},
    queryData: {},
    ignoreRecommendCustomer: () => { },
    changeSendEmailResult: () => { },
    getServiceList: () => { },
    ignoreCustomerResult: {},
    changeIgnoreResult: () => { },
  }

  // constructor(props) {
  //   super(props);
  //   this.state = {
  //     dataSource: EMPTY_OBJECT,
  //   };
  // }

  componentWillMount() {
    const { list, location: { query: { directoryCode, productCode } }, getList } = this.props;
    const { resultList = EMPTY_LIST } = list[`${productCode}_${directoryCode}`] || EMPTY_OBJECT;
    if (_.isEmpty(resultList)) {
      getList({
        directoryCode,
        productCode,
        pageNum: 1,
      });
    }
  }

  componentDidMount() {
    const { queryData: { isShowNavBar = 'Y' } } = this.props;
    if (isShowNavBar === 'N') {
      /* eslint-disable */
      const navBarElem = ReactDOM.findDOMNode(document.querySelectorAll('.am-navbar + section')[0]);
      /* eslint-enable */
      navBarElem.style.marginTop = '0px';
    }
  }

  render() {
    const {
      list,
      refresh,
      location,
      push,
      ignoreRecommendCustomer,
      empInfoData,
      changeSendEmailResult,
      ignoreCustomerResult,
      location: { query: { directoryCode, productCode } },
      getServiceList,
      changeIgnoreResult,
      isLoading,
      reportRefresh,
    } = this.props;

    const resultList = list[`${productCode}_${directoryCode}`] || EMPTY_OBJECT;

    // const { dataSource } = this.state;
    // const resultList = dataSource[`${productCode}_${directoryCode}`] || EMPTY_OBJECT;

    return (
      <section className="target-customer">
        <TargetCustList
          ref={ref => (this.listElem = ref)}
          list={resultList}
          getList={refresh}
          ignoreRecommendCustomer={ignoreRecommendCustomer}
          location={location}
          push={push}
          empInfoData={empInfoData}
          changeSendEmailResult={changeSendEmailResult}
          getServiceList={getServiceList}
          ignoreCustomerResult={ignoreCustomerResult}
          changeIgnoreResult={changeIgnoreResult}
          isFetching={isLoading}
          reportRefresh={reportRefresh}
        />
      </section>
    );
  }
}
