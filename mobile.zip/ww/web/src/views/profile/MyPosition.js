/**
 * @file profile/Myposition.js
 * 我的 -> 职位页面
 * @author wangjunjun(junjun.wang@cienet.com.cn)
 */

import React, { PropTypes, PureComponent } from 'react';
import { connect } from 'react-redux';
import { routerRedux } from 'dva/router';
import { List, Radio } from 'antd-mobile';
import _ from 'lodash';

import NavBar from '../../components/common/NavBar';
import './myposition.less';

const mapStateToProps = state => ({
  empInfo: state.global.empInfo,
  empPostnList: state.global.empPostnList,
  priPos: state.global.priPos,
});

const mapDispatchToProps = {
  goBack: routerRedux.goBack,
  setPriPosition: query => ({
    type: 'global/setPriPosition',
    payload: query,
  }),
};

@connect(mapStateToProps, mapDispatchToProps)
export default class Myposition extends PureComponent {
  static propTypes = {
    title: PropTypes.string.isRequired,
    goBack: PropTypes.func.isRequired,
    empInfo: PropTypes.object.isRequired,
    empPostnList: PropTypes.array.isRequired,
    priPos: PropTypes.object.isRequired,
    setPriPosition: PropTypes.func.isRequired,
  }

  static defaultProps = {
    title: '职位',
  }

  componentWillMount() {
    const { priPos: { postnName }, setPriPosition, empPostnList } = this.props;
    if (!postnName) {
      const defaultPosition = _.find(empPostnList, item => item.isPriPostn === 'Y') || empPostnList[0];
      setPriPosition({
        postnName: defaultPosition.postnName,
        postnId: defaultPosition.postnId,
      });
    }
  }

  onChange(postnName, postnId) {
    const { setPriPosition } = this.props;
    setPriPosition({ postnName, postnId });
  }

  render() {
    const { title, goBack, priPos: { postnId }, empPostnList } = this.props;
    const RadioItem = Radio.RadioItem;
    const Brief = List.Item.Brief;

    return (
      <div className="page-myposition">
        <NavBar
          iconName={'iconfontfanhui2'}
          onLeftClick={goBack}
        >
          {title}
        </NavBar>
        <List>
          {
            (empPostnList || []).map(v => (
              <RadioItem
                key={v.postnId}
                checked={v.postnId === postnId}
                onChange={() => this.onChange(v.postnName, v.postnId)}
              >
                {v.postnName}<Brief>{v.orgName}</Brief>
              </RadioItem>
            ))
          }
        </List>
      </div>
    );
  }
}

