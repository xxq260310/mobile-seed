/**
 * @file profile/Mysetup.js
 * 我的 -> 设置页面
 * @author wangjunjun(junjun.wang@cienet.com.cn)
 */

import React, { PropTypes, PureComponent } from 'react';
import { connect } from 'react-redux';
import { autobind } from 'core-decorators';
import { routerRedux } from 'dva/router';
import { List, Switch, Button } from 'antd-mobile';
import { createForm } from 'rc-form';
import _ from 'lodash';

import withNavBar from '../../components/common/withNavBar';
import { getGestureEnable, resetGesture } from '../../utils/cordova';
import helper from '../../utils/helper';
import './mysetup.less';

const mapStateToProps = state => ({
  empInfo: state.global.empInfo,
  priPos: state.global.priPos,
  shakeSwitch: state.global.shakeSwitch,
  gestureState: state.global.gestureSwitch,
  empPostnList: state.global.empPostnList,
});

const mapDispatchToProps = {
  push: routerRedux.push,
  logout: () => ({
    type: 'global/logout',
  }),
  getShakeSwitchState: query => ({
    type: 'global/getShakeSwitchState',
    payload: query,
  }),
  setPriPosition: query => ({
    type: 'global/setPriPosition',
    payload: query,
  }),
};

@connect(mapStateToProps, mapDispatchToProps)
@withNavBar({ title: '设置', hasBack: true })
@createForm()
export default class Mysetup extends PureComponent {
  static propTypes = {
    push: PropTypes.func.isRequired,
    shakeSwitch: PropTypes.bool.isRequired,
    getShakeSwitchState: PropTypes.func.isRequired,
    form: PropTypes.object.isRequired,
    logout: PropTypes.func.isRequired,
    empInfo: PropTypes.object.isRequired,
    priPos: PropTypes.object.isRequired,
    gestureState: PropTypes.bool.isRequired,
    empPostnList: PropTypes.array.isRequired,
  }

  static defaultProps = {
  }

  constructor(props) {
    super(props);
    this.state = {
      hasGesture: false,
      gestureSwitch: false,
    };
  }

  componentWillMount() {
    // 调用native方法，获得gesture 开关的状态
    getGestureEnable(
      (gestureData) => {
        this.setState(gestureData);
      },
    );
  }

  componentWillReceiveProps(nextProps) {
    const { gestureState } = nextProps;
    if (gestureState !== this.props.gestureState) {
      /**
      * this.props.gestureState 改变的时刻是，native设置手势成功。
      * 故gestureState 传入的是true。
      */
      this.setState({
        gestureSwitch: gestureState,
        hasGesture: gestureState,
      });
    }
  }

  @autobind
  onChange() {
    const { getShakeSwitchState, shakeSwitch } = this.props;
    getShakeSwitchState({
      shakeSwitch: !shakeSwitch,
    });
  }

  @autobind
  handGestureClick() {
    const { push } = this.props;
    const { hasGesture, gestureSwitch } = this.state;

    if (hasGesture) {
      push({
        pathname: '/profile/setgesture',
        query: {
          gestureSwitch,
        },
      });
    } else {
      // native方法
      resetGesture({ showLockGuide: true });
    }
  }

  @autobind
  handClick() {
    this.props.logout();
  }

  render() {
    const {
      form: { getFieldProps },
      empPostnList,
      shakeSwitch,
      priPos: { postnName },
      push,
    } = this.props;
    const { gestureSwitch } = this.state;
    const Item = List.Item;
    const defaultPosition = _.find(empPostnList, item => item.isPriPostn === 'Y') || empPostnList[0];
    const priPosiName = postnName || defaultPosition.postnName;
    const gestureState = gestureSwitch ? '已开启' : '未开启';
    return (
      <div className="page-mysetup">
        <List>
          <form>
            <Item
              extra={
                <Switch
                  {...getFieldProps('shakeSwitch', { initialValue: shakeSwitch, valuePropName: 'checked' })}
                  onChange={this.onChange}
                />
              }
            >
              反馈“摇一摇”开关
            </Item>
            <Item
              extra={priPosiName}
              arrow="horizontal"
              onClick={() => { push('/profile/myposition'); }}
            >
              职位
            </Item>
            <Item
              extra={gestureState}
              arrow="horizontal"
              onClick={this.handGestureClick}
            >
              手势密码
            </Item>
            <Item extra={helper.getEnvVars().$app_version} >版本号</Item>
          </form>
        </List>
        <Button className="btn-logout" onClick={this.handClick}>退出当前账号</Button>
      </div>
    );
  }
}

