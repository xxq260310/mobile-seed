/**
 * @file profile/index.js
 * @author maoquan(maoquan@htsc.com)
 */

import React, { PropTypes, PureComponent } from 'react';
import { connect } from 'react-redux';
import { routerRedux } from 'dva/router';
import { autobind } from 'core-decorators';
import { WhiteSpace } from 'antd-mobile';
// import NavBar from '../../components/common/NavBar';
import PullToRefreshable from '../../components/common/PullToRefreshable';
// import withNavBar from '../../components/common/withNavBar';
import CustomerInfo from '../../components/profile/Info';
import ProfileHeader from '../../components/profile/ProfileHeader';
import api from '../../api';

import './home.less';

const getDataFunction = loading => query => ({
  type: 'profile/getMineAchievement',
  payload: query || {},
  loading,
});

const mapStateToProps = state => ({
  token: state.global.token,
  empInfo: state.global.empInfo,
  info: state.profile.achievement,
  tabIndex: state.status.customerTabIndex,
  isLoading: state.loading.models.profile,
  isGetEmpInfo: state.loading.effects['global/getEmpInfo'],
});

const mapDispatchToProps = {
  getToken: query => ({
    type: 'global/getToken',
    payload: query,
  }),
  getInfo: getDataFunction(true),
  refresh: getDataFunction(false),
  changeTabIndex: index => ({
    type: 'status/changeCustomerTabIndex',
    payload: index,
  }),
  // 上传刷新页面log
  reportRefresh: query => ({
    type: 'global/refreshPage',
    payload: query,
  }),
  push: routerRedux.push,
};

@connect(mapStateToProps, mapDispatchToProps)
// @withNavBar({ title: '我的', hasBack: false, layout: false })
@PullToRefreshable
export default class Profile extends PureComponent {

  static propTypes = {
    title: PropTypes.string.isRequired,
    empId: PropTypes.string,
    deviceId: PropTypes.string,
    token: PropTypes.string.isRequired,
    getToken: PropTypes.func.isRequired,
    empInfo: PropTypes.object,
    info: PropTypes.object.isRequired,
    getInfo: PropTypes.func.isRequired,
    refresh: PropTypes.func.isRequired,
    changeTabIndex: PropTypes.func.isRequired,
    tabIndex: PropTypes.number.isRequired,
    push: PropTypes.func.isRequired,
    isGetEmpInfo: PropTypes.bool.isRequired,
    reportRefresh: PropTypes.func.isRequired,
    eventEmitter: PropTypes.object.isRequired,
  }

  static defaultProps = {
    title: '我的',
    empId: '002332',
    deviceId: String(Math.random()),
    empInfo: {},
  }

  componentWillMount() {
    const { getInfo, refresh, info, eventEmitter } = this.props;
    if (!info) {
      getInfo();
    } else {
      refresh();
    }
    eventEmitter.on('reportRefresh', this.handleEventEmitter);
  }

  componentWillUnmount() {
    const { eventEmitter } = this.props;
    eventEmitter.removeListener('reportRefresh', this.handleEventEmitter);
  }

  @autobind
  handleEventEmitter() {
    const { reportRefresh } = this.props;
    reportRefresh({
      actionSource: '我的',
    });
  }

  @autobind
  handleClick() {
    const { empId, deviceId } = this.props;
    this.props.getToken({ empId, deviceId });
  }
  @autobind
  handlePorfileHeaderClick() {
    const { push, isGetEmpInfo } = this.props;
    if (!isGetEmpInfo) {
      push('/profile/mysetup');
    }
  }

  render() {
    const { token, empId, deviceId } = this.props;
    const { info, tabIndex, changeTabIndex } = this.props;
    const { empInfo: { empName, avatar }, isGetEmpInfo } = this.props;

    const authInfo = api.getAuthInfo();
    let authEmpId = authInfo && authInfo.empId;
    if (authEmpId === undefined || authEmpId === null || authEmpId === 'null' || authEmpId === '' || isGetEmpInfo) {
      authEmpId = '--';
    }

    return (
      <div className="page-profile">
        <ProfileHeader
          headerClick={this.handlePorfileHeaderClick}
          avatar={avatar}
          empName={isGetEmpInfo ? '--' : empName}
          empId={authEmpId}
        />
        <WhiteSpace />
        <CustomerInfo
          data={info}
          tabIndex={tabIndex}
          changeTabIndex={changeTabIndex}
        />
        {process.env.NODE_ENV === 'development' ? (
          <div className="profile-brief">
            <p>
              <a onClick={this.handleClick}>先点击这里刷新token，再点击下面链接</a>
            </p>
            {token ? (
              <p>
                <a href={`/?empId=${empId}&deviceId=${deviceId}&token=${token}`}>点击跳转到带token页面</a>
              </p>
            ) : null}
          </div>
        ) : null}
      </div>
    );
  }
}

