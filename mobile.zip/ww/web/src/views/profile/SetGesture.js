import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import { List, Switch } from 'antd-mobile';
import { createForm } from 'rc-form';
import { connect } from 'react-redux';

import withNavBar from '../../components/common/withNavBar';
import { setGestureEnable, resetGesture } from '../../utils/cordova';
import './setgesture.less';

const mapDispatchToProps = {
  // 发起action，埋点用，仅仅调用dispatch方法，即可实现埋点。
  eventTracking: switchState => ({
    type: 'gestureSwitch',
    payload: switchState,
  }),
};

@connect(null, mapDispatchToProps)
@withNavBar({ title: '手势密码设置', hasBack: true })
@createForm()
export default class SetGesture extends PureComponent {
  static propTypes = {
    form: PropTypes.object.isRequired,
    location: PropTypes.object.isRequired,
    eventTracking: PropTypes.func.isRequired,
  }

  static defaultProps = {
  }

  constructor(props) {
    super(props);
    const { location: { query: { gestureSwitch } } } = this.props;
    this.state = {
      gestureSwitch: gestureSwitch === 'true',
    };
  }

  @autobind
  onChange() {
    const { gestureSwitch } = this.state;
    const { eventTracking } = this.props;
    // 调用native方法，传递手势开关状态到native
    setGestureEnable({ gestureSwitch: !gestureSwitch });
    // 埋点action
    eventTracking({ gestureSwitch: !gestureSwitch });
    // 更新手势开关状态，重新渲染
    this.setState({ gestureSwitch: !gestureSwitch });
  }
  @autobind
  handResetGestureClick() {
    resetGesture({ showLockGuide: false });
  }

  render() {
    const {
      form: { getFieldProps },
    } = this.props;
    const { gestureSwitch } = this.state;
    const Item = List.Item;
    return (
      <div className="page-setgesture">
        <List>
          <form>
            <Item
              extra={
                <Switch
                  {...getFieldProps('gestureSwitch', { initialValue: gestureSwitch, valuePropName: 'checked' })}
                  onChange={this.onChange}
                />
              }
            >
              开启手势密码锁定
            </Item>
            {gestureSwitch ?
              <Item
                arrow="horizontal"
                onClick={this.handResetGestureClick}
              >
                重置手势密码
            </Item> : null
            }
          </form>
        </List>
      </div>
    );
  }
}

