/**
 * @file customer/ServiceRecord.js
 *  历史服务记录
 * @author xuxiaoqin
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'react-redux';
import { routerRedux } from 'dva/router';
import _ from 'lodash';
import withNavBar from '../../components/common/withNavBar';
import ServiceList from '../../components/customer/ServiceList';

const actionType = 'customer/getServiceRecordList';

const getDataFunction = loading => query => ({
  type: actionType,
  payload: query || {},
  loading,
});

const mapStateToProps = state => ({
  recordListData: state.customer.recordListData,
  isLoading: state.loading.effects[actionType] || false,
});

const mapDispatchToProps = {
  push: routerRedux.push,
  getServiceRecordList: getDataFunction(true),
  // 上传刷新页面log
  reportRefresh: query => ({
    type: 'global/refreshPage',
    payload: query,
  }),
};

// 空数据
const EMPTY_OBJECT = {};

@connect(mapStateToProps, mapDispatchToProps)
@withNavBar({ title: '历史服务记录', hasBack: true })
export default class ServiceRecord extends PureComponent {
  static propTypes = {
    recordListData: PropTypes.object,
    getServiceRecordList: PropTypes.func.isRequired,
    reportRefresh: PropTypes.func.isRequired,
    push: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    isLoading: PropTypes.bool,
  };

  static defaultProps = {
    isLoading: false,
    recordListData: EMPTY_OBJECT,
  };

  componentDidMount() {
    const {
      getServiceRecordList,
      location: { query: { custNumber } },
      recordListData,
    } = this.props;
    const { recordList = [] } = recordListData[custNumber] || {};
    if (_.isEmpty(recordList)) {
      getServiceRecordList({ custId: custNumber });
    }
  }

  render() {
    const {
      push,
      location,
      isLoading,
      reportRefresh,
      recordListData,
      getServiceRecordList,
      location: { query: { custNumber } },
    } = this.props;
    const { recordList = [], pageNum = 1, hasMore = true } = recordListData[custNumber] || {};

    return (
      <div>
        <ServiceList
          push={push}
          custId={custNumber}
          list={recordList}
          pageNum={pageNum}
          hasMore={hasMore}
          location={location}
          isFetching={isLoading}
          refresh={getServiceRecordList}
          reportRefresh={reportRefresh}
        />
      </div>
    );
  }
}
