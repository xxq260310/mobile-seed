/**
 * @file customer/Detail.js
 *  客户表单，修改客户信息
 * @author xuxiaoqin
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'react-redux';
import { autobind } from 'core-decorators';
import { routerRedux } from 'dva/router';
import _ from 'lodash';

import withNavBar from '../../components/common/withNavBar';
import PullToRefreshable from '../../components/common/PullToRefreshable';
import CustomerDetailHeader from '../../components/customer/DetailHeader';
import RecommendProductList from '../../components/customer/RecommendProductList';
import CustomerDetailFooter from '../../components/customer/DetailFooter';
import TabBar from '../../components/customer/Tab';

const getDataFunction = (query, loading = true) => ({
  type: 'customer/fetchCustDetail',
  payload: query || {},
  loading,
});

const mapStateToProps = state => ({
  data: state.customer.detailInfo,
  isLoading: state.loading.models.customer,
  tabIndex: state.status.customerDetailTabIndex,
  empInfoData: state.global.empInfo,
  custMotCountData: state.customer.custTaskMotCount,
});

const mapDispatchToProps = {
  // 不推荐产品
  ignoreRecommendProduct: query => ({
    type: 'customer/ignoreProduct',
    payload: query,
  }),
  changeCustomerDetailTabIndex: query => ({
    type: 'status/changeCustomerDetailTabIndex',
    payload: query,
  }),
  // 查询待办任务数量
  getCustTaskCount: query => ({
    type: 'customer/getCustMotCount',
    payload: query || {},
  }),
  // 上传刷新页面log
  reportRefresh: query => ({
    type: 'global/refreshPage',
    payload: query,
  }),
  // 提供给下拉刷新组件
  refresh: getDataFunction,
  push: routerRedux.push,
};

const mergeProps = (stateProps, dispatchProps, ownProps) => {
  const { location: { query } } = ownProps;
  return {
    refreshData: query,
    ...stateProps,
    ...dispatchProps,
    ...ownProps,
  };
};

const EMPTY_OBJECT = {};
const EMPTY_LIST = [];

@connect(mapStateToProps, mapDispatchToProps, mergeProps)
@withNavBar({ title: '客户详情', hasBack: true })
@PullToRefreshable
export default class CustomerDetail extends PureComponent {
  static propTypes = {
    data: PropTypes.object.isRequired,
    refresh: PropTypes.func.isRequired,
    refreshData: PropTypes.object.isRequired,
    push: PropTypes.func,
    location: PropTypes.object.isRequired,
    tabIndex: PropTypes.object.isRequired,
    changeCustomerDetailTabIndex: PropTypes.func,
    ignoreRecommendProduct: PropTypes.func,
    empInfoData: PropTypes.object.isRequired,
    getCustTaskCount: PropTypes.func,
    custMotCountData: PropTypes.object.isRequired,
    reportRefresh: PropTypes.func.isRequired,
    eventEmitter: PropTypes.object.isRequired,
  }

  static defaultProps = {
    data: {},
    push: () => { },
    changeCustomerDetailTabIndex: () => { },
    ignoreRecommendProduct: () => { },
    getCustTaskCount: () => { },
  };

  componentWillMount() {
    const {
      refresh,
      refreshData,
      getCustTaskCount,
      data,
      location: { query: { custId, custNumber } },
      eventEmitter,
    } = this.props;

    getCustTaskCount({ custId, custNumber });

    if (_.isEmpty(data[custId])) {
      refresh(refreshData);
    }

    eventEmitter.on('reportRefresh', this.handleEventEmitter);
  }

  componentWillUnmount() {
    const { eventEmitter } = this.props;
    eventEmitter.removeListener('reportRefresh', this.handleEventEmitter);
  }

  @autobind
  handleEventEmitter() {
    const { reportRefresh } = this.props;
    reportRefresh({
      actionSource: '客户详情',
    });
  }

  render() {
    const {
      data,
      push,
      location: { query: { custId, custNumber, custSor, motTaskId } },
      tabIndex,
      changeCustomerDetailTabIndex,
      location,
      ignoreRecommendProduct,
      empInfoData,
      custMotCountData,
    } = this.props;
    const detailTabIndexObject = tabIndex[custId] || EMPTY_OBJECT;
    const { activeKey = 0 } = detailTabIndexObject || EMPTY_OBJECT;
    const custData = data[custId] || EMPTY_OBJECT;
    const {
      custBaseInfo = EMPTY_OBJECT,
      monthlyProfits = EMPTY_LIST,
      custMoneyDistributionDTOList = EMPTY_LIST,
      productVoList = EMPTY_LIST,
    } = custData;

    const { lastCommission = '' } = custBaseInfo || EMPTY_OBJECT;

    const motCountData = custMotCountData[custId] || EMPTY_OBJECT;
    const { motTaskOfCustCount = 0 } = motCountData;

    return (
      <div>
        <CustomerDetailHeader
          data={custBaseInfo}
          custSor={custSor}
          custNumber={custNumber}
          custId={custId}
          push={push}
        />
        <TabBar
          chartData={monthlyProfits}
          assetData={custMoneyDistributionDTOList}
          detailTabIndex={activeKey}
          changeCustomerDetailTabIndex={changeCustomerDetailTabIndex}
          location={location}
        />
        <RecommendProductList
          recommendProductList={productVoList}
          ignoreRecommendProduct={ignoreRecommendProduct}
          location={location}
          push={push}
          empInfoData={empInfoData}
        />
        <CustomerDetailFooter
          lastCommission={lastCommission}
          push={push}
          custSor={custSor}
          custNumber={custNumber}
          custId={custId}
          motTaskId={motTaskId}
          data={custBaseInfo}
          custMotCount={motTaskOfCustCount}
        />
      </div>
    );
  }
}
