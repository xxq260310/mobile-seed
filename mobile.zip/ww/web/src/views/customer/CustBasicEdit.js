/**
 * @file customer/CustBasic.js
 *  客户职位信息编辑
 * @author hongguangqing(1757912135@qq.com)
 */

import React, { PureComponent, PropTypes } from 'react';
import { autobind } from 'core-decorators';
import _ from 'lodash';
import { connect } from 'react-redux';
import { routerRedux } from 'dva/router';
import { NavBar as AMNavBar, List, Radio, Checkbox, Modal, Toast } from 'antd-mobile';
import NavBar from '../../components/common/NavBar';

import './custbasicedit.less';

const RadioItem = Radio.RadioItem;
const CheckboxItem = Checkbox.CheckboxItem;
const alert = Modal.alert;
const EMPTY_OBJECT = {};

// 从state里面获取数据
const mapStateToProps = state => ({
  PROV_ARRAY: state.global.systemConst.PROV,
  CITY_ARRAY: state.global.systemConst.CITY,
  loading: state.loading.global,
});

// 将传送的数据写入props
const mapDispatchToProps = {
  goBack: routerRedux.goBack,
};

const EXCEPT_DATA = ['DF02', 'DF03', 'DF18', 'DF24', 'DF28', 'DF29', 'DF30'];

@connect(mapStateToProps, mapDispatchToProps)
export default class CustBasicEdit extends PureComponent {
  static propTypes = {
    location: PropTypes.object.isRequired,
    push: PropTypes.func,
    goBack: PropTypes.func,
    PROV_ARRAY: PropTypes.object.isRequired,
    CITY_ARRAY: PropTypes.object.isRequired,
    loading: PropTypes.bool.isRequired,
  };

  static defaultProps = {
    push: () => { },
    goBack: () => { },
  };

  constructor(props) {
    super(props);
    const { location: { state: {
      selectValue,
      titleName,
      options = EMPTY_OBJECT,
    } },
      PROV_ARRAY,
      CITY_ARRAY } = this.props;
    const provData = _.toPairsIn(PROV_ARRAY);
    const cityData = _.toPairsIn(CITY_ARRAY);
    // const countryData = _.toPairsIn(COUNTRY_ARRAY);
    // const newCountryData = _.filter(countryData, item => (
    //   item && item[0] !== '111156'
    // ));
    // newCountryData.unshift(['111156', '中国']);
    const currentData = provData;
    let currentProv;
    let currentCity;
    let currentSelect;
    let selectKey;
    if (_.isObject(selectValue)) {
      const { city = '',
        cityCd = '',
        province = '',
        provinceCd = '' } = selectValue || EMPTY_OBJECT;

      currentProv = {
        province,
        provinceCd,
      };
      currentCity = {
        city,
        cityCd,
      };
      currentSelect = {
        currentSelectKey: provinceCd,
        currentSelectValue: province,
      };
    } else if (!_.isEmpty(selectValue) && !_.isEmpty(options)) {
      _.toPairsIn(options).map((index) => {
        if (index[1] === selectValue) {
          selectKey = index[0];
        }
        return true;
      });
    }

    this.state = {
      selectKey,
      selectValue,
      titleName,
      options,
      provData,
      cityData,
      currentData,
      currentProv,
      currentCity,
      currentSelect,
    };
  }

  @autobind
  handleSelectChange(selectValue, selectKey) {
    this.setState({
      selectValue,
      selectKey,
    });
  }

  /**
   * handle by xuxiaoqin
   * 地址展示
   */
  @autobind
  handleDistrictChange(selectKey, selectValue) {
    const { currentCity, currentProv } = this.state;
    // if (selectKey.toString().indexOf('111156') !== -1) {
    //   // 当前数据是国家
    //   // 切换为省、直辖市
    //   this.setState({
    //     currentData: provData,
    //   });
    // } else
    if (selectKey.toString().length === 4) {
      // 省
      const { CITY_ARRAY } = this.props;
      const temp = _.toPairsIn(CITY_ARRAY);
      let currentData = [];
      const cityData = _.filter(temp, i =>
        i[0].indexOf(selectKey) !== -1,
      );


      if (_.includes(EXCEPT_DATA, selectKey)) {
        /**
         * 直辖市、行政区
         */
        currentData = this.state.currentData;
        this.setState({
          currentData,
          currentProv: {
            province: selectValue,
            provinceCd: selectKey,
          },
          currentSelect: {
            currentSelectKey: selectKey,
            currentSelectValue: selectValue,
          },
          selectValue: {
            province: selectValue,
            provinceCd: selectKey,
            cityCd: _.find(cityData, j =>
              j[0].indexOf(selectKey) !== -1,
            )[0],
            city: selectValue,
          },
        });
      } else {
        currentData = cityData;
        this.setState({
          currentData,
          currentProv: {
            province: selectValue,
            provinceCd: selectKey,
          },
          currentSelect: {
            currentSelectKey: currentCity.cityCd
            || selectKey
            || currentProv.provinceCd,
            currentSelectValue: currentCity.city
            || selectValue
            || currentProv.province,
          },
          selectValue: {
            province: selectValue || currentProv.province,
            provinceCd: selectKey || currentProv.provinceCd,
            city: currentCity.city,
            cityCd: currentCity.cityCd,
          },
        });
      }
    } else {
      // 市
      this.setState({
        currentCity: {
          province: selectValue,
          provinceCd: selectKey,
        },
        currentSelect: {
          currentSelectKey: selectKey || currentCity.cityCd,
          currentSelectValue: selectValue || currentCity.city,
        },
        selectValue: {
          province: currentProv.province,
          provinceCd: currentProv.provinceCd,
          city: selectValue || currentCity.city,
          cityCd: selectKey || currentCity.cityCd,
        },
      });
    }
  }

  @autobind
  handleRightSaveButton() {
    if (this.props.loading) {
      return;
    }

    const { location: { state: { onSave }, query: { editType = '' } } } = this.props;
    const { selectKey, selectValue, selectValue: { provinceCd, cityCd } } = this.state;
    if (cityCd && provinceCd && cityCd.indexOf(provinceCd) === -1) {
      Toast.show('请选择城市', 1);
      return;
    }
    onSave({ selectKey, selectValue, editType });
  }

  @autobind
  clickCancleShowAlert() {
    const { goBack, location: { state: { selectValue } } } = this.props;
    if (this.state.selectValue !== selectValue) {
      alert('提示', '确认放弃本次编辑内容?', [
        { text: '否', onPress: () => console.log('cancel'), style: 'default' },
        { text: '是', onPress: () => goBack(), style: 'default' },
      ]);
    } else {
      goBack();
    }
  }

  @autobind
  handleLeftClick() {
    const { goBack } = this.props;
    goBack();
  }

  render() {
    const { location: { query: { seltype, titleName, navStyle, navRightStyle } } } = this.props;
    const { selectValue, options, currentData, currentSelect } = this.state;
    const navRightObj = navRightStyle ? { buttonName: '完成' } : { buttonName: '保存' };
    let selectNode = [];
    const result = _.toPairsIn(options);

    // 渲染头部的右侧保存按钮
    const renderRightButton = obj => (
      <div className="right-button" onClick={this.handleRightSaveButton}>
        {obj.buttonName}
      </div>
    );

    if (_.isObject(selectValue)) {
      // 编辑城市、地址
      selectNode = currentData.map(i =>
        <List key={i[0]}>
          <RadioItem
            defaultChecked={false}
            checked={currentSelect.currentSelectValue === i[1]}
            onChange={() => this.handleDistrictChange(i[0], i[1])}
          >
            {i[1]}
          </RadioItem>
        </List>,
      );
    } else if (seltype === 'selRadio') {
      selectNode = result.map(i =>
        <List key={i[0]}>
          <RadioItem
            defaultChecked={false}
            checked={selectValue === i[1]}
            onChange={() => this.handleSelectChange(i[1], i[0])}
          >
            {i[1]}
          </RadioItem>
        </List>,
      );
    } else if (seltype === 'selCheckbox') {
      selectNode = result.map(i =>
        <List key={i[0]}>
          <CheckboxItem
            onChange={() => this.handleSelectChange(i[1], i[0])}
          >
            {i[1]}
          </CheckboxItem>
        </List>,
      );
    }

    return (
      <section className="custBasicEdit-page">
        {
          navStyle ?
            <NavBar
              iconName={'iconfontfanhui2'}
              onLeftClick={this.handleLeftClick}
              rightContent={renderRightButton({ buttonName: '完成' })}
            >
              {titleName}
            </NavBar>
            :
            <AMNavBar
              leftContent="取消"
              onLeftClick={this.clickCancleShowAlert}
              rightContent={renderRightButton(navRightObj)}
            >
              {titleName}
            </AMNavBar>
        }
        <div id="si-container" className="container container-scrollable">
          <div className="container-content">
            {selectNode}
          </div>
        </div>
      </section>
    );
  }
}

