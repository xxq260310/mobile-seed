/**
 * @file customer/ServiceRecordDetail.js
 *  服务记录详情
 * @author xuxiaoqin
 */

import React, { PureComponent, PropTypes } from 'react';
import { routerRedux } from 'dva/router';
import { connect } from 'react-redux';

import withNavBar from '../../components/common/withNavBar';
import RecordDetail from '../../components/customer/RecordDetail';

const mapStateToProps = state => ({
  recordListData: state.customer.recordListData,
});

const mapDispatchToProps = {
  push: routerRedux.push,
};

@connect(mapStateToProps, mapDispatchToProps)
@withNavBar({ title: '服务记录详情', hasBack: true })
export default class ServiceRecordDetail extends PureComponent {

  static propTypes = {
    location: PropTypes.object.isRequired,
    recordListData: PropTypes.object.isRequired,
    push: PropTypes.func.isRequired,
  };

  render() {
    const {
      push,
      recordListData,
      location: { query: { custId, rowId } },
    } = this.props;
    const { recordList = [] } = recordListData[custId] || {};
    const index = Number.parseInt(rowId.slice(1), 10);
    const data = recordList[index] || {};
    return (
      <section className="recordDetailList">
        <RecordDetail
          data={data}
          push={push}
        />
      </section>
    );
  }
}
