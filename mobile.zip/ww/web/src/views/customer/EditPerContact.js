/**
 * @file customer/EditPerContact.js
 *  编辑个人联系方式电话、邮箱
 * @author xuxiaoqin
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'react-redux';
import { routerRedux } from 'dva/router';
import withNavBar from '../../components/common/withNavBar';
import EditPersonalContact from '../../components/customer/EditPersonalContact';
import { hideKeyboard } from '../../utils/helper';

const mapStateToProps = state => ({
  data: state.customer.contact,
});

const updateContactPer = (query, loading = true) => ({
  type: 'customer/addOrUpdateContactPer',
  payload: query || {},
  loading,
});

const storeSaveDataFunction = (query, loading = false) => ({
  type: 'customer/storeSaveData',
  payload: query || {},
  loading,
});

const updateGoBackLevelFunction = (query, loading = true) => ({
  type: 'customer/updateGoBackLevel',
  payload: query,
  loading,
});

const mapDispatchToProps = {
  push: routerRedux.push,
  addOrUpdateContactPer: updateContactPer,
  go: routerRedux.go,
  goBack: routerRedux.goBack,
  updateGoBackLevel: updateGoBackLevelFunction,
  storeSaveData: storeSaveDataFunction,
};

const mergeProps = (stateProps, dispatchProps, ownProps) => {
  const { location: { query: { type } } } = ownProps;
  let editTitle = '';
  switch (type) {
    case 'tel':
      editTitle = '编辑电话';
      break;
    case 'email':
      editTitle = '编辑邮箱';
      break;
    case 'address':
      editTitle = '编辑地址';
      break;
    case 'qq':
      editTitle = '编辑QQ';
      break;
    case 'wechat':
      editTitle = '编辑微信';
      break;
    default:
      editTitle = '编辑';
      break;
  }
  return {
    title: editTitle,
    ...stateProps,
    ...dispatchProps,
    ...ownProps,
  };
};

// 空数据
const EMPTY_LIST = [];
const EMPTY_OBJECT = {};

@connect(mapStateToProps, mapDispatchToProps, mergeProps)
@withNavBar({ title: '编辑', hasBack: true })
export default class EditPerContact extends PureComponent {
  static propTypes = {
    title: PropTypes.string,
    data: PropTypes.object.isRequired,
    push: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    addOrUpdateContactPer: PropTypes.func.isRequired,
    go: PropTypes.func.isRequired,
    goBack: PropTypes.func.isRequired,
    updateGoBackLevel: PropTypes.func.isRequired,
    goBackCount: PropTypes.number,
    storeSaveData: PropTypes.func.isRequired,
  };

  static defaultProps = {
    title: '',
    goBackCount: 1,
  };

  constructor(props) {
    super(props);

    const { location: { query: { custId, type } }, data = EMPTY_OBJECT } = this.props;
    const { perCustomerContactInfo = EMPTY_OBJECT } = data[custId] || EMPTY_OBJECT;
    const {
      cellPhones = EMPTY_LIST,
      homeTels = EMPTY_LIST,
      otherTels = EMPTY_LIST,
      workTels = EMPTY_LIST,
      emailAddresses = EMPTY_LIST,
      homeAddresses = EMPTY_LIST,
      otherAddresses = EMPTY_LIST,
      workAddresses = EMPTY_LIST,
      qqNumbers = EMPTY_LIST,
      wechatNumbers = EMPTY_LIST,
      idAddress = EMPTY_OBJECT,
    } = perCustomerContactInfo;

    let editData = EMPTY_OBJECT;
    switch (type) {
      case 'tel':
        editData = {
          cellPhones,
          homeTels,
          otherTels,
          workTels,
        };
        break;
      case 'email':
        editData = {
          emailAddresses,
        };
        break;
      case 'address':
        editData = {
          idAddress,
          homeAddresses,
          otherAddresses,
          workAddresses,
        };
        break;
      case 'qq':
        editData = {
          qqNumbers,
        };
        break;
      case 'wechat':
        editData = {
          wechatNumbers,
        };
        break;
      default:
        editData = EMPTY_OBJECT;
        break;
    }

    this.state = {
      contactPerData: editData,
    };
  }

  componentDidMount() {
    document.querySelector('body').addEventListener('touchmove', hideKeyboard, false);
  }

  componentWillReceiveProps(nextProps) {
    const { data: newData } = nextProps;
    const { data: prevData, location: { query: { custId, type } } } = this.props;
    const { perCustomerContactInfo: newPerCustomerContactInfo } = newData[custId] || EMPTY_OBJECT;
    const { perCustomerContactInfo: prevPerCustomerContactInfo } = prevData[custId] || EMPTY_OBJECT;
    if (newPerCustomerContactInfo !== prevPerCustomerContactInfo) {
      const {
        cellPhones = EMPTY_LIST,
        homeTels = EMPTY_LIST,
        otherTels = EMPTY_LIST,
        workTels = EMPTY_LIST,
        emailAddresses = EMPTY_LIST,
        homeAddresses = EMPTY_LIST,
        otherAddresses = EMPTY_LIST,
        workAddresses = EMPTY_LIST,
        qqNumbers = EMPTY_LIST,
        wechatNumbers = EMPTY_LIST,
        idAddress = EMPTY_OBJECT,
    } = newPerCustomerContactInfo;

      let editData = EMPTY_OBJECT;
      switch (type) {
        case 'tel':
          editData = {
            cellPhones,
            homeTels,
            otherTels,
            workTels,
          };
          break;
        case 'email':
          editData = {
            emailAddresses,
          };
          break;
        case 'address':
          editData = {
            idAddress,
            homeAddresses,
            otherAddresses,
            workAddresses,
          };
          break;
        case 'qq':
          editData = {
            qqNumbers,
          };
          break;
        case 'wechat':
          editData = {
            wechatNumbers,
          };
          break;
        default:
          editData = EMPTY_OBJECT;
          break;
      }

      this.setState({
        contactPerData: editData,
      });
    }
  }

  componentWillUnmount() {
    document.querySelector('body').removeEventListener('touchmove', hideKeyboard, false);
  }

  render() {
    const {
      push,
      location,
      location: { query: { custId, type } },
      addOrUpdateContactPer,
      go,
      goBack,
      updateGoBackLevel,
      goBackCount,
      storeSaveData,
    } = this.props;

    const { contactPerData } = this.state;

    return (
      <div>
        <EditPersonalContact
          data={contactPerData}
          custId={custId}
          type={type}
          location={location}
          push={push}
          addOrUpdateContactPer={addOrUpdateContactPer}
          go={go}
          goBack={goBack}
          updateGoBackLevel={updateGoBackLevel}
          goBackCount={goBackCount}
          storeSaveData={storeSaveData}
        />
      </div>
    );
  }
}
