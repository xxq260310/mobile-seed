/**
 * @file customer/CustTaskList.js
 * @author honggaungqing
 * @用户待办任务列表
 */
import React, { PropTypes, PureComponent } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import _ from 'lodash';
import { autobind } from 'core-decorators';
import { prepareDataSource } from '../../utils/listView';

import withNavBar from '../../components/common/withNavBar';
import CustTaskDesc from '../../components/customer/CustTaskDesc';
import TaskListMenu from '../../components/customer/TaskListMenu';

const EMPTY_OBJECT = {};
const EMPTY_LIST = [];
const actionType = 'customer/getCustMotList';

// 获取客户简要通讯信息
const getCustBrifeContact = query => ({
  type: 'customer/getCustBrifeContact',
  payload: query || {},
  loading: false,
});

// 获取客户任务待办列表
const getDataFunction = loading => query => ({
  type: actionType,
  payload: query || {},
  loading,
});


const mapStateToProps = state => ({
  data: state.customer.custMotList,
  isLoading: state.loading.effects[actionType] || false,
  briefdata: state.customer.custBriefContact,
});

const mapDispatchToProps = {
  // 数据初始化
  initial: getDataFunction(true),
  // 数据刷新
  refresh: getDataFunction(false),
  push: routerRedux.push,
  goBack: routerRedux.goBack,
  getCustEmail: getCustBrifeContact,
  // 上传刷新页面log
  reportRefresh: query => ({
    type: 'global/refreshPage',
    payload: query,
  }),
};

@connect(mapStateToProps, mapDispatchToProps)
@withNavBar({ title: '待办任务', hasBack: true })
export default class CustTaskList extends PureComponent {
  static propTypes = {
    data: PropTypes.object.isRequired,
    push: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    initial: PropTypes.func.isRequired,
    refresh: PropTypes.func.isRequired,
    isLoading: PropTypes.bool.isRequired,
    briefdata: PropTypes.object.isRequired,
    titleName: PropTypes.object,
    getCustEmail: PropTypes.func.isRequired,
    reportRefresh: PropTypes.func.isRequired,
  };

  static defaultProps = {
    titleName: {
      checkAllBtn: '全选',
      leftContent: '电话联系',
      rightContent: '直接完成',
    },
  };

  constructor(props) {
    super(props);
    const {
      location: { query: { custNumber } },
      briefdata,
    } = this.props;
    this.state = {
      popover: {
        visible: false,
        offsetY: 0,
        baseRemoveY: 0,
        contain: '',
      },
      list: {
        listScrollY: 0,
        listHeight: 0,
      },
      // 待办任务列表是否每项都被选中，若选中则控制全选选中
      itemAllCheck: false,
      // 用于存放被选中的待办任务项的数据
      checkedItems: [],
      // 同checkedItems,但是只存id
      checkedIds: [],
      dataSource: briefdata[custNumber] || {},
    };
  }

  componentWillMount() {
    const {
      initial,
      data,
      location: { query: { custId, custNumber, custSor } },
      getCustEmail,
      briefdata,
    } = this.props;
    // 缓存策略：
    // native处理（直接完成／发送邮件）完成，会调用待办任务列表的action刷新state中的数据源，故此处可做缓存
    if (_.isEmpty(data[custId])) {
      initial({ custId, custNumber, custSor });
    }
    if (_.isEmpty(briefdata[custNumber])) {
      getCustEmail({ custNumber, custSor });
    }
  }

  componentWillReceiveProps(nextProps) {
    const { briefdata } = nextProps;
    const { location: { query: { custNumber } } } = this.props;
    if (briefdata[custNumber] !== this.props.briefdata[custNumber]) {
      this.setState({
        dataSource: briefdata[custNumber],
      });
    }
  }

  getData() {
    const { data, location: { query: { custId } } } = this.props;
    const custMotData = data[custId] || EMPTY_OBJECT;
    const { page = EMPTY_OBJECT, motTaskOfCust = EMPTY_LIST } = custMotData;
    return {
      list: motTaskOfCust,
      page,
    };
  }

  // 点击全选按钮返回字段用于操作待办任务列表的每项
  @autobind
  handleCheckAll(flag) {
    let checkedList = [];
    if (flag) {
      const data = this.getData();
      checkedList = data.list.map(item => ({ ...item }));
    }
    this.setState({
      checkedItems: checkedList,
      checkedIds: checkedList.map(item => item.mssnId),
      itemAllCheck: flag,
    });
  }

  @autobind
  handleItemSelected(rowData, checked) {
    const { checkedItems } = this.state;
    const { data, location: { query: { custId } } } = this.props;
    let checkedList = _.filter(checkedItems, item => item.mssnId !== rowData.mssnId);
    if (checked) {
      checkedList = [...checkedList, { ...rowData, custId }];
    }

    const custMotData = data[custId] || EMPTY_OBJECT;
    const { page = EMPTY_OBJECT } = custMotData;
    const { totalRecordNum } = page;

    this.setState({
      checkedItems: checkedList,
      checkedIds: checkedList.map(item => item.mssnId),
      itemAllCheck: checkedList.length === totalRecordNum,
    });
  }

  render() {
    const {
      titleName,
      data,
      refresh,
      location,
      push,
      isLoading,
      reportRefresh,
    } = this.props;
    const { query: { custId } } = location;
    const { dataSource, list, itemAllCheck, checkedIds } = this.state;
    const { listHeight } = list;
    const custMotData = data[custId] || EMPTY_OBJECT;
    const { motTaskOfCust = EMPTY_LIST } = custMotData;
    const custMotList = prepareDataSource(motTaskOfCust);
    let isLoaded = false;
    if (custMotList.getRowCount() !== 0) {
      isLoaded = true;
    }

    return (
      <section className="task-detail">
        <CustTaskDesc
          list={motTaskOfCust}
          listHeight={listHeight}
          push={push}
          custId={custId}
          location={location}
          refresh={refresh}
          isFetching={isLoading}
          onItemSelected={this.handleItemSelected}
          checkedList={checkedIds}
          reportRefresh={reportRefresh}
        />
        <TaskListMenu
          push={push}
          title={titleName}
          data={dataSource}
          location={location}
          checkAll={this.handleCheckAll}
          itemAllCheck={itemAllCheck}
          isLoaded={isLoaded}
          checkedItems={this.state.checkedItems}
        />
      </section>
    );
  }
}
