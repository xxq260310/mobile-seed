/**
 * @file customer/Home.js
 * @author maoquan(maoquan@htsc.com)
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'dva';
import { withRouter, routerRedux } from 'dva/router';
import { autobind } from 'core-decorators';
import { Drawer } from 'antd-mobile';
import _ from 'lodash';

import {
  addBackbuttonListener,
  removeBackbuttonListener,
} from '../../utils/cordova';
import PopMask from '../../components/common/PopMask';
import Searchable from '../../components/customer/Searchable';
import CustomerList from '../../components/customer/List';
import CustomerHeader from '../../components/customer/ListHeader';
import Filter from '../../components/customer/Filter';
import './home.less';

const actionType = 'customer/getList';

const mapStateToProps = state => ({
  list: state.customer.list,
  isLoading: state.loading.effects[actionType] || false,
});

const getListFunction = loading => query => ({
  type: actionType,
  payload: query || {},
  loading,
});

const mapDispatchToProps = {
  getList: getListFunction(true),
  // 提供给下拉刷新组件
  refresh: getListFunction(false),
  push: routerRedux.push,
  replace: routerRedux.replace,
  // 上传刷新页面log
  reportRefresh: query => ({
    type: 'global/refreshPage',
    payload: query,
  }),
  openFilter: query => ({
    type: 'customer/openFilter',
    payload: query,
  }),
};

const appContainer = document.querySelector('#app');

@connect(mapStateToProps, mapDispatchToProps)
@withRouter
@Searchable
export default class CustomerHome extends PureComponent {
  static propTypes = {
    getList: PropTypes.func.isRequired,
    refresh: PropTypes.func.isRequired,
    list: PropTypes.object,
    location: PropTypes.object.isRequired,
    replace: PropTypes.func.isRequired,
    push: PropTypes.func.isRequired,
    isLoading: PropTypes.bool.isRequired,
    selectOpen: PropTypes.bool.isRequired,
    reportRefresh: PropTypes.func.isRequired,
    openFilter: PropTypes.func.isRequired,
  }

  static defaultProps = {
    list: {},
  }

  constructor(props) {
    super(props);

    const { selectOpen } = this.props;

    this.state = {
      open: false,
      position: 'right',
      maskShow: false,
      selectOpen,
    };
  }

  componentWillMount() {
    const { list: { resultList }, location: { query } } = this.props;
    if (_.isEmpty(resultList)) {
      this.props.getList({
        ...query,
        pageNum: 1,
      });
    }
    appContainer.addEventListener('touchmove', this.handleTouch, false);
  }

  componentDidMount() {
    const popMask = document.querySelector('#select-pop-mask');
    popMask.addEventListener('touchstart', this.handlePopMaskClick, false);
  }

  componentWillReceiveProps(nextProps) {
    const { location: { query }, selectOpen } = nextProps;
    const { location: { query: preQuery } } = this.props;
    if (selectOpen) {
      // 如果selectOpen = false时不考虑组件变化
      this.setState({
        maskShow: false,
      });
    }
    // 条件变化
    if (!_.isEqual(query, preQuery)) {
      this.props.getList({
        ...query,
        pageNum: 1,
      });
      // 如果列表滚动了很远，这时候切换列表数据源，
      // scrollTop不会自己恢复,需要手动搞一下
      this.resetScroll();
    }
  }

  componentWillUnmount() {
    const popMask = document.querySelector('#select-pop-mask');
    // 无脑移除添加一次，保证组件销毁时全局backbutton可用
    removeBackbuttonListener();
    appContainer.removeEventListener('touchmove', this.handleTouch, false);
    popMask.removeEventListener('touchstart', this.handlePopMaskClick, false);
  }

  @autobind
  onOpenChange() {
    const { open } = this.state;
    const { openFilter } = this.props;
    this.setState(
      { open: !open },
      () => {
        if (open) {
          // 此时是指的是需要关闭筛选功能
          // open = true
          removeBackbuttonListener();
        } else {
          openFilter({
            actionSource: '客户列表',
          });
          // 打开抽屉的时候状态open = false
          addBackbuttonListener(this.handleBackbutton);
        }
      },
    );
  }

  @autobind
  handleBackbutton() {
    const { open } = this.state;
    if (open) {
      this.setState({ open: !open });
    }
  }

  @autobind
  handleTouch(event) {
    const { open } = this.state;
    const wrapperHeight = document.querySelector('.filterWrapper').clientHeight;
    const scrollHeight = document.querySelector('.filterScroll').scrollHeight;
    if (open && scrollHeight < wrapperHeight) {
      event.preventDefault();
    }
  }

  resetScroll() {
    if (this.listElem) {
      this.listElem.scrollTo(0);
    }
  }

  // 下拉选项框的蒙层
  @autobind
  popMaskShow(flag) {
    this.setState({
      maskShow: flag,
    });
  }

  // 添加点击PopMask事件
  @autobind
  handlePopMaskClick(event) {
    event.preventDefault();
    this.popMaskShow(false);
    // 当点击了蒙层时，需要将所有的下拉框全部收起
  }

  render() {
    const {
      list,
      refresh,
      location,
      replace,
      push,
      isLoading,
      reportRefresh,
    } = this.props;
    const sidebar = (
      <Filter
        onOpenChange={this.onOpenChange}
        location={location}
        replace={replace}
      />
    );
    const drawerProps = {
      open: this.state.open,
      position: this.state.position,
      onOpenChange: this.onOpenChange,
    };
    const bar = document.querySelector('.am-tab-bar-bar');
    const footerHeight = bar ? bar.offsetHeight : 0;
    const { maskShow } = this.state;
    return (
      <section className="page-customer">
        <PopMask
          height={document.documentElement.clientHeight - footerHeight}
          show={maskShow}
        />
        <CustomerHeader
          onOpenChange={this.onOpenChange}
          location={location}
          replace={replace}
          maskShow={maskShow}
          popMaskShow={this.popMaskShow}
        />
        <CustomerList
          ref={ref => (this.listElem = ref)}
          list={list}
          getList={refresh}
          location={location}
          replace={replace}
          push={push}
          isFetching={isLoading}
          reportRefresh={reportRefresh}
        />
        <Drawer
          className="my-drawer"
          sidebar={sidebar}
          style={{ maxHeight: document.documentElement.clientHeight - footerHeight }}
          dragHandleStyle={{ display: 'none' }}
          touch={false}
          {...drawerProps}
        >
          .
        </Drawer>
      </section>
    );
  }
}
