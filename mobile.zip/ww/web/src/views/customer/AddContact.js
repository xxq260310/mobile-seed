/**
 * @file customer/AddConcact.js
 *  机构客户联系方式
 * @author wangjunjun
 */

import React, { PureComponent, PropTypes } from 'react';
import { routerRedux } from 'dva/router';
import { connect } from 'react-redux';
import { Flex, Modal } from 'antd-mobile';
import { autobind } from 'core-decorators';
import _ from 'lodash';

import NavBar from '../../components/common/NavBar';
import Icon from '../../components/common/Icon';
import { getAvailableHeight, checkFormate } from '../../utils/helper';
import Toast from '../../components/common/Toast';

import './addcontact.less';

const alert = Modal.alert;

const YESNO = ['否', '是'];

const mapStateToProps = state => ({
  addContact: state.customer.addContact,
  systemConstData: state.global.systemConst,
});

const mapDispatchToProps = {
  goBack: routerRedux.goBack,
  push: routerRedux.push,
  saveContactOrg: query => ({
    type: 'customer/saveContactOrg',
    payload: query,
  }),
  addContactsInfo: query => ({
    type: 'customer/addContactsInfo',
    payload: query,
  }),
};

function showMessage(msg) {
  Toast.show(msg, 1);
}

@connect(mapStateToProps, mapDispatchToProps)
export default class ContactOrgDetail extends PureComponent {

  static propTypes = {
    push: PropTypes.func.isRequired,
    goBack: PropTypes.func.isRequired,
    saveContactOrg: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    addContact: PropTypes.object.isRequired,
    systemConstData: PropTypes.object.isRequired,
    addContactsInfo: PropTypes.func.isRequired,
    data: PropTypes.object.isRequired,
  }

  static defaultProps = {
  }

  constructor(props) {
    super(props);
    this.state = {
      wrapperHeight: 0,
    };
  }

  componentDidMount() {
    this.setWrapperHeight();
  }

  componentDidUpdate() {
    this.setWrapperHeight();
  }

  setWrapperHeight() {
    this.setState({
      wrapperHeight: getAvailableHeight(),
    });
  }

  @autobind
  handleSaveClick() {
    const { isCellphone, isTelephone, isEmail } = checkFormate;
    const {
      location: { query: { custNumber, custId } },
      addContact: {
        name,
        cellPhones,
        workTels,
        homeTels,
        emailAddresses,
        custRela,
        mainFlag,
      },
      addContactsInfo,
    } = this.props;
    console.log('mainFlag>>>', mainFlag);
    if (!name) {
      showMessage('联系人姓名不能为空');
      return;
    }
    if (Object.keys(custRela).length === 0 || !custRela.selectKey || !custRela.selectValue) {
      showMessage('请选择人员类型');
      return;
    }
    if (mainFlag === undefined) {
      showMessage('请选择是否主要');
      return;
    }
    if (cellPhones && !isCellphone(cellPhones)) {
      showMessage('手机号码格式不正确');
      return;
    }
    if (workTels && !isCellphone(workTels) && !isTelephone(workTels)) {
      showMessage('单位电话格式不正确');
      return;
    }
    if (homeTels && !isCellphone(homeTels) && !isTelephone(homeTels)) {
      showMessage('住宅电话格式不正确');
      return;
    }
    if (emailAddresses && (!isEmail(emailAddresses) || emailAddresses.indexOf(' ') !== -1)) {
      showMessage('邮箱地址格式不正确');
      return;
    }
    const condition = {
      custId,
      custNumber,
      custSor: 'org',
      name,
      custRela: custRela.selectValue,
      custRelaCd: custRela.selectKey,
      mainFlag: !!(+mainFlag),
      validFlag: true,
    };
    if (cellPhones) {
      condition.cellPhones = [{ contactValue: cellPhones }];
    }
    if (workTels) {
      console.log('workTels', workTels);
      condition.workTels = [{ contactValue: workTels }];
    }
    if (homeTels) {
      console.log('homeTels', homeTels);
      condition.homeTels = [{ contactValue: homeTels }];
    }
    if (emailAddresses) {
      console.log('emailAddresses', emailAddresses);
      condition.emailAddresses = [{ contactValue: emailAddresses }];
    }
    addContactsInfo(condition);
  }

  @autobind
  handleLeftClick() {
    const { goBack } = this.props;
    alert('提示', '确认放弃本次编辑内容？', [
      { text: '否', onPress: () => console.log('cancel') },
      { text: '是', onPress: () => goBack() },
    ]);
  }

  linkTo(
    title,
    opObj,
    defaultValue = '',
    type = '',
    pathname = '/common',
  ) {
    const { isCellphone, isTelephone, isEmail } = checkFormate;
    const { saveContactOrg } = this.props;
    this.props.push({
      pathname,
      query: {
        type,
        opObj,
        title: encodeURIComponent(title),
        defaultValue: encodeURIComponent(defaultValue),
        noGobackHint: true,
        option: 'add',
      },
      state: {
        onSave: (obj) => {
          if (opObj === 'name'
            && Object.keys(obj).length !== 0
            && obj.value.length > 50) {
            showMessage('联系人姓名输入不能超过50个字符');
            return;
          }
          if (Object.keys(obj).length !== 0
            && obj.name === 'cellPhones'
            && !isCellphone(obj.value)) {
            showMessage('手机号码格式不正确');
            return;
          }
          if (Object.keys(obj).length !== 0
            && _.includes(['workTels', 'homeTels'], obj.name)
            && !isTelephone(obj.value) && !isCellphone(obj.value)) {
            showMessage('电话号码格式不正确');
            return;
          }
          if (opObj === 'emailAddresses'
            && Object.keys(obj).length !== 0
            && obj.value.length > 50) {
            showMessage('邮箱地址输入不能超过50个字符');
            return;
          }
          if (Object.keys(obj).length !== 0
            && obj.name === 'emailAddresses'
            && (!isEmail(obj.value) || obj.value.indexOf(' ') !== -1)) {
            showMessage('邮箱地址格式不正确');
            return;
          }
          saveContactOrg(obj);
        },
      },
    });
  }

  linkToTwo(type, title, defaultValue) {
    console.log('mainFlag', defaultValue);
    const {
      push,
      systemConstData,
      saveContactOrg,
    } = this.props;
    push({
      pathname: '/customer/CustBasicEdit',
      query: {
        seltype: 'selRadio',
        titleName: title,
        navRightStyle: true,
        navStyle: true,
      },
      state: {
        selectValue: type === 'custRela' ? defaultValue : YESNO[+defaultValue],
        options: type === 'custRela' ? systemConstData['206'] : YESNO,
        onSave: (obj) => {
          if (type === 'custRela') {
            saveContactOrg({ name: 'custRela', value: obj });
          } else if (type === 'mainFlag') {
            saveContactOrg({ name: 'mainFlag', value: obj.selectKey });
          }
        },
      },
    });
  }

  render() {
    const { wrapperHeight } = this.state;
    const { addContact: {
      name,
      cellPhones,
      workTels,
      homeTels,
      emailAddresses,
      custRela,
      mainFlag } } = this.props;

    const renderButton = obj => (
      <div className="btn-save" onClick={obj.handleClick}>
        {obj.name}
      </div>
    );

    return (
      <div>
        <div className="contact-org-detail add-contact">
          <NavBar
            iconName={'iconfontfanhui2'}
            onLeftClick={this.handleLeftClick}
            rightContent={renderButton({
              name: '保存',
              handleClick: this.handleSaveClick,
            })}
          >
            新增联系人
          </NavBar>
          <section className="contain" style={{ height: wrapperHeight }}>
            <ul className="list-container">
              <li className="list-item" onClick={() => this.linkTo('姓名', 'name', name)}>
                <Flex direction="row" align="center">
                  <Icon className="" type="account" />
                  <Flex className="list-content" justify="between">
                    <span className="label">联系人姓名</span>
                    <p>{name || '请填写'}</p>
                    <Icon className="more" type="more" />
                  </Flex>
                </Flex>
              </li>
              <li className="list-item" onClick={() => this.linkToTwo('custRela', '人员类型', (custRela || {}).selectValue)}>
                <Flex direction="row" align="center">
                  <Icon className="" type="viewgallery" />
                  <Flex className="list-content" justify="between">
                    <span className="label">人员类型</span>
                    <p>{(custRela || {}).selectValue || '请选择'}</p>
                    <Icon className="more" type="more" />
                  </Flex>
                </Flex>
              </li>
              <li className="list-item" onClick={() => this.linkToTwo('mainFlag', '是否主要', mainFlag)}>
                <Flex direction="row" align="center">
                  <Icon className="" type="favorite" />
                  <Flex className="list-content" justify="between">
                    <span className="label">是否主要</span>
                    <p>{mainFlag !== undefined ? YESNO[+mainFlag] : '请选择'}</p>
                    <Icon className="more" type="more" />
                  </Flex>
                </Flex>
              </li>
              <li className="list-item" onClick={() => this.linkTo('手机号码', 'cellPhones', cellPhones, 'tel')}>
                <Flex direction="row" align="center">
                  <Icon className="" type="mobilephone" />
                  <Flex className="list-content" justify="between">
                    <span className="label">手机号码</span>
                    <p>{cellPhones || '请填写'}</p>
                    <Icon className="more" type="more" />
                  </Flex>
                </Flex>
              </li>
              <li className="list-item" onClick={() => this.linkTo('单位电话', 'workTels', workTels, 'tel')}>
                <Flex direction="row" align="center">
                  <Icon className="" type="phone" />
                  <Flex className="list-content" justify="between">
                    <span className="label">单位电话</span>
                    <p>{workTels || '请填写'}</p>
                    <Icon className="more" type="more" />
                  </Flex>
                </Flex>
              </li>
              <li className="list-item" onClick={() => this.linkTo('住宅电话', 'homeTels', homeTels, 'tel')}>
                <Flex direction="row" align="center">
                  <Icon className="" type="phone" />
                  <Flex className="list-content" justify="between">
                    <span className="label">住宅电话</span>
                    <p>{homeTels || '请填写'}</p>
                    <Icon className="more" type="more" />
                  </Flex>
                </Flex>
              </li>
              <li className="list-item" onClick={() => this.linkTo('电子邮件', 'emailAddresses', emailAddresses)}>
                <Flex direction="row" align="center">
                  <Icon className="" type="email" />
                  <Flex className="list-content" justify="between">
                    <span className="label">电子邮件</span>
                    <p>{emailAddresses || '请填写'}</p>
                    <Icon className="more" type="more" />
                  </Flex>
                </Flex>
              </li>
            </ul>
          </section>
        </div>
      </div>
    );
  }
}
