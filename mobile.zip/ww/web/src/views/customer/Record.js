/**
 * @file customer/ServRecord.js
 * @author zhangjunli
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'dva';
import { withRouter, routerRedux } from 'dva/router';
import { NavBar, Modal } from 'antd-mobile';
import { autobind } from 'core-decorators';
import moment from 'moment';
import 'moment/locale/zh-cn';
import _ from 'lodash';

import Toast from '../../components/common/Toast';
import ServRecord from '../../components/customer/ServRecord';
import './record.less';

const PHONE = '电话';
const DATE_FORMAT2 = 'YYYY-MM-DD HH:mm'; // 用于传参
const DATE_FORMAT = 'YYYY年MM月DD日 HH:mm';  // 界面显示

// 将毫秒转换成时分秒
function calculateDuration(intervalMs) {
  if (!intervalMs) {
    return '00秒';
  }
  const duration = moment('000000', 'HHmmss').add(intervalMs, 'ms');
  if (intervalMs <= 60 * 1000) {
    return duration.format('ss秒');
  }
  if (intervalMs <= 60 * 60 * 1000) {
    return duration.format('mm分ss秒');
  }
  return duration.format('HH时mm分ss秒');
}

const mapStateToProps = state => ({
  empInfo: state.global.empInfo,
  requestParam: state.mission.recordPageNeedfulData,
  content: state.customer.content,
  serviceTypeOption: state.customer.serviceTypeOption,
  addRecordResult: state.customer.addRecordResult,
  dictionary: state.global.dictionary,
  isLoading: state.loading.effects['customer/addCommonServeRecord'],
});

const mapDispatchToProps = {
  getServiceType: query => ({
    type: 'customer/getServiceType',
    payload: query || {},
  }),
  saveServiceContent: query => ({
    type: 'customer/saveServiceContent',
    payload: query || {},
  }),
  resetServiceRecordSuccess: query => ({
    type: 'customer/addCommonServeRecordSuccess',
    payload: query,
  }),
  addCommonServeRecord: query => ({
    type: 'customer/addCommonServeRecord',
    payload: query || {},
  }),
  getDictionary: query => ({
    type: 'global/getDictionary',
    payload: query || {},
    loading: false,
  }),
  getMotDetailList: query => ({
    type: 'mission/fetchMotDetail',
    payload: query || {},
    loading: false,
  }),
  getMotCenterList: query => ({
    type: 'mission/getCenter',
    payload: query || {},
    loading: false,
  }),
  getServeRecordList: query => ({
    type: 'customer/getServiceRecordList',
    payload: query || {},
    loading: false,
  }),
  getToDoList: query => ({
    type: 'customer/getCustMotList',
    payload: query || {},
    loading: false,
  }),
  push: routerRedux.push,
  replace: routerRedux.replace,
};

@connect(mapStateToProps, mapDispatchToProps)
@withRouter
export default class Record extends PureComponent {
  static propTypes = {
    getToDoList: PropTypes.func.isRequired,
    getServeRecordList: PropTypes.func.isRequired,
    getMotCenterList: PropTypes.func.isRequired,
    getMotDetailList: PropTypes.func.isRequired,
    getServiceType: PropTypes.func.isRequired,
    saveServiceContent: PropTypes.func.isRequired,
    resetServiceRecordSuccess: PropTypes.func.isRequired,
    addCommonServeRecord: PropTypes.func.isRequired,
    serviceTypeOption: PropTypes.object.isRequired,
    addRecordResult: PropTypes.bool.isRequired,
    location: PropTypes.object.isRequired,
    router: PropTypes.object.isRequired,
    replace: PropTypes.func.isRequired,
    push: PropTypes.func.isRequired,
    getDictionary: PropTypes.func.isRequired,
    isLoading: PropTypes.bool,
    dictionary: PropTypes.object,
    content: PropTypes.string,
    requestParam: PropTypes.object,
    empInfo: PropTypes.object,
  }

  static defaultProps = {
    isLoading: false,
    dictionary: {},
    requestParam: {},
    empInfo: {},
    content: '',
  }

  constructor(props) {
    super(props);
    this.initInfo(props);
    this.state = {
      isClickCancel: false,
      isClickSave: false,
      isShow: false,
    };
  }

  componentDidMount() {
    const {
      serviceTypeOption,
      getServiceType,
      dictionary,
      getDictionary,
      location: { query },
    } = this.props;
    if (!this.hasMission && _.isEmpty(serviceTypeOption)) {
      // 请求服务类型数据（反馈数据内包含客户反馈和反馈明细）
      // 参数的type，固定传 2
      getServiceType({
        type: 2,
        pageNum: 1,
        pageSize: 10000,
      });
    }
    // 字典值为空，则发起请求
    if (_.isEmpty(dictionary)) {
      getDictionary();
    }
    // 当前时间
    const nowDate = moment().locale('zh-cn').utcOffset(8).format(DATE_FORMAT);
    if (!query.serveDate) {
      // 服务时间到保存在location中。从编辑服务记录返回到创建服务记录界面，服务时间，要保持不变
      this.handleChange({ serveDate: this.serveDate || nowDate });
    }
  }

  componentWillReceiveProps(nextProps) {
    const { isLoading, addRecordResult, resetServiceRecordSuccess } = nextProps;
    // isLoading 从true->false，说明请求完成
    if (isLoading !== this.props.isLoading && !isLoading) {
      if (addRecordResult) {
        this.showSuccessToast();
        // 当请求返回code不为0，则modal中的success回调，不能执行，导致addRecordResult仍是上次成功的值。
        // 手动重置 添加服务记录 成功标志
        resetServiceRecordSuccess(false);
        // 下面界面，做了缓存，故有改动，需要统一刷新下
        const { requestParam = {} } = this.props;
        const { custNumber = '', custId = '', custType = '', motTaskId = '' } = requestParam || {};
        // 刷新历史服务记录列表
        this.props.getServeRecordList({ custId: custNumber });
        if (this.hasMission) {
          // 刷新任务中心列表
          this.props.getMotCenterList();
          // 刷新代办任务
          this.props.getToDoList({ custId, custNumber, custSor: custType });
          if (motTaskId) {
            // 刷新任务详情列表
            this.props.getMotDetailList({ motTaskId });
          }
        }
      } else {
        // 恢复button可点击
        this.setState({ isClickSave: false });
      }
    }
  }

  @autobind
  getParam() {
    const {
      content,
      dictionary,
      requestParam,
      empInfo,
      location: { query },
    } = this.props;
    const {
      custId = '',
      custType = '',
      serveWay = '',
      eventFlowIdList = [],
    } = requestParam || {};
    const { rowId } = empInfo || {};
    const { serveWay: serveWayList = [] } = dictionary || {};
    // 服务方式的key
    if (!this.isDirectComplete && !this.serveWayValue) {
      const serveWayItem = _.find(serveWayList, item => item.value === serveWay) || {};
      this.serveWayValue = serveWayItem.key || '';
    }
    // 客户类型
    const custTypeValue = custType === 'prod' ? 'org' : custType;
    // 服务记录
    const preServeContent = this.preContent ? `${this.preContent}。` : '';
    return {
      custRowId: custId || '',  // 客户id
      custType: custTypeValue || '', // 客户类型
      empRowId: rowId || '', // 登录人rowid
      serveType: query.serviceType || '', // 服务类型
      serveWay: query.actionType || this.serveWayValue, // 服务方式
      serveDate: query.serveDate ?
        moment(query.serveDate, DATE_FORMAT2).utcOffset(8).format(DATE_FORMAT2) : '', // 服务时间
      serveContentDesc: `${preServeContent}${content}`, // 服务记录
      serveCustFeedBack: query.custFeedback || '', // 客户反馈
      serveCustFeedBack2: query.feedbackDetail || '', // 反馈明细
      eventFlowIdList, // 流水id 数组
    };
  }

  @autobind
  initInfo(props) {
    const { requestParam } = props;
    const {
      serveWay = '',
      serveDate,
      callDuration,
      eventFlowIdList = [],
    } = requestParam || {};
    // 是否是直接完成（留痕类型有两种，一种是直接完成，一种是打电话）
    this.isDirectComplete = !serveWay;
    // 是否是有任务的服务记录
    this.hasMission = !_.isEmpty(eventFlowIdList);
    // 服务方式赋值
    this.actionType = this.isDirectComplete ? '' : serveWay;
    // 服务时间
    this.serveDate = serveDate || '';
    // 服务记录，预置内容
    if (!this.isDirectComplet && serveWay === PHONE) {
      const formateServeDate = moment(serveDate, DATE_FORMAT2).utcOffset(8).format('HH:mm:ss');
      // callDuration 单位是 毫秒
      const formateDuration = calculateDuration(callDuration).replace(/^0/g, '');
      this.preContent = `${formateServeDate}给客户发起语音通话，通话时长${formateDuration}`;
    }
  }

  @autobind
  goBack() {
    const { router } = this.props;
    // 返回
    router.goBack();
  }

  @autobind
  saveBack() {
    const { isClickCancel, isClickSave } = this.state;
    if (!isClickCancel && !isClickSave) { // 避免连续点击
      this.setState({ isClickCancel: true });
      if (this.isDirectComplete) {
        // 清空缓存数据
        this.props.saveServiceContent({ content: '' });
        // 恢复button可点击
        this.setState({ isClickCancel: false });
        this.goBack();
      } else {
        // 弹框提醒用户，保存服务记录
        this.setState({ isShow: true });
      }
    }
  }

  @autobind
  saveRecord() {
    const { isClickSave, isClickCancel } = this.state;
    if (!isClickSave && !isClickCancel) { // 避免连续点击
      this.setState({ isClickSave: true });
      const {
        content = '',
        location: { query },
        addCommonServeRecord,
      } = this.props;
      // 有任务的服务留痕
      if (this.hasMission) {
        if (this.isDirectComplete && !query.actionType) {
          Toast.fail('请选择服务方式');
          this.setState({ isClickSave: false });
        } else if (this.isDirectComplete && !content) {
          Toast.fail('请填写服务记录');
          this.setState({ isClickSave: false });
        } else {
          addCommonServeRecord(this.getParam());
        }
        return;
      }
      // 无任务的服务留痕
      if (!query.serviceType) {
        Toast.fail('请选择服务类型');
        this.setState({ isClickSave: false });
      } else if (!query.custFeedback) {
        Toast.fail('请选择客户反馈');
        this.setState({ isClickSave: false });
      } else if (query.hasFeedbackDetail === 'true' && !query.feedbackDetail) {
        Toast.fail('请选择反馈明细');
        this.setState({ isClickSave: false });
      } else {
        addCommonServeRecord(this.getParam());
      }
    }
  }

  @autobind
  showSuccessToast() {
    Toast.info('保存成功', 1, () => {
      // 清空缓存数据
      this.props.saveServiceContent({ content: '' });
      // 恢复按钮可点击
      this.setState({ isClickSave: false });
      this.goBack();
    });
  }

  @autobind
  handleChange(item) {
    const { replace, location: { query } } = this.props;
    replace({
      pathname: '/customer/record',
      query: {
        ...query,
        ...item,
      },
    });
  }

  @autobind
  handleModalClose() {
    this.setState({
      isShow: false,
      isClickCancel: false,
    });
  }

  render() {
    const {
      push,
      content,
      dictionary,
      requestParam,
      serviceTypeOption,
      location: { query },
    } = this.props;
    const {
      custName = '',
      callDuration = '',
    } = requestParam || {};
    const { serveWay = [] } = dictionary || {};

    // 当前时间
    const nowDate = moment().locale('zh-cn').utcOffset(8).format(DATE_FORMAT);

    return (
      <section className="page-record">
        <NavBar
          leftContent="取消"
          onLeftClick={() => this.saveBack()}
          rightContent={<div onClick={() => this.saveRecord()}>完成</div>}
          className="navbar"
          iconName={false}
        >
          创建服务记录
        </NavBar>
        <ServRecord
          preContent={this.preContent}
          serveWay={serveWay}
          custName={custName}
          actionType={query.actionType || this.actionType}
          serveDate={this.serveDate || query.serveDate || nowDate}
          serviceRecord={content}
          serviceType={query.serviceType}
          custFeedback={query.custFeedback}
          feedbackDetail={query.feedbackDetail}
          callDuration={callDuration}
          serviceTypeOption={serviceTypeOption}
          hasMission={this.hasMission}
          isDirectComplete={this.isDirectComplete}
          changeForm={this.handleChange}
          push={push}
        />
        <Modal
          title={'提示'}
          transparent
          maskClosable={false}
          visible={this.state.isShow}
          footer={[{ text: '确定', onPress: this.handleModalClose }]}
          onClose={this.handleModalClose}
        >
          <div>请保存服务记录</div>
        </Modal>
      </section>
    );
  }
}
