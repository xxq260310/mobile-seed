/**
 * @file customer/CustContactOrg.js
 *  机构客户联系方式
 * @author liutingting(3171214926@qq.com)
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'react-redux';
import { routerRedux } from 'dva/router';
import { autobind } from 'core-decorators';
import _ from 'lodash';
import { Flex } from 'antd-mobile';

import withNavBar from '../../components/common/withNavBar';
import PullToRefreshable from '../../components/common/PullToRefreshable';
import Icon from '../../components/common/Icon';
import Message from '../../components/message';
import helper from '../../utils/helper';
import './CustContactOrg.less';

const getDataFunction = loading => query => ({
  type: 'customer/getOrgContact',
  payload: query || {},
  loading,
});

const mapStateToProps = state => ({
  data: state.customer.contactList,
  isLoading: state.loading.models.customer,
  detailInfo: state.customer.detailInfo,
});

const mapDispatchToProps = {
  push: routerRedux.push,
  getData: getDataFunction(true),
  refresh: getDataFunction(false),
  clearPrevAddContent: () => ({
    type: 'customer/clearPrevAddContent',
  }),
  // 上传刷新页面log
  reportRefresh: query => ({
    type: 'global/refreshPage',
    payload: query,
  }),
};

const mergeProps = (stateProps, dispatchProps, ownProps) => {
  const { location: { query: { custId } } } = ownProps;
  const { location: { query } } = ownProps;
  const { data } = stateProps;
  let name = '机构联系人';
  if (data[custId]) {
    const { custBaseInfo: { custName = '--' } } = data[custId];
    name = custName;
  }
  return {
    refreshData: query,
    ...stateProps,
    ...dispatchProps,
    ...ownProps,
    title: <p>{name}</p>,
  };
};

@connect(mapStateToProps, mapDispatchToProps, mergeProps)
@withNavBar({ hasBack: true })
@PullToRefreshable
export default class CustContactOrg extends PureComponent {
  static propTypes = {
    data: PropTypes.object.isRequired,
    getData: PropTypes.func.isRequired,
    refresh: PropTypes.func.isRequired,
    refreshData: PropTypes.object.isRequired,
    push: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    title: PropTypes.object.isRequired,
    clearPrevAddContent: PropTypes.func.isRequired,
    detailInfo: PropTypes.object.isRequired,
    reportRefresh: PropTypes.func.isRequired,
    eventEmitter: PropTypes.object.isRequired,
  }

  static defaultProps = {
  }

  constructor(props) {
    super(props);
    this.state = {
      messageHeight: 0,
      isLoaded: false,
    };
  }

  componentWillMount() {
    const { getData, refreshData, eventEmitter } = this.props;
    getData(refreshData);
    eventEmitter.on('reportRefresh', this.handleEventEmitter);
  }

  componentDidMount() {
    this.setMessageHeight();
  }

  componentWillReceiveProps(nextProps) {
    const { data } = nextProps;
    if (data !== this.props.data) {
      this.setState({ isLoaded: true });
    }
  }

  componentDidUpdate() {
    this.setMessageHeight();
  }

  componentWillUnmount() {
    const { eventEmitter } = this.props;
    eventEmitter.removeListener('reportRefresh', this.handleEventEmitter);
  }

  setMessageHeight() {
    this.setState({
      messageHeight: helper.getAvailableHeight(),
    });
  }

  @autobind
  getDataModel() {
    const { data = {}, location: { query: { custId = '--' } } } = this.props;
    const dataModel = data[custId] || {};
    return dataModel;
  }

  @autobind
  getCustName() {
    // 获取机构联系人数据列表
    const dataModel = this.getDataModel();
    if (dataModel === {} || _.isEmpty(dataModel.custBaseInfo)) return '--';
    const { custName = '--' } = dataModel.custBaseInfo || {};
    return custName;
  }

  @autobind
  getContactList() {
    // 获取机构联系人数据列表
    const dataModel = this.getDataModel();
    const contactList = dataModel.orgCustomerContactInfoList || [];
    return (contactList instanceof Array && contactList.length > 0) ? contactList : [];
  }

  @autobind
  getMainContact(arr) {
    // 获取主要联系人数据，主要联系人唯一
    if (!(arr.length > 0 && arr instanceof Array)) return {};
    let mainObj = {};
    arr.map((item) => {
      if (item.mainFlag === true) mainObj = item;
      return true;
    });
    return mainObj;
  }

  @autobind
  getOtherContact(arr) {
    // 获取非主要联系人列表
    if (!(arr.length > 0 && arr instanceof Array)) return [];
    const otherArr = [];
    arr.map((item, index) => {
      if (item.mainFlag === false) {
        otherArr.push({
          key: index + 1,
          ...item,
        });
      }
      return true;
    });
    return otherArr;
  }

  @autobind
  handleEventEmitter() {
    const { reportRefresh } = this.props;
    reportRefresh({
      actionSource: '机构客户联系方式',
    });
  }

  @autobind
  handleClick(mainFlag, obj) {
    // 跳转联系人详情页
    const { rowId = '' } = obj;
    const { push, location: { query: { custNumber, custId = '--' } }, title } = this.props;
    push({
      pathname: '/customer/contactOrgDetail',
      query: {
        mainFlag,
        custNumber,
        custId,
        rowId,
        custName: title.props.children,
      },
    });
  }

  @autobind
  handleAdd(custNumber, custId) {
    const { push, clearPrevAddContent } = this.props;
    clearPrevAddContent();
    push(`/customer/addContact?custNumber=${custNumber}&custId=${custId}`);
  }

  render() {
    const { messageHeight, isLoaded } = this.state;
    const { detailInfo, location: { query: { custNumber, custId } } } = this.props;
    const contactArr = this.getContactList();
    if (!contactArr.length) {
      return (
        <div className="cust-contact-org">
          <section className="contain">
            {
              detailInfo[custId].isMainEmp ?
                (
                  <Flex
                    align="center"
                    className="add-btn"
                    style={{ margin: '0' }}
                    onClick={() => { this.handleAdd(custNumber, custId); }}
                  >
                    <Icon
                      className="add"
                      type="weibiaoti--"
                    />
                    <span>新增</span>
                  </Flex>
                ) : null
            }
          </section>
        </div>
      );
    }
    const isNull = (contactArr && contactArr.length > 0) ? 'have-data' : 'no-data';
    if (isNull === 'no-data') {
      return isLoaded ? (
        <div className="cust-contact-org">
          <Message
            type={'notfound'}
            text={'暂无联系人'}
            height={messageHeight}
          />
        </div>
      ) : null;
    }
    const mainData = this.getMainContact(contactArr);
    const otherData = this.getOtherContact(contactArr);

    const mainShow = () => {
      if (mainData === {}) {
        return (
          <div className="item">
            <p className="left nodata"><Icon className="left" type="shenfenzheng" />暂无信息</p>
          </div>
        );
      }
      return (
        <div className="item" data={mainData} onClick={() => this.handleClick('Y', mainData)}>
          <p className="left"><i className="main-icon" />{mainData.name || '--'}</p>
          <p className="right">{(mainData.custRela) ? mainData.custRela : '--'}</p>
          <Icon className="more" type="more" />
        </div>
      );
    };
    const otherShow = () => {
      if (otherData === []) return null;
      return otherData.map(item => (
        <div className="item" data={item} key={item.key} onClick={() => { this.handleClick('N', item); }}>
          <p className="left">{item.name || '--'}</p>
          <p className="right">{item.custRela || '--'}</p>
          <Icon className="more" type="more" />
        </div>
      ));
    };

    return (
      <div className="cust-contact-org">
        <section className="contain">
          <div className={`main ${isNull}`}>
            {mainShow()}
          </div>
          <div className={`other ${isNull} len-${otherData.length}`}>
            {otherShow()}
          </div>
          {
            detailInfo[custId].isMainEmp ?
              (
                <Flex
                  align="center"
                  className="add-btn"
                  onClick={() => { this.handleAdd(custNumber, custId); }}
                >
                  <Icon
                    className="add"
                    type="weibiaoti--"
                  />
                  <span>新增</span>
                </Flex>
              ) : null
          }
        </section>
      </div>
    );
  }
}
