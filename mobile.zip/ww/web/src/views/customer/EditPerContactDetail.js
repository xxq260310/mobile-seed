/**
 * @file customer/EditPerContactDetail.js
 *  编辑个人电话
 * @author xuxiaoqin
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'react-redux';
import { routerRedux } from 'dva/router';
import { Modal } from 'antd-mobile';
import { autobind } from 'core-decorators';
import _ from 'lodash';
// import { hideKeyboard } from '../../utils/helper';
import EditDetail from '../../components/customer/EditDetail';
import '../../components/common/withNavBar.less';

const alert = Modal.alert;

const mapStateToProps = state => ({
  global: state.global,
  goBackCount: state.customer.goBackCount,
  saveDataFunction: state.customer.saveDataFunction,
});

const updateGoBackLevelFunction = (query, loading = true) => ({
  type: 'customer/updateGoBackLevel',
  payload: query,
  loading,
});

const mapDispatchToProps = {
  push: routerRedux.push,
  goBack: routerRedux.goBack,
  replace: routerRedux.replace,
  go: routerRedux.go,
  updateGoBackLevel: updateGoBackLevelFunction,
};

const mergeProps = (stateProps, dispatchProps, ownProps) => {
  const { location: { query: { type } } } = ownProps;
  let editTitle = '';
  switch (type) {
    case 'tel':
      editTitle = '编辑电话';
      break;
    case 'address':
      editTitle = '编辑地址';
      break;
    default:
      editTitle = '编辑';
      break;
  }
  return {
    title: editTitle,
    ...stateProps,
    ...dispatchProps,
    ...ownProps,
  };
};

// 空数据
const EMPTY_OBJECT = {};

@connect(mapStateToProps, mapDispatchToProps, mergeProps)
export default class EditPerContactDetail extends PureComponent {
  static propTypes = {
    title: PropTypes.string,
    push: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    goBack: PropTypes.func,
    global: PropTypes.object,
    replace: PropTypes.func.isRequired,
    go: PropTypes.func.isRequired,
    updateGoBackLevel: PropTypes.func.isRequired,
    goBackCount: PropTypes.number,
    saveDataFunction: PropTypes.object.isRequired,
  };

  static defaultProps = {
    title: '',
    goBack: () => { },
    global: {},
    goBackCount: 1,
  };

  constructor(props) {
    super(props);

    const { location: { query: {
      type = '',
      rowId = '',
      telValue = '',
      telType = '',
      province = '',
      city = '',
      addressValue = '',
      addressType = '',
      isAdd = 'N',
      cityCd = '',
      provinceCd = '',
      originType = '',
     } } } = this.props;

    let editData = EMPTY_OBJECT;

    switch (type) {
      case 'tel':
        editData = {
          rowId,
          telValue,
          telType,
          isAdd,
          originType,
          type,
        };
        break;
      case 'address':
        editData = {
          rowId,
          addressValue,
          addressType,
          province,
          city,
          isAdd,
          cityCd,
          provinceCd,
          originType,
          type,
        };
        break;
      default:
        editData = EMPTY_OBJECT;
        break;
    }

    this.state = {
      contactPerData: editData,
    };
  }

  @autobind
  handleLeftClick(newData) {
    const { goBack, go, updateGoBackLevel, location: { query: { type } } } = this.props;

    const { contactPerData: {
      telValue: prevTelValue = '',
      telType: prevTelType = '',
      addressValue: prevAddressValue = '',
      addressType: prevAddressType = '',
      province: prevProvince = '',
      city: prevCity = '',
      cityCd: prevCityCd,
      provinceCd: prevProvinceCd,
      rowId: prevRowId,
    } } = this.state;

    const {
      telValue,
      telType,
      addressValue,
      addressType,
      province,
      city,
      cityCd,
      provinceCd,
      rowId,
      goBackCount,
      originType,
    } = newData;

    const oldData = {
      telValue: prevTelValue,
      telType: type === 'tel' ? originType : prevTelType,
      addressValue: prevAddressValue,
      addressType: type === 'address' ? originType : prevAddressType,
      province: prevProvince,
      city: prevCity,
      cityCd: prevCityCd,
      provinceCd: prevProvinceCd,
      rowId: prevRowId,
    };

    const compareData = {
      telValue,
      telType,
      addressValue,
      addressType,
      province,
      city,
      cityCd,
      provinceCd,
      rowId,
    };

    if (!_.isEqual(oldData, compareData)) {
      alert('提示', '确认放弃本次编辑内容？', [
        { text: '否', onPress: () => console.log('cancel') },
        {
          text: '是',
          onPress: () => {
            if (goBackCount === 1) {
              goBack();
            } else {
              go(-goBackCount);
              // 恢复返回级数
              updateGoBackLevel({ count: 1 });
            }
          },
        },
      ]);
    } else if (goBackCount === 1) {
      goBack();
    } else {
      go(-goBackCount);
      // 恢复返回级数
      updateGoBackLevel({ count: 1 });
    }
  }

  @autobind
  handleRightClick(newData) {
    const { location: { state: { onSavePerContact } }, saveDataFunction } = this.props;
    if (!onSavePerContact) {
      const { onSavePerContact: onSave } = saveDataFunction;
      onSave(newData);
    } else {
      onSavePerContact(newData);
    }
  }

  render() {
    const {
      push,
      location,
      goBack,
      replace,
      title,
      global,
      location: { query: { type } },
      updateGoBackLevel,
      goBackCount,
      saveDataFunction,
    } = this.props;

    const { contactPerData } = this.state;

    return (
      <EditDetail
        data={contactPerData}
        type={type}
        location={location}
        push={push}
        recordValue={this.recordValue}
        leftClick={this.handleLeftClick}
        rightClick={this.handleRightClick}
        title={title}
        global={global}
        replace={replace}
        goBack={goBack}
        updateGoBackLevel={updateGoBackLevel}
        goBackCount={goBackCount}
        saveDataFunction={saveDataFunction}
      />
    );
  }
}
