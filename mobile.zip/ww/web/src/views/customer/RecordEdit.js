/**
 * @file customer/RecordEdit.js
 * @author fwc
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'dva';
import { withRouter } from 'dva/router';
import { autobind } from 'core-decorators';
import { NavBar } from 'antd-mobile';

import { setNothing, setResize } from '../../utils/cordova';
import { hideKeyboard } from '../../utils/helper';
import Toast from '../../components/common/Toast';
import './recordEdit.less';

// 基准值：
const heightIOS5 = 340; // iPhone SE/5/5S/5C，导航条下，文本框 padding-top=30px 下的最大高度
// 修改基准值450->435:自测iPhone6p，文本框高度不合适，键盘弹起后，导航条向上移动
const heightIOS6 = 435; // iPhone 6/6s/7/6p/6sp/7p ，导航条下，文本框 padding-top=30px 下的最大高度
const height = 900; // 其他机型的高度
const prePaddingTop = 30;
// 变量：
const paddingTop = 4; // 文本框的paddingTop（文本框上面有固定文字，为美观，paddingTop由30修改为4）
const divClientHeight = 80; // 固定文字，两行的高度（考虑到内容折行，最多是两行）

const mapStateToProps = state => ({
  content: state.customer.content,
});

const mapDispatchToProps = {
  saveServiceContent: query => ({
    type: 'customer/saveServiceContent',
    payload: query || {},
  }),
};

const retuenFalse = () => false;

@connect(mapStateToProps, mapDispatchToProps)
@withRouter
export default class RecordEdit extends PureComponent {
  static propTypes = {
    content: PropTypes.string,
    saveServiceContent: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    router: PropTypes.object.isRequired,
  }

  static defaultProps = {
    content: '',
  }

  constructor(props) {
    super(props);
    const {
      content,
      location: { query },
    } = props;
    this.state = {
      value: query.editType === 'serviceRecord' ? content : '',
    };
    setResize();
  }

  componentDidMount() {
    document.querySelector('body').addEventListener('touchmove', hideKeyboard, false);
    document.querySelector('body').addEventListener('touchstart', retuenFalse, false);
  }

  componentWillUnmount() {
    document.querySelector('body').removeEventListener('touchmove', hideKeyboard, false);
    document.querySelector('body').removeEventListener('touchstart', retuenFalse, false);
  }

  @autobind
  goBack() {
    const { router, location: { query }, saveServiceContent } = this.props;
    const { value } = this.state;
    if (value.length > 100 && query.editType === 'serviceRecord') {
      Toast.fail('最多只能输入100个字');
    } else {
      if (query.editType === 'serviceRecord') {
        saveServiceContent({ content: value });
      }
      setNothing();
      router.goBack();
    }
  }

  @autobind
  hadleEdit(event) {
    this.setState({ value: event.target.value });
  }

  render() {
    const {
      router,
      location: { query },
    } = this.props;
    // 设置textArea的高度。要避免：textArea高度过高，被键盘挡到，就会触发整个webview上移
    // 此问题仅iPhone有，根据不同机型，设置不同的textArea的高度
    const clientHeight = document.documentElement.clientHeight;
    let textAreaHeight = height;
    // iPhone SE/5/5S/5C 高度为1096（不包含状态栏）
    if (clientHeight >= 1096 && clientHeight < 1294) {
      textAreaHeight = (heightIOS5 + prePaddingTop) - paddingTop - divClientHeight;
    // iPhone 6/6s/7 高度为1294（不包含状态栏）
    // iPhone 6p/6sp/7p 高度为 2148（不包含状态栏）
    } else if (clientHeight >= 1294 && clientHeight < 2148) {
      textAreaHeight = (heightIOS6 + prePaddingTop) - paddingTop - divClientHeight;
    }

    const { preContent = '', canEdit = '' } = query || {};

    if (canEdit === 'false') {
      return (
        <section className="page-recordEdit">
          <NavBar
            className="navbar"
            leftContent={<i type="iconfontfanhui2" className="iconfont icon-iconfontfanhui2" />}
            iconName={false}
            onLeftClick={() => {
              setNothing();
              router.goBack();
            }}
          >
            {query.title}
          </NavBar>
          <div className="textEdit" style={{ minHeight: `${textAreaHeight}px` }}>
            {preContent}
          </div>
        </section>
      );
    }

    return (
      <section className="page-recordEdit">
        <NavBar
          className="navbar"
          leftContent={<i type="iconfontfanhui2" className="iconfont icon-iconfontfanhui2" />}
          iconName={false}
          onLeftClick={() => this.goBack()}
        >
          {query.title}
        </NavBar>
        <div className="recordContent">
          <div className="preText">{preContent}</div>
          <textarea
            className="textEdit"
            value={this.state.value}
            style={{ height: `${textAreaHeight}px` }}
            onChange={this.hadleEdit}
          />
        </div>
      </section>
    );
  }
}
