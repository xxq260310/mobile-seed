/**
 * @file customer/CustContact.js
 *  客户联系方式
 * @author liutingting(3171214926@qq.com)
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'react-redux';
import { routerRedux } from 'dva/router';
import { autobind } from 'core-decorators';
import _ from 'lodash';

import { localConst } from '../../config';
import withNavBar from '../../components/common/withNavBar';
import PullToRefreshable from '../../components/common/PullToRefreshable';
import Icon from '../../components/common/Icon';
import ContactList from '../../components/customer/ContactList';
import './CustContactPer.less';

const LIST_KEY_ARR = localConst.LIST_KEY_ARR;
const getDataFunction = (query, loading = true) => ({
  type: 'customer/getPerContact',
  payload: query || {},
  loading,
});

const mapStateToProps = state => ({
  data: state.customer.contact,
  isLoading: state.loading.models.customer,
  empInfoData: state.global.empInfo,
  detailInfo: state.customer.detailInfo,
});

const mapDispatchToProps = {
  // 下拉刷新组件
  refresh: getDataFunction,
  push: routerRedux.push,
  // 上传刷新页面log
  reportRefresh: query => ({
    type: 'global/refreshPage',
    payload: query,
  }),
};

const mergeProps = (stateProps, dispatchProps, ownProps) => {
  const { location: { query: { custId } } } = ownProps;
  const { location: { query } } = ownProps;
  const { data } = stateProps;
  let name = '联系方式';
  if (data[custId]) {
    const { custBaseInfo: { custName = '--' } } = data[custId];
    name = custName;
  }
  return {
    refreshData: query,
    ...stateProps,
    ...dispatchProps,
    ...ownProps,
    title: <p>{name}</p>,
  };
};

@connect(mapStateToProps, mapDispatchToProps, mergeProps)
@withNavBar({ title: '联系方式', hasBack: true })
@PullToRefreshable
export default class CustContactPer extends PureComponent {
  static propTypes = {
    data: PropTypes.object.isRequired,
    refresh: PropTypes.func.isRequired,
    refreshData: PropTypes.object.isRequired,
    location: PropTypes.object.isRequired,
    empInfoData: PropTypes.object.isRequired,
    push: PropTypes.func.isRequired,
    detailInfo: PropTypes.object.isRequired,
    reportRefresh: PropTypes.func.isRequired,
    eventEmitter: PropTypes.object.isRequired,
  }

  static defaultProps = {
    data: {},
    refreshData: {},
    refresh: () => { },
    detailInfo: {},
  }

  componentWillMount() {
    const { refresh, refreshData, eventEmitter } = this.props;
    refresh(refreshData);
    eventEmitter.on('reportRefresh', this.handleEventEmitter);
  }

  componentWillUnmount() {
    const { eventEmitter } = this.props;
    eventEmitter.removeListener('reportRefresh', this.handleEventEmitter);
  }

  @autobind
  getDataModel() {
    const { data = {}, location: { query: { custId } } } = this.props;
    const dataModel = data[custId] || {};
    return dataModel;
  }

  @autobind
  getCustName() {
    const dataModel = this.getDataModel();
    if (dataModel === {} || _.isEmpty(dataModel.custBaseInfo)) return '--';
    const { custName = '--' } = dataModel.custBaseInfo || {};
    return custName;
  }

  @autobind
  getSectionArr(childLabelArr) {
    // 依据二级类型标签列表获取某类数据，
    // 如根据二级标签['身份证地址'，'家庭地址'，'单位地址'，'其他地址'],获取地址数据
    if (!childLabelArr) return [];
    const { location: { query: { custSor = '--' } } } = this.props;
    let dataModel = this.getDataModel();
    dataModel = (custSor === 'per') ? dataModel.perCustomerContactInfo : [];
    if (_.isEmpty(dataModel)) return [];

    const resultArr = [];
    childLabelArr.map((item) => {
      let temp = (dataModel[item]) ? dataModel[item] : [];
      if (item === 'idAddress') {
        temp = (!temp || Object.keys(temp).length === 0) ? [] : new Array(temp);
      }
      resultArr.push(temp);
      return true;
    });
    return resultArr;
  }

  @autobind
  handleEventEmitter() {
    const { reportRefresh } = this.props;
    reportRefresh({
      actionSource: '个人客户联系方式',
    });
  }

  @autobind
  isNull(dataArr) {
    // 判断某类数据是否为空，如地址数据
    if (!dataArr) return false;
    let bool = 0;
    dataArr.map((item) => {
      if (item instanceof Array && item.length > 0) bool++;
      return true;
    });

    return (bool > 0) ? 'have-data' : 'no-data';
  }

  @autobind
  handleEditClick(label, isMainEmp) {
    if (isMainEmp) {
      const { push, location: { query: { custId, custNumber, custSor } } } = this.props;
      // 编辑页面
      push({
        pathname: '/customer/editPerContact',
        query: {
          custId,
          type: label,
          custNumber,
          custSor,
        },
      });
    }
  }

  render() {
    const { detailInfo, location: { query: { custId } } } = this.props;
    const custData = detailInfo[custId] || {};
    const { isMainEmp } = custData;

    const dataModel = LIST_KEY_ARR.map(item => ({
      data: this.getSectionArr(item.child),
      nullstyle: this.isNull(this.getSectionArr(item.child)),
      ...item,
    }));

    const more = {
      className: 'more',
      type: 'more',
    };

    const dataShow = dataModel.map((item, index) => (
      <div className={`info ${item.nullstyle}`} key={`sec-${item.label}-${index + 1}`}>
        <h3 onClick={() => this.handleEditClick(item.label, isMainEmp)}>
          <Icon className={item.label} type={`${item.icon}`} />
          {`${item.name}`}
          {isMainEmp ? <Icon {...more} className="edit" /> : null}
        </h3>
        <ContactList
          isNull={`${item.nullstyle}`}
          type={`${item.label}`}
          labelArr={item.child}
          nameArr={item.childname}
          dataArr={item.data}
          location={this.props.location}
          empInfoData={this.props.empInfoData}
          push={this.props.push}
        />
      </div>
    ));

    return (
      <div className="cust-contact">
        <section className="other">
          {dataShow}
        </section>
      </div>
    );
  }
}
