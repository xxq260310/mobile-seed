/**
 * @file customer/CustBasic.js
 *  客户基本信息
 * @author liutingting(3171214926@qq.com)
 */

import React, { PureComponent, PropTypes } from 'react';
import { autobind } from 'core-decorators';
import { connect } from 'react-redux';
import { routerRedux } from 'dva/router';
import { List } from 'antd-mobile';
import _ from 'lodash';

import { localConst } from '../../config';
import withNavBar from '../../components/common/withNavBar';
import PullToRefreshable from '../../components/common/PullToRefreshable';
import './custbasic.less';

const Item = List.Item;
const perLabelArr = localConst.perLabelArr;
const orgLabelArr = localConst.orgLabelArr;
const getDataFunction = loading => query => ({
  type: 'customer/getCustBasic',
  payload: query || {},
  loading,
});

const updateDataFunction = loading => query => ({
  type: 'customer/updateCustBasic',
  payload: query || {},
  loading,
});

const mapStateToProps = state => ({
  data: state.customer.basic,
  systemConst: state.global.systemConst,
  isLoading: state.loading.models.customer,
  detailInfo: state.customer.detailInfo,
});
const mapDispatchToProps = {
  getData: getDataFunction(true),
  refresh: getDataFunction(false),
  updateData: updateDataFunction(false),
  push: routerRedux.push,
  // 上传刷新页面log
  reportRefresh: query => ({
    type: 'global/refreshPage',
    payload: query,
  }),
};

const mergeProps = (stateProps, dispatchProps, ownProps) => {
  const { location: { query } } = ownProps;
  return {
    refreshData: query,
    ...stateProps,
    ...dispatchProps,
    ...ownProps,
  };
};

@connect(mapStateToProps, mapDispatchToProps, mergeProps)
@withNavBar({ title: '基本信息', hasBack: true })
@PullToRefreshable
export default class CustBasic extends PureComponent {
  static propTypes = {
    data: PropTypes.object.isRequired,
    push: PropTypes.func.isRequired,
    params: PropTypes.object.isRequired,
    location: PropTypes.object.isRequired,
    getData: PropTypes.func.isRequired,
    refresh: PropTypes.func.isRequired,
    updateData: PropTypes.func.isRequired,
    refreshData: PropTypes.object.isRequired,
    systemConst: PropTypes.object.isRequired,
    detailInfo: PropTypes.object.isRequired,
    reportRefresh: PropTypes.func.isRequired,
    eventEmitter: PropTypes.object.isRequired,
  }

  static defaultProps = {
    data: {},
    push: () => { },
    detailInfo: {},
  }

  componentWillMount() {
    const { getData, refreshData, eventEmitter } = this.props;
    getData(refreshData);

    eventEmitter.on('reportRefresh', this.handleEventEmitter);
  }

  componentWillUnmount() {
    const { eventEmitter } = this.props;
    eventEmitter.removeListener('reportRefresh', this.handleEventEmitter);
  }

  @autobind
  getMapKey(key) {
    // 获取数据模型key上value
    const dataModel = this.getDataModel();
    const value = (!dataModel || !dataModel[key] || dataModel[key] === '--') ? '--' : dataModel[key];
    return value;
  }

  @autobind
  getCustIcon() {
    // 获取顶部Icon
    const { location: { query: { custSor } } } = this.props;
    const dataModel = this.getDataModel();
    if (_.isEmpty(dataModel)) return null;
    const type = custSor || 'per';
    let icon = '';
    if (type === 'per') {
      icon = (!dataModel || dataModel.custGender === '男') ? 'touxiang' : 'nvxing';
    } else {
      icon = 'jigou';
    }
    return icon;
  }

  @autobind
  getDataModel() {
    // 获取数据
    const { data, location: { query: { custSor, custId } } } = this.props;
    const type = custSor || 'per';
    const temp = data[custId] || {};
    if (temp === {}) return {};
    const dataModel = (type === 'per') ? temp.customerInfoPer : temp.customerInfoOrg;
    return dataModel || {};
  }

  @autobind
  handleEventEmitter() {
    const { reportRefresh } = this.props;
    reportRefresh({
      actionSource: '客户基本信息',
    });
  }

  @autobind
  contactData(arr, obj = {}) {
    // 合并标签数组及接口数据
    const tempArr = arr;
    arr.map((item, index) => {
      let value = (!obj || !obj[item.type]) ? '--' : obj[item.type];
      if (item.type === 'idValDate' || item.type === 'foundTime' || item.type === 'openTime' || item.type === 'lastCommission') {
        const timeArray = [];
        if (value) {
          if (value.length > 10) {
            value = value.slice(0, 10);
          }
          value.replace(/-/g, '/').split('/').forEach((d, i) => {
            if (i === 2) {
              timeArray.unshift(d);
            } else {
              timeArray.push(d);
            }
          });

          value = timeArray.join('/');
        }
      }
      if (item.type === 'regAsset') value = (!value || isNaN(Number(value))) ? '0.00' : Number(value).toFixed(2);
      tempArr[index].value = value;
      tempArr[index].key = index + 1;
      return true;
    });
    return tempArr;
  }

  @autobind
  generatorState(type, value, custId) {
    const { systemConst, updateData } = this.props;
    const stateObj = {
      selectValue: value,
    };
    if (type === 'degree') {
      return {
        ...stateObj,
        options: systemConst.PROF_DEGREE,
        onSave: (v) => {
          updateData(
            {
              custId,
              degreeCode: v.selectKey,
            },
          );
        },
      };
    } else if (type === 'merriage') {
      return {
        ...stateObj,
        options: systemConst.MARITAL_STATUS,
        onSave: (v) => {
          updateData(
            {
              custId,
              merriageCode: v.selectKey,
            },
          );
        },
      };
    }
    return stateObj;
  }

  /**
   * 跳转基本信息编辑页面
   */
  @autobind
  handleClick(type, value, arrow, isMainEmp) {
    if (arrow && isMainEmp) {
      const { push, location: { query: { custId, custNumber, custSor } } } = this.props;
      const state = this.generatorState(type, value, custId);
      push({
        pathname: '/customer/CustBasicEdit',
        query: {
          custId,
          custNumber,
          custSor,
          seltype: 'selRadio',
          titleName: '编辑基本信息',
        },
        state,
      });
    }
  }

  render() {
    const { detailInfo, location: { query: { custSor, custNumber, custId } } } = this.props;
    const custData = detailInfo[custId] || {};
    const { isMainEmp } = custData;
    const dataModel = this.getDataModel();
    const labelArr = (custSor === 'per') ? perLabelArr : orgLabelArr;
    const custIcon = this.getCustIcon();
    const custName = this.getMapKey('custName');
    const custNum = (!custNumber || custNumber === 'null') ? '--' : custNumber;
    const arr = this.contactData(labelArr, dataModel);
    const renderHead = obj => (
      <section className="baseHead">
        <i className={`headIco ${custSor || ''}`} />
        <div className="headInfo">
          <p className="custName">{obj.name}</p>
          <p className="custNum">{obj.number}</p>
        </div>
      </section>
    );
    const itemShow = arr.map(item => (
      item.arrow && isMainEmp ?
        <Item
          arrow={isMainEmp ? item.arrow : ''}
          className={item.type}
          key={item.key}
          extra={<div className="text" ref={div => (this[item.type] = div)}>{item.value}</div>}
          onClick={() => { this.handleClick(item.type, item.value, item.arrow, isMainEmp); }}
        >
          {item.name}
        </Item>
        :
        <Item
          arrow={''}
          className={item.type}
          key={item.key}
          extra={<div className="text" ref={div => (this[item.type] = div)}>{item.value}</div>}
        >
          {item.name}
        </Item>
    ));
    return (
      <div className="custBasic">
        {renderHead({ icon: custIcon, name: custName, number: custNum })}
        <List className="cust-basic-list">
          {itemShow}
        </List>

      </div>
    );
  }
}
