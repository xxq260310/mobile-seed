import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'react-redux';
import { autobind } from 'core-decorators';
import _ from 'lodash';

import withNavBar from '../../components/common/withNavBar';
import PullToRefreshable from '../../components/common/PullToRefreshable';
import BusinessList from '../../components/customer/BusinessList';

const getDataFunction = loading => query => ({
  type: 'customer/getBusinessList',
  payload: query || {},
  loading,
});

const mapStateToProps = state => ({
  data: state.customer.custBusinessInfo,
  isLoading: state.loading.models.customer,
});
const mapDispatchToProps = {
  getData: getDataFunction(true),
  refresh: getDataFunction(false),
  // 上传刷新页面log
  reportRefresh: query => ({
    type: 'global/refreshPage',
    payload: query,
  }),
};

const mergeProps = (stateProps, dispatchProps, ownProps) => {
  const { location: { query } } = ownProps;
  return {
    ...query,
    ...stateProps,
    ...dispatchProps,
    ...ownProps,
  };
};

@connect(mapStateToProps, mapDispatchToProps, mergeProps)
@withNavBar({ title: '已开通业务', hasBack: true })
@PullToRefreshable
export default class CustBusinessInfo extends PureComponent {

  static propTypes = {
    data: PropTypes.object.isRequired,
    location: PropTypes.object.isRequired,
    getData: PropTypes.func.isRequired,
    refresh: PropTypes.func.isRequired,
    reportRefresh: PropTypes.func.isRequired,
    eventEmitter: PropTypes.object.isRequired,
  }

  static defaultProps = {
  }

  constructor(props) {
    super(props);
    this.state = {
      isLoaded: false,
    };
  }

  componentWillMount() {
    const { getData, data, location: { query: { custSor, custId } }, eventEmitter } = this.props;
    eventEmitter.on('reportRefresh', this.handleEventEmitter);
    // <缓存策略> 相同的custId对应的数据不存在，则发起请求，反之，不发请求
    if (_.isEmpty(data[custId])) {
      getData({ custSor, custId });
    } else {
      this.setState({ isLoaded: true });
    }
  }

  componentWillReceiveProps(nextProps) {
    const { data } = nextProps;
    if (data !== this.props.data) {
      this.setState({ isLoaded: true });
    }
  }

  componentWillUnmount() {
    const { eventEmitter } = this.props;
    eventEmitter.removeListener('reportRefresh', this.handleEventEmitter);
  }

  @autobind
  handleEventEmitter() {
    const { reportRefresh } = this.props;
    reportRefresh({
      actionSource: '已开通业务',
    });
  }

  render() {
    const { data, location: { query: { custId } } } = this.props;
    const { isLoaded } = this.state;
    const { notOpenedServiceList = [], openedServiceList = [] } = data[custId] || {};
    return (
      <BusinessList
        notOpenArr={notOpenedServiceList}
        openArr={openedServiceList}
        isLoaded={isLoaded}
      />
    );
  }
}
