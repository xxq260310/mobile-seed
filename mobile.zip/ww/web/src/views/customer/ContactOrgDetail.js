/**
 * @file customer/ContactOrgDetail.js
 *  机构客户联系方式
 * @author liutingting(3171214926@qq.com)
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'react-redux';
import { routerRedux } from 'dva/router';
import { autobind } from 'core-decorators';
import _ from 'lodash';
import moment from 'moment';
import 'moment/locale/zh-cn';
import { Flex, Modal } from 'antd-mobile';

import withNavBar from '../../components/common/withNavBar';
import Icon from '../../components/common/Icon';
import Toast from '../../components/common/Toast';
import { callPhone } from '../../utils/cordova';
import { checkFormate, isAndorid } from '../../utils/helper';
import './ContactOrgDetail.less';

const alert = Modal.alert;

const YESNO = ['否', '是'];

const updateDataFun = loading => query => ({
  type: 'customer/updatePersonnelInfo',
  payload: query || {},
  loading,
});

const mapStateToProps = state => ({
  data: state.customer.contactList,
  empInfoData: state.global.empInfo,
  systemConstData: state.global.systemConst,
  detailInfo: state.customer.detailInfo,
  // 是否授权可以拨打电话
  canCall: state.global.canCall,
});

const mapDispatchToProps = {
  push: routerRedux.push,
  goBack: routerRedux.goBack,
  updatePersonnelInfo: updateDataFun(true),
  delContactOrg: query => ({
    type: 'customer/delContactOrg',
    payload: query,
  }),
  saveRecordPageNeedfulData: query => ({
    type: 'mission/saveRecordPageNeedfulDataSuccess',
    payload: query,
  }),
};

function showMessage(msg) {
  Toast.show(msg, 1);
}

@connect(mapStateToProps, mapDispatchToProps)
@withNavBar({ title: '联系人详情', hasBack: true })
export default class ContactOrgDetail extends PureComponent {
  static propTypes = {
    data: PropTypes.object,
    location: PropTypes.object.isRequired,
    empInfoData: PropTypes.object.isRequired,
    push: PropTypes.func.isRequired,
    updatePersonnelInfo: PropTypes.func.isRequired,
    goBack: PropTypes.func.isRequired,
    delContactOrg: PropTypes.func.isRequired,
    systemConstData: PropTypes.object.isRequired,
    detailInfo: PropTypes.object.isRequired,
    canCall: PropTypes.bool.isRequired,
    saveRecordPageNeedfulData: PropTypes.func.isRequired,
  }

  static defaultProps = {
    data: {},
  }

  @autobind
  getData(rowId) {
    const { data = {}, location: { query: { custId = '--' } } } = this.props;
    if (data === {} || _.isEmpty(data[custId])) return null;
    const dataModel = data[custId].orgCustomerContactInfoList || [];
    if (!(dataModel instanceof Array) || (dataModel instanceof Array && dataModel.length < 1)) {
      return null;
    }
    let result = null;
    dataModel.map((item) => {
      if (item.rowId === rowId) {
        result = item;
      }
      return true;
    });
    return result;
  }

  // 电话联系组件
  @autobind
  handleTelephoneContactClick(contactValue) {
    const { canCall } = this.props;
    // 只有安卓手机和授权永华才能拨打电话
    if (canCall && isAndorid()) {
      // 调用native拨打电话
      callPhone({ number: contactValue }, this.handleServiceRecord);
    }
  }

  // 打完电话的回调，处理跳转服务记录相关数据等
  @autobind
  handleServiceRecord(callDuration) {
    const {
      push,
      location: { query: { custId, custName, custNumber } },
      saveRecordPageNeedfulData,
    } = this.props;
    // 服务时间
    this.zhNow = moment().locale('zh-cn').utcOffset(8);
    const serveDate = this.zhNow.format('YYYY年MM月DD日 HH:mm');
    // 保存服务记录页面所需要的数据到state中
    // serveWay: 服务方式,打电话就是电话，直接完成则服务方式在服务记录页面选择
    // serveDate: 服务日期，callDuration: 通话时长
    // eventFlowIdList: 无任务则不传
    // custType: 此页面为机构人联系页面，默认为org
    saveRecordPageNeedfulData({
      custId,
      custType: 'org',
      custName,
      custNumber,
      serveWay: '电话',
      serveDate,
      callDuration,
    });
    push({
      pathname: '/customer/Record',
      query: {
        custId,
        custType: 'org',
      },
    });
  }

  linkTo(event, arrRowId, title, op, defaultValue, type = '', pathname = '/common') {
    if (event.target.className === 'send-email') {
      return;
    }
    const { isCellphone, isTelephone, isEmail } = checkFormate;
    const {
      detailInfo,
      updatePersonnelInfo,
      location: { query: { custNumber, custId, rowId, mainFlag } },
    } = this.props;
    if (!detailInfo[custId].isMainEmp) {
      return;
    }
    this.props.push({
      pathname,
      query: {
        type,
        title: encodeURIComponent(title),
        defaultValue: encodeURIComponent(defaultValue),
      },
      state: {
        onSave: (value) => {
          const num = custNumber === 'null' ? '' : custNumber;
          if (op === 'name' && value && value.length > 50) {
            showMessage('联系人姓名输入不能超过50个字符');
            return;
          }
          if (op === 'cellPhones' && value && !isCellphone(value)) {
            showMessage('手机号码格式不正确');
            return;
          }
          if (op === 'workTels' && value && !isCellphone(value) && !isTelephone(value)) {
            showMessage('单位电话格式不正确');
            return;
          }
          if (op === 'homeTels' && value && !isCellphone(value) && !isTelephone(value)) {
            showMessage('住宅电话格式不正确');
            return;
          }
          if (op === 'emailAddresses' && value && (!isEmail(value) || value.indexOf(' ') !== -1)) {
            showMessage('邮箱地址格式不正确');
            return;
          }
          if (op === 'emailAddresses' && value && value.length > 50) {
            showMessage('邮箱地址输入不能超过50个字符');
            return;
          }
          updatePersonnelInfo({
            mainFlag,
            num,
            rowId,
            arrRowId,
            op,
            value,
            custId,
          });
        },
      },
    });
  }

  // 删除联系人
  @autobind
  handleDel() {
    alert('提示', '确认要删除该联系人？', [
      { text: '否', onPress: () => console.log('cancel') },
      { text: '是', onPress: () => { this.delInfo(); } },
    ]);
  }

  @autobind
  delInfo() {
    const { delContactOrg, location: { query: { custNumber, custId, rowId } } } = this.props;
    const dataModel = this.getData(rowId);
    const { name } = dataModel;
    delContactOrg({
      custId,
      custNumber,
      custSor: 'org',
      name,
      rowId,
      validFlag: false,
    });
  }

  linkToTwo(type, value, title) {
    const {
      push,
      detailInfo,
      systemConstData,
      updatePersonnelInfo,
      location: { query: { rowId, custNumber, custId } },
    } = this.props;
    if (!detailInfo[custId].isMainEmp) {
      return;
    }
    push({
      pathname: '/customer/CustBasicEdit',
      query: {
        seltype: 'selRadio',
        titleName: title,
      },
      state: {
        selectValue: type === 'custRela' ? value : YESNO[+value],   // eslint-disable-line
        options: type === 'custRela' ? systemConstData['206'] : YESNO,
        onSave: (v) => {
          const num = custNumber === 'null' ? '' : custNumber;
          updatePersonnelInfo({
            num,
            rowId,
            op: type,
            value: v,
            custId,
          });
        },
      },
    });
  }

  @autobind
  renderRow(arr, label = '信息', icon = 'viewgallery', op) {
    const { detailInfo, location: { query: { custId } } } = this.props;
    if (!arr || !(arr instanceof Array) || (arr instanceof Array && arr.length < 1)) {
      return (
        <li
          className="list-item"
          onClick={
            (event) => {
              if (_.includes(['cellPhones', 'workTels', 'homeTels'], op)) {
                this.linkTo(event, '', label, op, '', 'tel');
                return;
              }
              this.linkTo(event, '', label, op, '');
            }
          }
        >
          <Flex direction="row" align="center">
            <Icon className="" type={icon} />
            <Flex className="list-content" justify="between">
              <span className="label">{label}</span>
              <p>暂无信息</p>
              {detailInfo[custId].isMainEmp ? <Icon className="more" type="more" /> : null}
            </Flex>
          </Flex>
        </li>
      );
    }
    return arr.map((item, index) => (

      <li
        className={`list-item ${icon}`}
        key={`${icon}-${index + 1}`}
        onClick={(event) => {
          if (_.includes(['cellPhones', 'workTels', 'homeTels'], op)) {
            this.linkTo(event, item.rowId, label, op, item.contactValue, 'tel');
            return;
          }
          this.linkTo(event, item.rowId, label, op, item.contactValue);
        }}
      >
        <Flex direction="row" align="center">
          <Icon className="" type={icon} />
          <Flex className={icon === 'email' ? 'nobt list-content' : 'list-content'} justify="between">
            <span className="label">{label}</span>
            {detailInfo[custId].isMainEmp ? <Icon className="more" type="more" /> : null}
            {icon === 'email' ? <p>{item.contactValue}</p> : null}
          </Flex>
        </Flex>
      </li>
    ));
  }

  // 渲染联系方式
  @autobind
  renderContactValueRow(arr) {
    const { canCall } = this.props;
    let phoneNumberStyle = 'list-item phone-number';
    // 授权并且是安卓用户电话显示为蓝色可拨号状态，否则为灰色状态
    if (canCall && isAndorid()) {
      phoneNumberStyle = 'list-item phone-number can-call';
    }
    if (!_.isEmpty(arr)) {
      return arr.map(item => (
        <li
          className={phoneNumberStyle}
          onClick={() => this.handleTelephoneContactClick(item.contactValue)}
        >
          <Flex direction="row" align="center">
            <Flex className="list-content">
              <p className="contactValue">{item.contactValue}</p>
            </Flex>
          </Flex>
        </li>
      ));
    }
    return null;
  }

  render() {
    const { detailInfo, location: { query: { custId, rowId = '--' } } } = this.props;
    const dataModel = this.getData(rowId);
    if (!dataModel) return null;
    const { name = '--', custRela = '--', mainFlag } = dataModel;
    const renderRow = this.renderRow;
    const phoneArr = dataModel.cellPhones;
    const workTelArr = dataModel.workTels;
    const homeTelArr = dataModel.homeTels;
    const emailArr = dataModel.emailAddresses;
    return (
      <div className="contact-org-detail">
        <section className="contain">
          <ul className="list-container">
            <li className="list-item" onClick={event => this.linkTo(event, '', '姓名', 'name', name)}>
              <Flex direction="row" align="center">
                <Icon className="" type="account" />
                <Flex className="list-content" justify="between">
                  <span className="label">联系人姓名</span>
                  <p>{name}</p>
                  {detailInfo[custId].isMainEmp ? <Icon className="more" type="more" /> : null}
                </Flex>
              </Flex>
            </li>
            <li className="list-item" onClick={() => this.linkToTwo('custRela', custRela, '人员类型')}>
              <Flex direction="row" align="center">
                <Icon className="" type="viewgallery" />
                <Flex className="list-content" justify="between">
                  <span className="label">人员类型</span>
                  <p>{custRela}</p>
                  {detailInfo[custId].isMainEmp ? <Icon className="more" type="more" /> : null}
                </Flex>
              </Flex>
            </li>
            <li className="list-item" onClick={() => this.linkToTwo('mainFlag', mainFlag, '是否主要')}>
              <Flex direction="row" align="center">
                <Icon className="" type="favorite" />
                <Flex className="list-content" justify="between">
                  <span className="label">是否主要</span>
                  <p>{(mainFlag === true) ? '是' : '否'}</p>
                  {detailInfo[custId].isMainEmp ? <Icon className="more" type="more" /> : null}
                </Flex>
              </Flex>
            </li>
            {renderRow(phoneArr, '手机号码', 'mobilephone', 'cellPhones')}
            {this.renderContactValueRow(phoneArr)}
            {renderRow(workTelArr, '单位电话', 'phone', 'workTels')}
            {this.renderContactValueRow(workTelArr)}
            {renderRow(homeTelArr, '住宅电话', 'phone', 'homeTels')}
            {this.renderContactValueRow(homeTelArr)}
            {renderRow(emailArr, '电子邮件', 'email', 'emailAddresses')}
            {
              detailInfo[custId].isMainEmp ? (
                <Flex align="center" className="del-btn" onClick={this.handleDel}>
                  <Icon
                    className="del deleteIcon"
                    type="delete"
                  />
                  <span>删除联系人</span>
                </Flex>
              ) : null
            }
          </ul>
        </section>
      </div>
    );
  }
}
