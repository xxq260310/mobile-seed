/**
 * @file mission/Home.js
 * @author fengwencong
 */

import React, { PureComponent, PropTypes } from 'react';
import { connect } from 'dva';
import { withRouter, routerRedux } from 'dva/router';
import { autobind } from 'core-decorators';
import { Drawer } from 'antd-mobile';
import _ from 'lodash';

import {
  addBackbuttonListener,
  removeBackbuttonListener,
} from '../../utils/cordova';
import CenterHeader from '../../components/mission/CenterHeader';
import CenterList from '../../components/mission/CenterList';
import Filter from '../../components/mission/Filter';
import './home.less';

const actionType = 'mission/getCenter';

// loading表示是否显示loading toast
const getCenterFunction = loading => query => ({
  type: actionType,
  payload: query || {},
  loading,
});

const mapStateToProps = state => ({
  missionCenter: state.mission.missionCenter,
  isLoading: state.loading.effects[actionType],
});

const mapDispatchToProps = {
  getCenter: getCenterFunction(true),
  // 提供给下拉刷新组件
  refresh: getCenterFunction(false),
  // 任务详情接口取不到任务详情的数据
  // 所以日志上报需要从列表项中拿数据，手动上报
  reportDetail: query => ({
    type: 'mission/reportDetail',
    payload: query,
  }),
  // 上传刷新页面log
  reportRefresh: query => ({
    type: 'global/refreshPage',
    payload: query,
  }),
  openFilter: query => ({
    type: 'mission/openFilter',
    payload: query,
  }),
  push: routerRedux.push,
  replace: routerRedux.replace,
  // 清除纪录展示任务详情引导页的flagarr
  removeClickEvent: () => ({
    type: 'mission/removeFlagArraySuccess',
  }),
};

const appContainer = document.querySelector('#app');

@connect(mapStateToProps, mapDispatchToProps)
@withRouter
export default class MissionHome extends PureComponent {
  static propTypes = {
    missionCenter: PropTypes.object,
    getCenter: PropTypes.func,
    location: PropTypes.object,
    replace: PropTypes.func,
    push: PropTypes.func.isRequired,
    reportDetail: PropTypes.func.isRequired,
    refresh: PropTypes.func.isRequired,
    isLoading: PropTypes.bool,
    reportRefresh: PropTypes.func.isRequired,
    openFilter: PropTypes.func.isRequired,
    removeClickEvent: PropTypes.func.isRequired,
  }

  static defaultProps = {
    missionCenter: {},
    getCenter: () => { },
    location: {},
    replace: () => { },
    isLoading: false,
  }

  constructor(props) {
    super(props);
    this.state = {
      open: false,
      position: 'right',
    };
  }

  componentWillMount() {
    const { missionCenter, location: { query }, removeClickEvent } = this.props;
    if (_.isEmpty(missionCenter) || _.isEmpty(missionCenter.motTaskList)) {
      this.props.getCenter({
        ...query,
      });
    }
    appContainer.addEventListener('touchmove', this.handleTouch, false);
    removeClickEvent();
  }

  componentWillUnmount() {
    // 添加的针对Android虚拟Backbutton事件的处理
    removeBackbuttonListener();
    appContainer.removeEventListener('touchmove', this.handleTouch, false);
  }

  @autobind
  onOpenChange() {
    const { open } = this.state;
    const { openFilter } = this.props;
    this.setState(
      { open: !open },
      () => {
        if (open) {
          removeBackbuttonListener();
        } else {
          openFilter({
            actionSource: '任务列表',
          });
          // 打开抽屉的时候状态open = false
          addBackbuttonListener(this.handleBackbutton);
        }
      },
    );
  }

  @autobind
  handleBackbutton() {
    const { open } = this.state;
    if (open) {
      this.setState({ open: !open });
    }
  }

  @autobind
  handleTouch(event) {
    const { open } = this.state;
    if (open) {
      event.preventDefault();
    }
  }

  render() {
    const {
      missionCenter,
      refresh,
      location,
      replace,
      push,
      reportDetail,
      isLoading,
      reportRefresh,
    } = this.props;
    const sidebar = (
      <Filter
        onOpenChange={this.onOpenChange}
        location={location}
        replace={replace}
      />
    );
    const drawerProps = {
      open: this.state.open,
      position: this.state.position,
      onOpenChange: this.onOpenChange,
    };
    const bar = document.querySelector('.am-tab-bar-bar');
    const footerHeight = bar ? bar.offsetHeight : 0;
    return (
      <section className="page-mission">
        <CenterHeader
          data={missionCenter}
          onOpenChange={this.onOpenChange}
        />
        <CenterList
          data={missionCenter}
          getCenter={refresh}
          location={location}
          replace={replace}
          push={push}
          reportDetail={reportDetail}
          isFetching={isLoading}
          onOpenChange={this.onOpenChange}
          reportRefresh={reportRefresh}
        />
        <Drawer
          className="missionDrawer"
          sidebar={sidebar}
          style={{ maxHeight: document.documentElement.clientHeight - footerHeight }}
          dragHandleStyle={{ display: 'none' }}
          touch={false}
          {...drawerProps}
        >
          .
        </Drawer>
      </section>
    );
  }
}
