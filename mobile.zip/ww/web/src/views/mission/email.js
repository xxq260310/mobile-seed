/**
 * @file views/mission/email.js
 * 邮件发送
 * @author wangjunjun
 */

import React, { PropTypes, PureComponent } from 'react';
import { connect } from 'react-redux';
import { routerRedux, withRouter } from 'dva/router';
import { autobind } from 'core-decorators';
import { List, InputItem, TextareaItem, Modal } from 'antd-mobile';
import { createForm } from 'rc-form';

import NavBar from '../../components/common/NavBar';
import Toast from '../../components/common/Toast';
import helper from '../../utils/helper';
import './email.less';

/**
 *
 * 判断文本中是否包含 emoji
 */
const isEmojiCharacter = (substring) => {
  for (let i = 0; i < substring.length; i++) {
    const hs = substring.charCodeAt(i);
    if (hs >= 0xd800 && hs <= 0xdbff) {
      if (substring.length > 1) {
        const ls = substring.charCodeAt(i + 1);
        const uc = ((hs - 0xd800) * 0x400) + (ls - 0xdc00) + 0x10000;
        if (uc >= 0x1d000 && uc <= 0x1f77f) {
          return true;
        }
        if (uc >= 0x1f910 && uc <= 0x1f918) {
          return true;
        }
        if (uc >= 0x1f980 && uc <= 0x1f984) {
          return true;
        }
        if (uc === 0x1f9c0) {
          return true;
        }
      }
    } else if (substring.length > 1) {
      const ls = substring.charCodeAt(i + 1);
      if (ls === 0x20e3 || ls === 0xfe0f || ls === 0xd83c) {
        return true;
      }
    } else if (hs >= 0x2100 && hs <= 0x27ff && hs !== 0x263b) {
      return true;
    } else if (hs >= 0x2B05 && hs <= 0x2b07) {
      return true;
    } else if (hs >= 0x2934 && hs <= 0x2935) {
      return true;
    } else if (hs >= 0x3297 && hs <= 0x3299) {
      return true;
    } else if (hs === 0xa9 || hs === 0xae || hs === 0x303d || hs === 0x3030 || hs === 0x2b55
                      || hs === 0x2b1c || hs === 0x2b1b || hs === 0x2b50 || hs === 0x231a) {
      return true;
    }
  }
  return false;
};

const mapStateToProps = state => ({
  isSendSuccess: state.mission.isSendSuccess,
  empInfo: state.global.empInfo,
  receiver: state.mission.email,
  isSaving: state.mission.isSavingEmail,
});

const mapDispatchToProps = {
  push: routerRedux.push,
  goBack: routerRedux.goBack,
  sendMail: query => ({
    type: 'mission/sendMail',
    payload: query,
  }),
  getReceiverMailAddr: query => ({
    type: 'mission/getReceiverMailAddr',
    payload: query,
  }),
};

@connect(mapStateToProps, mapDispatchToProps)
@withRouter
@createForm()
export default class Email extends PureComponent {

  static propTypes = {
    title: PropTypes.string.isRequired,
    receiver: PropTypes.string.isRequired,
    form: PropTypes.object.isRequired,
    isSendSuccess: PropTypes.bool.isRequired,
    sendMail: PropTypes.func.isRequired,
    goBack: PropTypes.func.isRequired,
    empInfo: PropTypes.object.isRequired,
    getReceiverMailAddr: PropTypes.func.isRequired,
    isSaving: PropTypes.bool.isRequired,
    push: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
  };

  static defaultProps = {
    title: '邮件',
  };

  componentWillMount() {
    const { getReceiverMailAddr, location: { query: { custNumber } } } = this.props;
    getReceiverMailAddr({
      custNumber,
    });
  }

  componentWillReceiveProps(nextProps) {
    const { isSaving, isSendSuccess } = nextProps;
    if (isSaving === false && this.props.isSaving === true && isSendSuccess === true) {
      this.isCompleteAlert();
    }
  }

  isCompleteAlert() {
    const alert = Modal.alert;
    const { push, goBack, location: { query: { custRowId, custType, eventFlowId } } } = this.props;
    alert('确认', '是否完成任务 ？', [
      { text: '否', onPress: () => goBack() },
      { text: '是', onPress: () => push(`/mission/ServiceImplement?from=0&custRowId=${custRowId}&custType=${custType}&eventFlowId=${eventFlowId}`), style: { fontWeight: 'bold' } },
    ]);
  }

  haveEmojiAlert(submitParams, okCallback, cancelCallback) {
    const alert = Modal.alert;
    alert('提示', '邮件中发送表情可能导致乱码，是否确认发送 ？', [
      { text: '否', onPress: () => { cancelCallback(); } },
      { text: '是', onPress: () => { okCallback(submitParams); }, style: { fontWeight: 'bold' } },
    ]);
  }

  @autobind
  handleSendClick() {
    const { sendMail, receiver, form: { getFieldValue } } = this.props;
    const obj = {
      receiverAddress: receiver,
      subject: getFieldValue('mailTitle'),
      content: getFieldValue('mailContent'),
    };
    if (!obj.subject) {
      Toast.fail('邮件的主题不能为空！', 1);
      return;
    }
    if (!obj.content) {
      Toast.fail('邮件的内容不能为空！', 1);
      return;
    }
    if (isEmojiCharacter(obj.subject) || isEmojiCharacter(obj.content)) {
      this.haveEmojiAlert(obj, sendMail, () => { });
    } else {
      sendMail(obj);
    }
  }

  render() {
    const { title, receiver, empInfo: { emailAddr }, goBack } = this.props;
    const { getFieldProps } = this.props.form;
    const { getAvailableHeight } = helper;
    const Item = List.Item;
    const renderSendButton = obj => (
      <div className="btn-send" onClick={this.handleSendClick}>
        {obj.name}
      </div>
    );
    return (
      <div className="page-email" style={{ height: getAvailableHeight() }}>
        <NavBar
          iconName={false}
          leftContent={'取消'}
          onLeftClick={goBack}
          rightContent={renderSendButton({ name: '发送' })}
        >
          {title}
        </NavBar>
        <List>
          <Item extra={receiver}>收件人:</Item>
          <Item extra={emailAddr}>发件人:</Item>
          <InputItem
            {...getFieldProps('mailTitle')}
            clear
            placeholder="在此输入邮件标题"
            autoFocus
          >主&nbsp;&nbsp;&nbsp;题:</InputItem>
          <TextareaItem
            {...getFieldProps('mailContent')}
            autoHeight
            placeholder="在此输入您的邮件内容..."
          />
        </List>
      </div>
    );
  }
}
