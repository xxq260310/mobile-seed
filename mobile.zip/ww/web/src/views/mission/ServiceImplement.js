/**
 * @file customer/ServiceImplement.js
 * 服务实施
 * @author sunweibin(695170566.qq.com)
 */

import React, { PureComponent, PropTypes } from 'react';
import { autobind } from 'core-decorators';
import { connect } from 'react-redux';
import { withRouter, routerRedux } from 'dva/router';
import { Grid, Radio, WhiteSpace, List, TextareaItem } from 'antd-mobile';
import { createForm } from 'rc-form';

import { localConst } from '../../config';
import NavBar from '../../components/common/NavBar';
import Toast from '../../components/common/Toast';
import Icon from '../../components/common/Icon';
import './ServiceImplement.less';

const SERVICEIMPLEMENT_ICONS = localConst.SERVICEIMPLEMENT_ICONS;

// 从state里面获取数据
const mapStateToProps = state => ({
  data: state.global.empInfo,
  isSavingRecord: state.mission.isSavingRecord,
});
// 将传送的数据写入props
const mapDispatchToProps = {
  go: routerRedux.go,
  saveRecord: query => ({
    type: 'mission/saveSIRecord',
    payload: query || {},
  }),
};

@connect(mapStateToProps, mapDispatchToProps)
@withRouter
class ServiceImplement extends PureComponent {

  static propTypes = {
    form: PropTypes.object.isRequired,
    data: PropTypes.object,
    location: PropTypes.object,
    title: PropTypes.string.isRequired,
    isSavingRecord: PropTypes.bool.isRequired,
    go: PropTypes.func.isRequired,
    saveRecord: PropTypes.func.isRequired,
  }

  // location中需要添加一个值判断从何处跳转本页面
  static defaultProps = {
    data: {},
    location: {},
    title: '服务实施',
  }

  constructor(props) {
    super(props);
    this.state = { radio: 4 };
  }

  componentWillReceiveProps(nextProps) {
    const { isSavingRecord } = nextProps;
    // why?
    if (isSavingRecord === false && this.props.isSavingRecord === true) {
      this.successToast();
    }
  }

  @autobind
  successToast() {
    Toast.success('保存成功', 3, () => {
      const { from = '1' } = this.props.location.query;
      if (from === '0') {
        this.props.go(-2);
      } else {
        this.props.go(-1);
      }
    });
  }

  @autobind
  handleProcessMot() {
    const { saveRecord, form: { getFieldValue }, data } = this.props;
    const { location: { query: { custRowId, custType, eventFlowId } } } = this.props;
    const serviceChannel = SERVICEIMPLEMENT_ICONS[this.state.radio].word;
    // 新接口获取参数值
    const empRowId = data.rowId;
    let serviceRecord = '';
    let custCallBack = '';
    // 对数据进行处理
    if (getFieldValue('serviceRecord')) {
      serviceRecord = getFieldValue('serviceRecord');
    }
    if (getFieldValue('custCallBack')) {
      custCallBack = getFieldValue('custCallBack');
    }
    // 此处需要传送参数
    saveRecord({
      custId: custRowId,
      custType,
      action: 'new',
      taskProcessDtoList: [
        {
          id: '',
          empId: empRowId,
          contactId: custRowId,
          serviceRecord,
          serviceChannel,
          serviceType: '',
          serviceContent: '',
          custCallBack,
          actionType: '',
          eventFlowId,
          accountId: '',
          doneFlag: 'Y',
        },
      ],
    });
  }

  // 点击头部保存按钮的处理程序
  @autobind
  handleRightSaveButton() {
    // 此处需要进行新的逻辑处理
    this.handleProcessMot();
  }

  @autobind
  handleLeftGoBackButtonClick() {
    const { go } = this.props;
    const from = this.state.from;
    console.log(from);
    if (from === 0) {
      go(-2);
    } else {
      go(-1);
    }
  }

  @autobind
  handleRadioChecked(v) {
    // 改变整个页面的Radio
    this.setState({
      radio: v,
    });
  }

  handleInputFirstFocus() {
    window.scrollTop = 0;
    const container = document.getElementById('si-container');
    container.style.top = '-320px';
  }
  handleInputBlur() {
    const container = document.getElementById('si-container');
    container.style.top = '0';
  }
  handleInputSecondFocus() {
    window.scrollTop = 0;
    const container = document.getElementById('si-container');
    container.style.top = '-650px';
  }


  render() {
    const { title } = this.props;
    const value = this.state.radio;
    const { getFieldProps } = this.props.form;

    // 渲染头部的右侧保存按钮
    const renderRightButton = obj => (
      <div className="right-button" onClick={this.handleRightSaveButton}>
        {obj.buttonName}
      </div>
    );

    // 渲染水平分割线
    const renderHorizontalDivider = () => (
      <div
        style={{
          width: '100%',
          height: '1px',
          backgroundColor: '#ddd',
        }}
      />
    );

    return (
      <div className="page-service-implement">
        <NavBar
          iconName={'iconfontfanhui2'}
          onLeftClick={this.handleLeftGoBackButtonClick}
          rightContent={renderRightButton({ buttonName: '保存' })}
        >
          {title}
        </NavBar>
        <div id="si-container" className="container container-scrollable">
          <div className="container-content">
            <Grid
              data={SERVICEIMPLEMENT_ICONS}
              columnNum={3}
              hasLine={false}
              renderItem={dataItem => (
                <Radio
                  className="si-radio"
                  name={'serviceImplementType'}
                  defaultChecked={false}
                  key={dataItem.value}
                  checked={value === dataItem.value}
                  onClick={() => this.handleRadioChecked(dataItem.value)}
                >
                  <div className="si-grid-item-wrapper" onClick={() => this.handleRadioChecked(dataItem.value)}>
                    <Icon type={dataItem.icon} className="si-grid-item-icon" />
                    <div className="si-grid-item-text">{dataItem.serviceName}</div>
                  </div>
                </Radio>
              )}
            />
            <WhiteSpace size="md" />
            <List renderHeader={() => '服务记录'}>
              <TextareaItem
                {...getFieldProps('serviceRecord')}
                rows={4}
                onFocus={() => this.handleInputFirstFocus()}
                onBlur={() => this.handleInputBlur()}
              />
            </List>
            {renderHorizontalDivider()}
            <List renderHeader={() => '客户反馈'}>
              <TextareaItem
                {...getFieldProps('custCallBack')}
                rows={4}
                onFocus={() => this.handleInputSecondFocus()}
                onBlur={() => this.handleInputBlur()}
              />
            </List>
          </div>
        </div>
      </div>
    );
  }
}

export default createForm()(ServiceImplement);
