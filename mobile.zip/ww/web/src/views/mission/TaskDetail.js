/**
 * @file mission/TaskDetail.js
 * @author liutingting
 */
import React, { PropTypes, PureComponent } from 'react';
import { connect } from 'dva';
import { routerRedux } from 'dva/router';
import { autobind } from 'core-decorators';
import _ from 'lodash';

import withNavBar from '../../components/common/withNavBar';
import MotDetailDesc from '../../components/mission/MotDesc';
import MotCustList from '../../components/mission/MotCustList';
import LeftSlideGuide from '../../components/mission/LeftSlideGuide';

const EMPTY_LIST = [];
const EMPTY_OBJECT = {};
const actionType = 'mission/fetchMotDetail';

const getDataFunction = loading => query => ({
  type: actionType,
  payload: query || EMPTY_OBJECT,
  // 作用是：是否显示loading 图标
  loading,
});

const mapStateToProps = state => ({
  data: state.mission.motDetail,
  batchTaskMissionIdList: state.mission.batchTaskMissionIdList,
  isLoading: state.loading.effects[actionType] || false,
});

const mapDispatchToProps = {
  // 请求数据时，显示loading 图标
  initial: getDataFunction(true),
  // 请求数据时，不显示loading 图标
  refresh: getDataFunction(false),
  push: routerRedux.push,
  reportSwipeAction: query => ({
    type: 'mission/swipeAction',
    payload: query,
  }),
  // 上传刷新页面log
  reportRefresh: query => ({
    type: 'global/refreshPage',
    payload: query,
  }),
  goBack: routerRedux.goBack,
  removeOneTaskMissionIdSuccess: query => ({
    type: 'mission/removeOneTaskMissionIdSuccess',
    payload: query,
  }),
};

const mergeProps = (stateProps, dispatchProps, ownProps) => {
  const { location: { query: { motTaskName } } } = ownProps;

  return {
    ...stateProps,
    ...dispatchProps,
    ...ownProps,
    title: <p>{motTaskName}</p>, // 标签<p>一定要带上，因为title的css是对p修饰的
  };
};

@connect(mapStateToProps, mapDispatchToProps, mergeProps)
@withNavBar({ title: '任务详情', hasBack: true, backUrl: '/mission' })
export default class TaskDetail extends PureComponent {

  static propTypes = {
    data: PropTypes.object.isRequired,
    push: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    initial: PropTypes.func.isRequired,
    refresh: PropTypes.func.isRequired,
    isLoading: PropTypes.bool.isRequired,
    reportSwipeAction: PropTypes.func.isRequired,
    reportRefresh: PropTypes.func.isRequired,
    batchTaskMissionIdList: PropTypes.array.isRequired,
    removeOneTaskMissionIdSuccess: PropTypes.func.isRequired,
  };

  constructor(props) {
    super(props);
    this.state = {
      descFoldStatus: true, // 折叠
      listHeight: 0,
      showNumber: -1,
    };
  }

  componentWillMount() {
    // 缓存策略（完成任务后，native会调用 任务详情列表action，更新待办任务数）
    const {
      initial,
      data,
      location: { query: { motTaskId } },
      batchTaskMissionIdList,
      removeOneTaskMissionIdSuccess,
    } = this.props;
    // 有缓存的时候去判断是否在已处理的代办列表中，如若存在，要重新刷新页面
    const hasInbatchTaskMissionIdlist = _.indexOf(batchTaskMissionIdList, motTaskId) > -1;
    // 该条任务还没存在缓存中
    if (_.isEmpty(data[motTaskId])) {
      initial({ motTaskId });
    } else if (hasInbatchTaskMissionIdlist) {
      // 该条任务已经存在缓存中，但是若存在已处理的代办列表中
      initial({ motTaskId });
      // 刷新完成后要把这条任务的id从批量处理的任务数组中去掉，保证再次进入任务详情的时候不会再次刷新
      removeOneTaskMissionIdSuccess({ missionId: motTaskId });
    }
  }
  @autobind
  renderListAgain() {
    const { descFoldStatus } = this.state;
    this.setState({ descFoldStatus: !descFoldStatus });
  }

  @autobind
  renderGuideLayer(listHeight) {
    this.setState({ listHeight });
  }

  @autobind
  renderGuideLayerAgain(showNumber) {
    this.setState({ showNumber });
  }

  render() {
    const { descFoldStatus, listHeight, showNumber } = this.state;
    const {
      data,
      refresh,
      location,
      push,
      isLoading,
      reportSwipeAction,
      reportRefresh,
    } = this.props;
    const { query: { motTaskId, motTaskName } } = location;
    const motData = data[motTaskId] || EMPTY_OBJECT;
    const { taskCustList = EMPTY_LIST } = motData;
    const { summary = '' } = motData;

    return (
      <section className="task-detail">
        <MotDetailDesc
          title={motTaskName}
          data={summary}
          handleClick={this.renderListAgain}
        />
        <MotCustList
          list={motData}
          reportSwipeAction={reportSwipeAction}
          reportRefresh={reportRefresh}
          push={push}
          motTaskId={motTaskId}
          motTaskName={motTaskName}
          location={location}
          refresh={refresh}
          isFetching={isLoading}
          descFoldStatus={descFoldStatus}
          callBackFunc={this.renderGuideLayer}
          showGuideAgain={this.renderGuideLayerAgain}
        />
        <LeftSlideGuide
          list={taskCustList}
          listHeight={listHeight}
          showNumber={showNumber}
        />
      </section>
    );
  }
}
