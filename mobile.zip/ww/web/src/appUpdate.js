/**
 * @file appUpdate.js
 * @author zhaochangwu@ios
 */

let retryCount = 1;
let chcp = null;

export default {
  initialize() {
    this.bindEvents();
  },

  bindEvents() {
    document.addEventListener('deviceready', this.onDeviceReady, false);
    document.addEventListener('chcp_updateIsReadyToInstall', this.onUpdateReady, false);
    document.addEventListener('chcp_updateLoadFailed', this.onUpdateLoadFailed, false);
    document.addEventListener('chcp_updateInstalled', this.onUpdateInstalled, false);
    document.addEventListener('chcp_updateInstallFailed', this.onUpdateInstallFailed, false);
    document.addEventListener('chcp_assetsInstallationError', this.onAssetsInstallationError, false);
  },

  // chcp_updateIsReadyToInstall Event Handler
  onDeviceReady() {
    console.log('Device is ready for work');
    chcp = window.chcp;
    if (chcp) {
      chcp.fetchUpdate();
    }
  },

  onUpdateReady() {
    console.log('New release was successfully loaded and ready to be installed');
    if (chcp) {
      retryCount = 1;
      chcp.installUpdate();
    }
  },

  onUpdateLoadFailed() {
    console.log('Plugin couldnt load update from the server');
    if (chcp && retryCount++ <= 3) {
      chcp.fetchUpdate();
    }
  },

  onUpdateInstalled() {
    console.log('Update was successfully installed.');
    retryCount = 1;
  },

  onUpdateInstallFailed() {
    console.log('Update installation failed');
    if (chcp && retryCount++ <= 3) {
      chcp.installUpdate();
    }
  },

  onAssetsInstallationError() {
    console.log(`Plugin couldn't copy files from bundle on the external storage.
      If this happens - plugin won't work.
      Can occur when there is not enough free space on the device.`);
  },
};
