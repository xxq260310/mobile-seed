/**
 * @file layouts/Frame.js
 * @author maoquan(maoquan@htsc.com)
 */

import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { TabBar, ActivityIndicator } from 'antd-mobile';
import { withRouter, routerRedux } from 'dva/router';
import { autobind } from 'core-decorators';
import _ from 'lodash';

import TabPane from './TabPane';
import Icon from '../components/common/Icon';
import tabConfig from '../config/tabConfig';

import '../css/main.less';

// 存放每个tab页的对象，以便切换的时候保持状态
const QUERY_MAP = {};

const getMissionBadge = (state) => {
  const { missionCenter } = state.mission;
  return (missionCenter && missionCenter.totalCount) || 0;
};

const mapStateToProps = state => ({
  loading: state.activity.global,
  missionBadge: getMissionBadge(state),
  priPos: state.global.priPos,
});

const mapDispatchToProps = {
  push: routerRedux.push,
  getSystemConst: () => ({
    type: 'global/getSystemConst',
    loading: false,
  }),
  getDictionary: () => ({
    type: 'global/getDictionary',
    loading: false,
  }),
  getServiceType: query => ({
    type: 'customer/getServiceType',
    payload: query || {},
  }),
};

@connect(mapStateToProps, mapDispatchToProps)
class Frame extends Component {

  static propTypes = {
    children: PropTypes.node.isRequired,
    push: PropTypes.func.isRequired,
    getSystemConst: PropTypes.func.isRequired,
    getDictionary: PropTypes.func.isRequired,
    getServiceType: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    loading: PropTypes.bool.isRequired,
    missionBadge: PropTypes.number,
    priPos: PropTypes.object.isRequired,
  }

  static defaultProps = {
    missionBadge: 0,
  }

  constructor(props) {
    super(props);
    this.state = {
    };
  }

  componentDidMount() {
    this.props.getSystemConst();
    this.props.getDictionary();
    // 请求服务类型数据（反馈数据内包含客户反馈和反馈明细）
    // 参数 type 的值，固定为 2
    this.props.getServiceType({
      type: 2,
      pageNum: 1,
      pageSize: 10000,
    });
  }

  componentWillReceiveProps(nextProps) {
    const { priPos } = nextProps;
    if (!_.isEqual(priPos, this.props.priPos)) {
      QUERY_MAP.customer = {};
    }
  }

  onChange(item) {
    const { push, location: { pathname, query } } = this.props;
    if (pathname) {
      QUERY_MAP[pathname.slice(1)] = { ...query };
    }
    const { key } = item;
    const lastQuery = QUERY_MAP[key] || {};
    push({
      pathname: `/${key}`,
      query: {
        ...lastQuery,
      },
    });
  }

  renderIcon({ key, isSelected }) {
    const iconMap = {
      mission: isSelected ? 'renwuhl' : 'renwu5',
      product: isSelected ? 'chanpinhl' : 'chanpinhl',
      customer: isSelected ? 'kehuhl' : 'kehu3',
      profile: isSelected ? 'wodehl' : 'wode1',
    };
    return (
      <Icon
        className={isSelected ? 'icon-active' : ''}
        type={iconMap[key]}
      />
    );
  }

  @autobind
  renderTabBarItem(item) {
    return (
      <TabBar.Item
        key={item.key}
        title={item.label}
        icon={this.renderIcon(item)}
        selectedIcon={this.renderIcon(item)}
        selected={item.isSelected}
        badge={item.key === 'mission' ? this.props.missionBadge : ''}
        onPress={() => {
          this.onChange(item);
        }}
      >
        { item.component }
      </TabBar.Item>
    );
  }

  render() {
    const { children, location, loading = false } = this.props;
    const { pathname } = location;
    const paths = pathname.split('/').filter(path => !!path);
    // 暂时先根据pathname长度决定是否隐藏tabbar,
    // 后续根据需求建立需要tabbar的白名单,如{ '/product': true, ... }
    const isTabBarHidden = paths.length > 1;

    // tabbar内渲染 or 独立页面
    let findTabItem = false;
    const tabs = tabConfig.map(
      (item) => {
        if (pathname.slice(1).indexOf(item.key) === 0) {
          findTabItem = true;
          return this.renderTabBarItem({ ...item, component: children, isSelected: true });
        }
        return this.renderTabBarItem({ ...item, component: TabPane });
      },
    );
    const main = findTabItem ? (
      <TabBar
        unselectedTintColor="#c5c4c7"
        tintColor="#333333"
        hidden={isTabBarHidden}
      >
        {tabs}
      </TabBar>
    ) : (
      <div className="page-wrapper">{children}</div>
    );
    return (
      <div className="page-wrapper">
        {main}
        <ActivityIndicator toast animating={loading} text="正在加载" />
      </div>
    );
  }
}

export default withRouter(Frame);
