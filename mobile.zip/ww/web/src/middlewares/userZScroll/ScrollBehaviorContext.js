/**
 * @file middlewares/userZScroll/ScrollBehaviorContext.js
 * @author maoquan(maoquan@htsc.com)
 */

import React, { PureComponent } from 'react';

import StateStorage from './StateStorage';

const banUrl = ['/mission/taskDetail'];

export default class ScrollBehaviorContext extends PureComponent {

  static propTypes = {
    shouldUpdateScroll: React.PropTypes.func,
    routerProps: React.PropTypes.object.isRequired,
    children: React.PropTypes.element.isRequired,
  }

  static defaultProps = {
    shouldUpdateScroll: () => {},
  }

  static childContextTypes = {
    shouldUpdateScroll: React.PropTypes.func.isRequired,
  }

  // getChildContext() {
    // return {color: "purple"};
  // }

  constructor(props, context) {
    super(props, context);

    const { routerProps } = props;
    const { router } = routerProps;

    this.storage = new StateStorage(router);
    if (typeof String.prototype.startsWith !== 'function') {
      String.prototype.startsWith = function (prefix) {// eslint-disable-line
        return this.slice(0, prefix.length) === prefix;
      };
    }
    // stateStorage: new StateStorage(router),
    // getCurrentLocation: () => this.props.routerProps.location,

    // do updateScroll
  }

  componentWillUpdate() {
    const { routerProps } = this.props;
    const listView = this.findReact(document.querySelector('.am-list-view-scrollview'));
    if (listView) {
      const scrollTop = listView.domScroller.scroller.__scrollTop; // eslint-disable-line
      this.storage.save(
        this.getCurrentLocation(),
        this.getKey(routerProps.location),
        scrollTop,
      );
    }
  }

  componentDidUpdate(prevProps) {
    const { routerProps } = this.props;
    const prevRouterProps = prevProps.routerProps;

    console.log('ScrollBehaviorContext.js: componentDidUpdate');
    if (routerProps.location.pathname === prevRouterProps.location.pathname) {
      return;
    }
    const listView = this.findReact(document.querySelectorAll('.am-list-view-scrollview')[0]);
    const top = this.storage.read(
      this.getCurrentLocation(),
      this.getKey(routerProps.location),
    ) || 0;
    // console.log(top);
    if (listView && this.banUrlCheck(routerProps.location)) {
      listView.scrollTo(0, top);
    }
    // do updateScroll TODO
  }

  componentWillUnmount() {
    // clear
    console.log('ScrollBehaviorContext.js: componentWillUnmount');
  }

  getCurrentLocation() {
    const { routerProps } = this.props;
    return routerProps.location.pathname;
  }

  getKey(location) {
    const { query, pathname } = location;
    function checkKey(value) {
      return value !== 'deviceId'
        && value !== 'empId'
        && value !== 'token';
    }
    const queryString = Object.keys(query).filter(checkKey).map(
      key => `${key}=${query[key]}`,
    ).join('&');
    return pathname + (queryString ? `?${queryString}` : '');
  }

  findReact(dom = {}) {
    let result = null;
    if (dom) {
      Object.keys(dom).forEach(
        (key) => {
          if (key.startsWith('__reactInternalInstance$')) {
            /* eslint-disable */
            const compInternals = dom[key]._currentElement;
            const compWrapper = compInternals._owner;
            result = compWrapper._instance;
            /* eslint-enable */
          }
        },
      );
    }
    return result;
  }

  shouldUpdateScroll(prevRouterProps, routerProps) {
    console.log('ScrollBehaviorContext.js: shouldUpdateScroll');
    const { shouldUpdateScroll } = this.props;
    if (!shouldUpdateScroll) {
      return true;
    }

    // Hack to allow accessing scrollBehavior._stateStorage.
    return shouldUpdateScroll.call(
      null, prevRouterProps, routerProps,
    );
  }

  banUrlCheck(location) {
    let result = true;
    banUrl.forEach(
      (url) => {
        if (location.pathname === url) {
          result = false;
        }
      },
    );
    return result;
  }

  render() {
    return this.props.children;
  }
}
