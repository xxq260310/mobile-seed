export default {};

// 列表下拉刷新检查
export const checkErrData = (options = {}) => (target, name, descriptor) => {
  const { propertyName = 'isFetching', loadingName = 'isLoading' } = options;
  const origin = descriptor.value;

  return {
    ...descriptor,
    value(...args) {
      if (this.props[propertyName] === true && args[0][propertyName] === false) {
        this.setState({
          [loadingName]: false,
          isLoaded: true,
        });
      }
      origin.apply(this, args);
    },
  };
};
