import cordova from '../utils/cordova';
import Toast from '../components/common/Toast';

export default {};

// 列表下拉刷新检查
export const checkListPTR = (options = {}) => (target, name, descriptor) => {
  const { propertyName = 'isRefreshing' } = options;
  const origin = descriptor.value;

  return {
    ...descriptor,
    value(...args) {
      if (!this.state[propertyName]) {
        this.setState(
          { [propertyName]: true },
          () => {
            if (!cordova.isConnected()) {
              setTimeout(
                () => {
                  this.setState({ [propertyName]: false });
                },
                1000,
              );
              return;
            }
            origin.apply(this, args);
          },
        );
      }
    },
  };
};

// 检测网络状态
export const checkNetworkStatus = (target, name, descriptor) => {
  const origin = descriptor.value;

  return {
    ...descriptor,
    value(...args) {
      if (!cordova.isConnected()) {
        Toast.info('网络异常', 1);
        return;
      }
      origin.apply(this, args);
    },
  };
};
