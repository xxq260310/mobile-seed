/**
 * @file routes.js
 * @author maoquan(maoquan@htsc.com)
 */

import React from 'react';
import {
  applyRouterMiddleware,
  Router,
  Route,
  IndexRoute,
  IndexRedirect,
} from 'dva/router';

// import { useScroll } from 'react-router-scroll';
import useZScroll from './middlewares/userZScroll';

import Frame from './layouts/Frame';
import TabPane from './layouts/TabPane';

import ProductHome from './views/product/Home';
import ProductDetail from './views/product/Detail';
import ProductDetailWithMenu from './views/product/DetailWithMenu';
import ProductDetailMoreInfo from './views/product/MoreInfo';
import ProductDetailDescription from './views/product/Description';
import ProductSearchResult from './views/product/SearchResult';
import TargetCustomer from './views/product/TargetCustomer';
import CustomerHome from './views/customer/Home';
import CustomerDetail from './views/customer/Detail';
import CustBasic from './views/customer/CustBasic';
import CustContactPer from './views/customer/CustContactPer';
import CustContactOrg from './views/customer/CustContactOrg';
import ContactOrgDetail from './views/customer/ContactOrgDetail';
import ServiceList from './views/customer/ServiceRecord';
import ServiceListDetail from './views/customer/ServiceRecordDetail';
import CustomerSearchResult from './views/customer/SearchResult';
import CustomerServRecord from './views/customer/Record';
import CustomerServRecordEdit from './views/customer/RecordEdit';
import CustBasicEdit from './views/customer/CustBasicEdit';
import CustTaskList from './views/customer/CustTaskList';
import AddContact from './views/customer/AddContact';
import MissionHome from './views/mission/Home';
import TaskDetail from './views/mission/TaskDetail';
import Profile from './views/profile/Home';
import MissionEmail from './views/mission/email';
import ServiceImplement from './views/mission/ServiceImplement';
import MySetup from './views/profile/MySetup';
import MyPosition from './views/profile/MyPosition';
import CustBusinessInfo from './views/customer/CustBusinessInfo';
import EditPerContact from './views/customer/EditPerContact';
import EditPerContactDetail from './views/customer/EditPerContactDetail';
import EditInput from './views/common/EditInputPage';
import SetGesture from './views/profile/SetGesture';

const routes = ({ history }) => (// eslint-disable-line
  <Router
    history={history}
    /**
    * 引发scroll回不到顶部的问题
    */
    render={applyRouterMiddleware(useZScroll())}
  >
    <Route path="/" component={Frame}>
      <IndexRedirect to="/mission" />
      <Route path="mission" component={TabPane}>
        <IndexRoute component={MissionHome} />
        <Route path="email" component={MissionEmail} />
        <Route path="taskDetail" component={TaskDetail} />
        <Route path="ServiceImplement" component={ServiceImplement} />
      </Route>
      <Route path="product" components={TabPane}>
        <IndexRoute component={ProductHome} />
        <Route path="detailWithMenu" components={ProductDetailWithMenu} />
        <Route path="detailMoreInfo" components={ProductDetailMoreInfo} />
        <Route path="detailDescription" components={ProductDetailDescription} />
        <Route path="detail" components={ProductDetail} />
        <Route path="search-result" components={ProductSearchResult} />
        <Route path="targetCustomer" components={TargetCustomer} />
      </Route>
      <Route path="customer" component={TabPane}>
        <IndexRoute component={CustomerHome} />
        <Route path="searchResult" component={CustomerSearchResult} />
        <Route path="custBasic" component={CustBasic} />
        <Route path="custContactPer" component={CustContactPer} />
        <Route path="custContactOrg" component={CustContactOrg} />
        <Route path="contactOrgDetail" component={ContactOrgDetail} />
        <Route path="serviceListDetail" component={ServiceListDetail} />
        <Route path="serviceList" component={ServiceList} />
        <Route path="detail" components={CustomerDetail} />
        <Route path="recordEdit" components={CustomerServRecordEdit} />
        <Route path="record" components={CustomerServRecord} />
        <Route path="custBusinessInfo" component={CustBusinessInfo} />
        <Route path="CustBasicEdit" component={CustBasicEdit} />
        <Route path="editPerContactDetail" component={EditPerContactDetail} />
        <Route path="editPerContact" component={EditPerContact} />
        <Route path="addContact" component={AddContact} />
        <Route path="custTaskList" component={CustTaskList} />
      </Route>
      <Route path="profile" components={TabPane} >
        <IndexRoute component={Profile} />
        <Route path="mysetup" components={MySetup} />
        <Route path="myposition" components={MyPosition} />
        <Route path="setgesture" components={SetGesture} />
      </Route>
      <Route path="common" components={TabPane} >
        <IndexRoute component={EditInput} />
      </Route>
    </Route>
  </Router>
);

export default routes;
