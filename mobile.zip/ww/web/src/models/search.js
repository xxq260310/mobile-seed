/**
 * @file models/search.js
 * @author maoquan(maoquan@htsc.com)
 */

import _ from 'lodash';

import api from '../api';
import { constants } from '../config';

export default {
  namespace: 'search',
  state: {
    customer: {
      page: {},
      list: [],
    },
    product: {
      page: {},
      list: [],
    },
    customerQuery: {},
    productQuery: {},
  },
  reducers: {
    customerSuccess(state, { payload: { response, query } }) {// eslint-disable-line
      const { resultData: { page, resultList } } = response;
      // 翻页情况下，如果返回为空，则直接返回state
      const { curPageNum } = page;
      if (_.isEmpty(resultList) && (curPageNum !== 1)) {
        return state;
      }
      // 如果page为1表示新刷新，这时候清空之前的列表
      const originList = page.curPageNum === 1 ? [] : state.customer.list;
      return {
        ...state,
        customer: {
          page,
          list: [...originList, ...resultList],
        },
      };
    },
    // 产品搜索
    productSuccess(state, { payload: { response, query } }) {// eslint-disable-line
      const { resultData: { page, productlist } } = response;
      // 翻页情况下，如果返回为空，则直接返回state
      const { curPageNum } = page;
      if (_.isEmpty(productlist) && (curPageNum !== 1)) {
        return state;
      }
      // 如果page为1表示新刷新，这时候清空之前的列表
      const originList = page.curPageNum === 1 ? [] : state.product.list;
      return {
        ...state,
        product: {
          page,
          list: [...originList, ...productlist],
        },
      };
    },
    // 保存搜索条件
    saveQuery(state, { payload: queryInfo }) {// eslint-disable-line
      if (queryInfo.type === 'customer') {
        return {
          ...state,
          customerQuery: queryInfo.query,
        };
      }
      return {
        ...state,
        productQuery: queryInfo.query,
      };
    },
  },
  effects: {
    // 搜索客户
    * customer({ payload: query }, { call, put, select }) {
      const { postnId, postnName } = yield select(state => state.global.priPos);
      const { keyword: keywords, custQueryType, page: pageNum = 1, ...others } = query;
      const response = yield call(
        api.searchCustomer,
        {
          ...others,
          keywords,
          custQueryType,
          pageNum,
          pageSize: constants.pageSize,
          posId: postnId,
          posName: postnName,
        },
      );
      yield put({ type: 'customerSuccess', payload: { response, query } });
    },
    // 搜索产品
    * product({ payload: query }, { call, put }) {
      const {
        prdTypeCode,
        salesStatus,
        sortColumn,
        sortType,
        riskLevel,
        bfMaturityMin,
        bfMaturityMax,
        firstParticipationMin,
        firstParticipationMax,
        keywords,
        pageNum,
      } = query;
      const response = yield call(
        api.searchProduct,
        {
          prdTypeCode,
          salesStatus,
          sortColumn,
          sortType,
          riskLevel,
          bfMaturityMin,
          bfMaturityMax,
          firstParticipationMin,
          firstParticipationMax,
          keywords,
          pageNum,
          pageSize: constants.pageSize,
        },
      );
      yield put({ type: 'productSuccess', payload: { response, query } });
    },
  },
  subscriptions: {},
};
