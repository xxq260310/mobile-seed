/**
 * @fileOverview models/profile.js
 * @author sunweibin
 */

import api from '../api';

export default {
  namespace: 'profile',
  state: {
    // 员工信息
    achievement: {},
  },
  reducers: {
    getMineAchievementSuccess(state, action) {
      const { payload: { mineAchievement } } = action;
      return {
        ...state,
        achievement: {
          ...mineAchievement.resultData,
        },
      };
    },
  },
  effects: {
    // 获取用户业务指标
    * getMineAchievement({ payload: query }, { call, put }) {
      const mineAchievement = yield call(api.getMineAchievement, query);
      // 此处在保存成功后
      yield put({
        type: 'getMineAchievementSuccess',
        payload: {
          mineAchievement,
        },
      });
    },
  },
  subscriptions: {},
};
