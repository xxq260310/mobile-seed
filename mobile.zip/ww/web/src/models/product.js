/**
 * @file models/product.js
 * @author fwc
 */

import _ from 'lodash';
import api from '../api';
import { constants } from '../config';

const EMPTY_LIST = [];
const EMPTY_OBJECT = {};

export default {
  namespace: 'product',
  state: {
    // 产品详情
    detailInfo: EMPTY_OBJECT,
    // 产品首页列表
    list: {
      page: EMPTY_OBJECT,
      resultList: EMPTY_LIST,
    },
    // 目标客户列表
    targetCustList: {
      page: EMPTY_OBJECT,
      resultList: EMPTY_LIST,
    },
    sendEmailResult: {},
    ignoreCustomerResult: {},
  },
  reducers: {
    ignoreCustomerSuccess(state, action) {
      const { payload: { response: { resultData }, clientIdSign } } = action;
      return {
        ...state,
        ignoreCustomerResult: {
          ...state.ignoreCustomerResult,
          [`${clientIdSign}`]: {
            resultData,
          },
        },
      };
    },
    sendCustEmailSuccess(state, action) {
      const { payload: { response: { resultData }, clientIdSign } } = action;
      return {
        ...state,
        sendEmailResult: {
          ...state.sendEmailResult,
          [`${clientIdSign}`]: {
            resultData,
          },
        },
        // sendEmailResult: isSendSuccess,
      };
    },
    deleteTargetList(state, action) {
      const { payload: { directoryCode, productCode, clientIdSign } } = action;
      const { page, resultList } = state.targetCustList[`${productCode}_${directoryCode}`]
        || EMPTY_OBJECT;
      const newTargetList = _.filter(resultList, item => (
        item && item.clientIdSign !== clientIdSign
      ));

      return {
        ...state,
        targetCustList: {
          [`${productCode}_${directoryCode}`]: {
            page,
            resultList: newTargetList,
          },
        },
      };
    },
    changeSendEmailResult(state, action) {
      const { payload: { currentTargetCustomer } } = action;
      return {
        ...state,
        sendEmailResult: {
          ...state.sendEmailResult,
          [currentTargetCustomer]: {
            resultData: null,
          },
        },
      };
    },
    changeIgnoreResult(state, action) {
      const { payload: { currentTargetCustomer } } = action;
      return {
        ...state,
        ignoreCustomerResult: {
          ...state.ignoreCustomerResult,
          [currentTargetCustomer]: {
            resultData: null,
          },
        },
      };
    },
    getProListSuccess(state, action) {
      const { payload: { list } } = action;
      const resultData = list.resultData || EMPTY_OBJECT;
      const { page = EMPTY_OBJECT, productlist = EMPTY_LIST } = resultData;
      const { resultList: preData } = state.list;
      return {
        ...state,
        list: {
          page,
          resultList: page.curPageNum === 1 ? productlist : [...preData, ...productlist],
        },
      };
    },
    fetchProductDetailSuccess(state, action) {
      const { payload: { response, productCode, directoryCode } } = action;
      return {
        ...state,
        detailInfo: {
          ...state.detailInfo,
          [`${productCode}_${directoryCode}`]: {
            ...response.resultData,
          },
        },
      };
    },
    fetchTargetCustomerSuccess(state, action) {
      const { payload: { response, productCode, directoryCode } } = action;
      const resultData = response.resultData || EMPTY_OBJECT;
      const { page = EMPTY_OBJECT, clientlist = EMPTY_LIST } = resultData;
      const { resultList: preData = EMPTY_LIST } =
        state.targetCustList[`${productCode}_${directoryCode}`] || EMPTY_OBJECT;

      return {
        ...state,
        targetCustList: {
          [`${productCode}_${directoryCode}`]: {
            page,
            resultList: page.curPageNum === 1 ? clientlist : [...preData, ...clientlist],
          },
        },
      };
    },
  },
  effects: {
    * ignoreCustomer({ payload: {
      clientIdSign = '',
      productCode = '',
      directoryCode = '', source = '01' } }, { call, put }) {
      const response = yield call(api.ignoreProduct, {
        clientIdSign,
        productCode,
        directoryCode,
        source,
      });
      yield put({
        type: 'ignoreCustomerSuccess',
        payload: {
          response,
          clientIdSign,
        },
      });
      yield put({
        type: 'deleteTargetList',
        payload: {
          directoryCode,
          productCode,
          clientIdSign,
        },
      });
      // // 忽略成功之后，刷新目标客户列表
      // yield put({
      //   type: 'fetchTargetCustomer',
      //   payload: {
      //     directoryCode,
      //     productCode,
      //     pageNum: 1,
      //   },
      // });
    },
    * sendCustEmail({ payload: { clientIdSign = '', clientName = '', productCode = '', directoryCode = '' } }, { call, put }) {
      const response = yield call(api.sendProductEmail,
        {
          clientIdSign,
          clientName,
          productCode,
          directoryCode,
        });
      yield put({
        type: 'sendCustEmailSuccess',
        payload: {
          response,
          clientIdSign,
        },
      });
    },
    * fetchProductDetail({ payload: { productId = null, productCode = '1', directoryCode = '1' } }, { call, put }) {
      const response = yield call(api.getProductDetail,
        {
          productId,
          productCode,
          directoryCode,
        });
      yield put({
        type: 'fetchProductDetailSuccess',
        payload: {
          response,
          productId,
          productCode,
          directoryCode,
        },
      });
    },
    * fetchTargetCustomer({ payload: { directoryCode = '', productCode = '', pageNum = 1 } }, { call, put }) {
      const response = yield call(api.targetCusts, { directoryCode, productCode, pageNum });
      yield put({
        type: 'fetchTargetCustomerSuccess',
        payload: {
          response,
          directoryCode,
          productCode,
        },
      });
    },
    // 获取客户列表
    * getProList({ payload: {
      prdTypeCode = '',
      salesStatus = '',
      sortColumn = 2,
      sortType = 1,
      riskLevel = '',
      bfMaturityMin = '',
      bfMaturityMax = '',
      firstParticipationMin = '',
      firstParticipationMax = '',
      keywords = '',
      pageSize = constants.pageSize,
      pageNum = 1,
      } }, { call, put }) {
      const list = yield call(
        api.getProductList,
        {
          prdTypeCode,
          salesStatus,
          sortColumn,
          sortType,
          riskLevel,
          bfMaturityMin,
          bfMaturityMax,
          firstParticipationMin,
          firstParticipationMax,
          keywords,
          pageSize,
          pageNum,
        },
      );
      yield put({
        type: 'getProListSuccess',
        payload: {
          list,
        },
      });
    },
  },
  subscriptions: {},
};
