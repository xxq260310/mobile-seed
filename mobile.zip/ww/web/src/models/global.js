/**
 * @file models/global.js
 * @author maoquan(maoquan@htsc.com)
 */

import _ from 'lodash';
import { navToLogin } from '../utils/cordova';
import api from '../api';
import { getPersistItem, setLocalStorageItem, removePersistItem } from '../utils/helper';

const localData = getPersistItem('global');
const {
  empInfo: localEmpInfo = {},
  empPostnList: localPostnList = [],
  empRespList: localEmpRespList = [],
  priPos: localPriPos = {},
  shakeSwitch: localShakeSwitch = true,
} = localData || {};

export default {
  namespace: 'global',
  state: {
    token: '',
    // 是否授权可以打电话
    canCall: false,
    // 用户信息
    empInfo: localEmpInfo,
    // 职位
    empPostnList: localPostnList,
    // 职责
    empRespList: localEmpRespList,
    // 摇一摇开关
    shakeSwitch: localShakeSwitch,
    // 职位
    priPos: localPriPos,
    // 手势开关
    gestureSwitch: false,
    // 全局的字典数据
    systemConst: {},
    dictionary: {},
  },
  reducers: {
    getSystemConstSuccess(state, action) {
      // 客户基本信息
      const { payload: { resultData } } = action;
      if (resultData.isSuccess && resultData.codeMatch) {
        return {
          ...state,
          systemConst: resultData.codeMatch,
        };
      }
      return state;
    },
    getTokenSuccess(state, action) {
      // 客户基本信息
      const { payload: { token } } = action;
      return {
        ...state,
        token,
      };
    },
    getDictionarySuccess(state, action) {
      const { payload } = action;
      return {
        ...state,
        dictionary: payload,
      };
    },
    getEmpInfoSuccess(state, action) {
      // 用户信息
      const {
        payload: {
          canCall,
          empInfo,
          empPostnList,
          empRespList,
        },
      } = action;
      return {
        ...state,
        canCall,
        empInfo,
        empPostnList,
        empRespList,
      };
    },
    getShakeSwitchStateSuccess(state, action) {
      // 开启摇一摇开关
      const { payload: { shakeSwitch } } = action;
      return {
        ...state,
        shakeSwitch,
      };
    },
    setPriPositionSuccess(state, action) {
      // 设置主职位
      const { payload } = action;
      return {
        ...state,
        priPos: payload,
      };
    },
    setGestureSwitchState(state) {
      return {
        ...state,
        // 当且仅当，native创建手势成功，通过window.dispatch调用该方法，故自动设置为true。
        gestureSwitch: true,
      };
    },
  },
  effects: {
    // 获取系统常量
    * getSystemConst(action, { call, put }) {
      const response = yield call(api.getSystemConst);
      yield put({
        type: 'getSystemConstSuccess',
        payload: response,
      });
    },
    // 登出
    * logout({ payload: query }, { call }) {
      yield call(api.logout, query);
      navToLogin();
    },
    // 获取token(for dev)
    * getToken({ payload: { empId, deviceId } }, { call, put }) {
      try {
        yield call(api.sendSmsCheckCode, { empId });
      } catch (e) {
        console.log(e);
      }
      const response = yield call(api.login, { deviceId, empId });
      if (response.resultData) {
        const { token } = response.resultData;
        yield put({
          type: 'getTokenSuccess',
          payload: {
            token,
          },
        });
      }
    },
    // 获取字典信息
    * getDictionary({ payload }, { call, put }) {
      const response = yield call(api.getDictionary, payload);
      if (response.resultData) {
        yield put({
          type: 'getDictionarySuccess',
          payload: response.resultData,
        });
      }
    },
    // 获取员工信息
    * getEmpInfo({ payload }, { call, put }) {
      const response = yield call(api.getEmpInfo);
      const getGlobalData = (localData && !_.isEmpty(localEmpInfo))
        ?
        { empInfo: localEmpInfo }
        :
        { empInfo: { rowId: '' } };

      const { empInfo: { rowId } } = getGlobalData;
      const { resultData = {} } = response || {};
      if (!_.isEmpty(resultData)) {
        const { canCall, empInfo, empPostnList, empRespList } = resultData;
        if (rowId !== empInfo.rowId) {
          const defaultPosition = _.find(empPostnList, item => item.isPriPostn === 'Y') || empPostnList[0];
          const currentPosition = {
            postnId: defaultPosition.postnId,
            postnName: defaultPosition.postnName,
          };
          // 清除本地存储
          const strongs = Object.keys(localStorage);
          strongs.map((item) => {
            if (item.toString().indexOf('NOREMOVE') === -1) {
              removePersistItem(item.toString());
            }
            return true;
          });
          // 更新值
          const globalLocalStorage = {
            ...getGlobalData,
            empInfo,
            empPostnList,
            empRespList,
            shakeSwitch: true,
            priPos: currentPosition,
          };
          console.log('globalLocalStorage>>>', globalLocalStorage);
          // 存储值，本地化
          setLocalStorageItem('global', globalLocalStorage);

          // 更新state中的 职位 字段
          yield put({
            type: 'setPriPositionSuccess',
            payload: currentPosition,
          });
        }
        yield put({
          type: 'getEmpInfoSuccess',
          payload: {
            canCall,
            empInfo,
            empPostnList,
            empRespList,
          },
        });
      }
    },
    // 开启摇一摇开关
    * getShakeSwitchState({ payload }, { put }) {
      // const globalState = yield select(state => state.global);
      const getGlobalData = localData || { shakeSwitch: true };
      const { shakeSwitch } = payload;
      const globalLocalStorage = Object.assign(getGlobalData, { shakeSwitch });
      // 更新本地化存储的 摇一摇开关 字段
      setLocalStorageItem('global', globalLocalStorage);

      yield put({
        type: 'getShakeSwitchStateSuccess',
        payload,
      });
    },
    // 设置主职位
    * setPriPosition({ payload }, { put }) {
      const getGlobalData = (localData && !_.isEmpty(localData.priPos))
        ?
        localData.priPos
        :
        { priPos: {} };
      const globalLocalStorage = Object.assign(getGlobalData, { priPos: payload });
      // 更新本地化存储的 职位 字段
      setLocalStorageItem('global', globalLocalStorage);

      yield put({
        type: 'setPriPositionSuccess',
        payload,
      });
      yield put({
        type: 'customer/getList',
        payload: {
          custQueryType: 'personal',
          orderType: 'desc',
          pageNum: 1,
        },
      });
    },
  },
  subscriptions: {},
};
