/**
 * @file models/customer.js
 * @author maoquan(maoquan@htsc.com)
 */

import _ from 'lodash';
import 'moment/locale/zh-cn';
import { routerRedux } from 'dva/router';
import api from '../api';
import { constants } from '../config';
import { toast } from '../utils/sagaEffects';

const EMPTY_LIST = [];
const EMPTY_OBJECT = {};

export default {
  namespace: 'customer',
  state: {
    // 客户首页列表
    list: {
      page: EMPTY_OBJECT,
      resultList: EMPTY_LIST,
    },
    // 客户详情
    detailInfo: {},
    // 客户基本信息
    basic: {},
    // 个人客户联系方式
    contact: {},
    // 机构客户联系人列表
    contactList: {},
    // 待办任务数量
    custTaskMotCount: {},
    // 服务信息列表
    serviceList: {},
    // 客户简要信息
    custBriefContact: {},
    // 已开通业务列表
    custBusinessInfo: {},
    // 发邮件需要的数据
    // motRelatedData: {},
    ignoreProductResult: {},
    // 给客户发邮件成功与否
    sendEmailResult: {},
    // 服务记录活动内容选项
    serviceContentOpts: [],
    // 添加机构客户时保存各属性值
    addContact: {},
    // 机构客户的个人信息
    personnelInfo: {},
    // 存储编辑信息的返回层级
    goBackCount: 1,
    // 存储编辑个人联系方式的state数据，goBack时，state会丢失
    saveDataFunction: {},
    // 客户待办任务列表
    custMotList: EMPTY_OBJECT,
    addServiceRecordFlag: '',
    // 存储编辑内容
    content: '',
    serviceTypeOption: EMPTY_OBJECT,
    addRecordResult: false,
    recordListData: EMPTY_OBJECT,
    // 服务记录页面需要的数据
    recordPageNeedfulData: EMPTY_OBJECT,
  },
  reducers: {
    // storeMotRelatedData(state, { payload }) {
    //   const { response, custId } = payload;
    //   return {
    //     ...state,
    //     motRelatedData: {
    //       [custId]: response,
    //     },
    //   };
    // },
    // 获取用户待办列表成功
    getCustMotListSuccess(state, action) {
      const { payload: { response: { resultData = EMPTY_OBJECT }, custId } } = action;
      const { custMotList } = state;
      return {
        ...state,
        custMotList: {
          ...custMotList,
          [custId]: resultData,
        },
      };
    },
    // 获取用户待办任务数量
    getCustMotCountSuccess(state, action) {
      const { payload: { response, custId } } = action;
      return {
        ...state,
        custTaskMotCount: {
          [custId]: response.resultData,
        },
      };
    },
    getBasicSuccess(state, action) {
      // 客户基本信息
      const { payload: { response, custId } } = action;
      return {
        ...state,
        basic: {
          [custId]: response.resultData,
        },
      };
    },
    updateBasicSuccess(state, action) {
      // 修改客户基本信息
      const { payload: { response, custId } } = action;
      return {
        ...state,
        basic: {
          [custId]: response.resultData,
        },
      };
    },
    getContactSuccess(state, action) {
      // 个人客户联系方式
      const { payload: { response, custId } } = action;
      return {
        ...state,
        contact: {
          [custId]: response.resultData,
        },
      };
    },
    getContactListSuccess(state, action) {
      // 机构客户联系人
      const { payload: { response, custId } } = action;
      return {
        ...state,
        contactList: {
          [custId]: response.resultData,
        },
      };
    },
    getServiceListSuccess(state, action) {
      // 服务记录列表
      const { payload: { response, custId } } = action;
      return {
        ...state,
        serviceList: {
          ...state.serviceList,
          [custId]: response.resultData,
        },
      };
    },
    getListSuccess(state, action) {
      const { payload: { list } } = action;
      const resultData = list.resultData || EMPTY_OBJECT;
      const { page = EMPTY_OBJECT, resultList = EMPTY_LIST } = resultData;
      const { resultList: preData } = state.list;
      return {
        ...state,
        list: {
          page,
          resultList: page.curPageNum === 1 ? resultList : [...preData, ...resultList],
        },
      };
    },
    // 获取客户详情成功
    fetchCustDetailSuccess(state, action) {
      const { payload: { response, custId, custNumber, custSor } } = action;
      return {
        ...state,
        detailInfo: {
          ...state.detailInfo,
          [custId]: {
            ...response.resultData,
            custId,
            custNumber,
            custSor,
          },
        },
      };
    },
    ignoreProductSuccess(state, action) {
      const { payload: { response, productCode, directoryCode } } = action;
      return {
        ...state,
        ignoreProductResult: {
          ...state.ignoreProductResult,
          [`${productCode}_${directoryCode}`]: {
            ...response.resultData,
          },
        },
      };
    },
    sendCustEmailSuccess(state, action) {
      const { payload: { response: { resultData }, productCode, directoryCode } } = action;
      return {
        ...state,
        sendEmailResult: {
          ...state.sendEmailResult,
          [`${productCode}_${directoryCode}`]: {
            resultData,
          },
        },
        // sendEmailResult: isSendSuccess,
      };
    },
    fetchCustBriefContactSuccess(state, action) {
      const { payload: { response, custNumber, custSor } } = action;
      return {
        ...state,
        custBriefContact: {
          ...state.custBriefContact,
          [custNumber]: {
            ...response.resultData,
            custNumber,
            custSor,
          },
        },
      };
    },
    changeSendEmailResult(state, action) {
      const { payload: { currentTargetProduct } } = action;
      return {
        ...state,
        sendEmailResult: {
          ...state.sendEmailResult,
          [currentTargetProduct]: {
            resultData: null,
          },
        },
      };
    },
    // 更新返回级数
    updateGoBackLevel(state, action) {
      const { payload: { count } } = action;
      return {
        ...state,
        goBackCount: count,
      };
    },
    storeSaveData(state, action) {
      const { payload } = action;
      return {
        ...state,
        saveDataFunction: payload,
      };
    },
    getContentOptsSuccess(state, action) {
      const { payload: { response } } = action;
      return {
        ...state,
        serviceContentOpts: response.resultData,
      };
    },
    getServiceTypeSuccess(state, action) {
      const { payload: { response } } = action;
      return {
        ...state,
        serviceTypeOption: response.resultData || EMPTY_OBJECT,
      };
    },
    getServiceRecordListSuccess(state, action) {
      const { payload: { response, pageNum, custId } } = action;
      const { recordListData } = state;
      const preRecordListData = recordListData[custId] || EMPTY_OBJECT;
      const preRecordList = preRecordListData.recordList || EMPTY_LIST;
      const curRecordList = response.resultData || EMPTY_LIST;
      // 是否有下一页（后台接口没有返回page信息，根据请求接口是否为空和是否小于10条判断）
      let hasMore = true;
      if (pageNum !== 1 &&
        curRecordList &&
        (curRecordList < 10 || curRecordList.length === 0)
      ) {
        hasMore = false;
      }
      return {
        ...state,
        recordListData: {
          ...recordListData,
          [custId]: {
            recordList: pageNum === 1 ? curRecordList : [...preRecordList, ...curRecordList],
            hasMore,
            pageNum,
          },
        },
      };
    },
    addCommonServeRecordSuccess(state, action) {
      const { payload } = action;
      return {
        ...state,
        addRecordResult: payload,
      };
    },
    saveServiceContent(state, action) {
      const { payload } = action;
      return {
        ...state,
        ...payload,
      };
    },
    addServiceRecordSuccess(state, action) {
      const { payload: { flag } } = action;
      return {
        ...state,
        addServiceRecordFlag: flag,
      };
    },
    getBusinessListSuccess(state, action) {
      const { payload: { response, custId } } = action;
      return {
        ...state,
        custBusinessInfo: {
          [custId]: { ...response.resultData },
        },
      };
    },
    addContactOrgSuccess(state, action) {
      const { payload } = action;
      return {
        ...state,
        addContact: payload,
      };
    },
    delContactOrgSuccess(state, action) {
      const { payload: { callback } } = action;
      callback();
      return { ...state };
    },
    clearPrevAddContent(state) {
      return {
        ...state,
        addContact: {
          name: '',
          custRela: { selectkey: '', selectValue: '' },
          mainFlag: undefined,
          cellPhones: '',
          emailAddresses: '',
          homeTels: '',
          workTels: '',
        },
      };
    },
  },
  effects: {
    // 获取客户任务待办列表
    * getCustMotList({ payload:
        {
          custId = 1,
          custNumber = 1,
          pageNum = 1,
          pageSize = 10,
        },
      }, { call, put }) {
      const response = yield call(api.getCustMotList,
        { custId, custNumber, pageNum, pageSize });
      yield put({
        type: 'getCustMotListSuccess',
        payload: {
          custId,
          response,
          custNumber,
          pageNum,
          pageSize,
        },
      });
    },
    // 获取客户任务待办数量
    * getCustMotCount({ payload: { custId, custNumber = 1 } }, { call, put }) {
      const response = yield call(api.motTaskOfCustCount, { custId, custNumber });
      yield put({
        type: 'getCustMotCountSuccess',
        payload: {
          response,
          custId,
          custNumber,
        },
      });
    },
    // 获取客户详情
    * fetchCustDetail({ payload: { custId = 1, custNumber = 1, custSor = 'per' } }, { call, put }) {
      const response = yield call(api.getCustomerDetail, { custId, custNumber, custSor });
      yield put({
        type: 'fetchCustDetailSuccess',
        payload: {
          response,
          custId,
          custNumber,
          custSor,
        },
      });
    },
    * ignoreProduct({ payload: { clientIdSign = '',
      productCode = '',
      directoryCode = '', source = '01',
      custId = '', custNumber = '', custSor = '' } }, { call, put }) {
      const response = yield call(api.ignoreProduct, {
        clientIdSign,
        productCode,
        directoryCode,
        source,
      });
      yield put({
        type: 'ignoreProductSuccess',
        payload: {
          response,
          productCode,
          directoryCode,
        },
      });
      // 忽略成功之后，刷新列表
      yield put({
        type: 'fetchCustDetail',
        payload: {
          custId,
          custNumber,
          custSor,
        },
      });
    },
    * sendCustEmail({ payload: { clientIdSign = '', clientName = '', productCode = '', directoryCode = '' } }, { call, put }) {
      const response = yield call(api.sendProductEmail,
        {
          clientIdSign,
          clientName,
          productCode,
          directoryCode,
        });
      yield put({
        type: 'sendCustEmailSuccess',
        payload: {
          response,
          productCode,
          directoryCode,
        },
      });
    },
    // 获取客户简要通讯信息
    * getCustBrifeContact({ payload: { custNumber = 1, custSor = 1 } }, { call, put }) {
      const response = yield call(api.getCustBrifeContact, { custNumber, custSor });
      yield put({
        type: 'fetchCustBriefContactSuccess',
        payload: {
          response,
          custNumber,
          custSor,
        },
      });
    },
    // 获取客户基本信息
    * getCustBasic({ payload: { custNumber = 1, custSor = 'per', custId = 1 } }, { call, put }) {
      const response = yield call(api.getCustBasic, { custNumber, custSor, custId });
      yield put({
        type: 'getBasicSuccess',
        payload: {
          response,
          custNumber,
          custSor,
          custId,
        },
      });
    },
    // 编辑客户基本信息
    * updateCustBasic({ payload: { degreeCode, merriageCode, custId } }, { call, put }) {
      const response = yield call(api.updateCustBasic, { degreeCode, merriageCode, custId });
      yield put({
        type: 'updateBasicSuccess',
        payload: {
          response,
          degreeCode,
          merriageCode,
          custId,
        },
      });
      yield put(routerRedux.goBack());
    },
    // 更新客户个人联系方式
    * addOrUpdateContactPer({ payload, payload: { custId, custNumber, custSor,
      ...others } }, { call, put }) {
      yield call(api.addOrUpdateContactPer, payload);
      // yield put({
      //   type: 'addOrUpdateContactPerSuccess',
      //   payload: {
      //     response,
      //   },
      // });
      yield put({
        type: 'getPerContact',
        payload: {
          custNumber,
          custSor,
          custId,
        },
      });
    },
    // 获取个人客户联系方式
    * getPerContact({ payload: { custNumber = 1, custSor = 'per', custId = 1 } }, { call, put }) {
      const response = yield call(api.getCustCotact, { custNumber, custSor, custId });
      yield put({
        type: 'getContactSuccess',
        payload: {
          response,
          custNumber,
          custSor,
          custId,
        },
      });
    },
    // 获取机构联系人
    * getOrgContact({ payload: { custNumber = 1, custSor = 'org', custId = 1 } }, { call, put }) {
      const response = yield call(api.getCustCotact, { custNumber, custSor, custId });
      yield put({
        type: 'getContactListSuccess',
        payload: {
          response,
          custNumber,
          custSor,
          custId,
        },
      });
    },
    // 获取服务记录
    * getServiceList({ payload: { custSor = 'per', custId = 1 } }, { call, put }) {
      const response = yield call(api.getServiceList, { custSor, custId });
      yield put({
        type: 'getServiceListSuccess',
        payload: {
          response,
          custSor,
          custId,
        },
      });
    },
    // 获取客户列表
    * getList({
        payload: {
          custQueryType = 'personal',
      keywords = '',
      custNature = '',
      custType = '',
      custLevel = '',
      riskLevel = '',
      accountStatus = '',
      orderType = 'desc',
      pageSize = constants.pageSize,
      pageNum = 1,
      openDateStart = '',
      openDateEnd = '',
        },
      }, { call, put, select }) {
      const { postnId, postnName } = yield select(state => state.global.priPos);
      const list = yield call(
        api.getCustomerList,
        {
          custQueryType,
          keywords,
          custNature,
          custType,
          custLevel,
          riskLevel,
          accountStatus,
          orderType,
          pageSize,
          pageNum,
          openDateStart,
          openDateEnd,
          posId: postnId,
          posName: postnName,
        },
      );
      yield put({
        type: 'getListSuccess',
        payload: {
          list,
        },
      });
    },
    // 获取服务记录活动内容选项
    * getServiceContentOpts({ payload: { parCode = '' } }, { call, put }) {
      const response = yield call(api.getServiceContentOpts, { parCode });
      yield put({
        type: 'getContentOptsSuccess',
        payload: {
          response,
        },
      });
    },
    // 获取服务记录列表
    * getServiceRecordList({ payload: { custId = '', pageNum = 1 } }, { call, put }) {
      const authInfo = api.getAuthInfo();
      const response = yield call(
        api.getServiceRecordList,
        { custId, pageNum, empId: authInfo.empId },
      );
      yield put({
        type: 'getServiceRecordListSuccess',
        payload: {
          response,
          custId,
          pageNum,
        },
      });
    },
    // 添加服务记录
    * addCommonServeRecord({ payload }, { call, put }) {
      const response = yield call(api.addCommonServeRecord, payload);
      yield put({
        type: 'addCommonServeRecordSuccess',
        payload: response.code === '0',
      });
    },
    // 获取无任务服务留痕
    * getServiceType({ payload }, { call, put }) {
      const response = yield call(api.getServiceType, payload);
      yield put({
        type: 'getServiceTypeSuccess',
        payload: {
          response,
        },
      });
    },
    // 新增服务记录
    * addServiceRecord({ payload: {
      custId = '',
      custType = '',
      action = 'new',
      category = '',
      comment = '',
      desp = '',
      startTime = '',
      endTime = '',
      ownerId = '',
      priority = null,
      status = '',
      type = '',
      ani = null,
      actionChannel = 'HTSC Email',
    } }, { call, put }) {
      const response = yield call(api.addServiceRecord, {
        custId,
        custType,
        action,
        category,
        comment,
        desp,
        startTime,
        endTime,
        ownerId,
        priority,
        status,
        type,
        ani,
        actionChannel,
      });
      yield put({
        type: 'addServiceRecordSuccess',
        payload: {
          flag: response.msg,
        },
      });
    },
    // 获取开通业务数据
    * getBusinessList({ payload: { custSor = 'per', custId = 1 } }, { call, put }) {
      const response = yield call(api.getCustBusinessInfo, { custSor, custId });
      yield put({
        type: 'getBusinessListSuccess',
        payload: {
          response,
          custSor,
          custId,
        },
      });
    },

    // 添加联系人，保存属性值
    * saveContactOrg({ payload }, { put, select }) {
      const oldContactOrg = yield select(state => state.customer.addContact);
      const { name, value } = payload;
      yield put({
        type: 'addContactOrgSuccess',
        payload: Object.assign(oldContactOrg, { [name]: value }),
      });
      yield put(routerRedux.goBack());
    },

    // 删除联系人
    * delContactOrg({ payload }, { call, put }) {
      yield call(api.updatePersonnelInfo, payload);
      yield put(routerRedux.goBack());
    },

    // 更新机构客户的个人信息
    * updatePersonnelInfo({ payload: {
        mainFlag,
      num,
      rowId,
      arrRowId = '',
      op,
      value,
      custId,
      } }, { call, put }) {
      const condition = {
        custSor: 'org',
        custNumber: num,
        rowId,
      };
      if (mainFlag === 'Y') {
        condition.mainFlag = true;
      } else {
        condition.mainFlag = false;
      }
      if (op === 'name') {
        condition[op] = value;
      } else if (op === 'custRela') {
        condition.custRela = value.selectValue;
        condition.custRelaCd = value.selectKey;
      } else if (op === 'mainFlag') {
        condition.mainFlag = !!value.selectKey;
      } else if (_.includes(['cellPhones', 'workTels', 'homeTels', 'emailAddresses'], op)) {
        if (arrRowId) {
          condition[op] = [{ contactValue: value, rowId: arrRowId }];
        } else {
          condition[op] = [{ contactValue: value }];
        }
      }
      yield call(api.updatePersonnelInfo, condition);
      const res = yield call(api.getCustCotact, { custNumber: num, custSor: 'org', custId });
      yield put({
        type: 'getContactListSuccess',
        payload: {
          response: res,
          custNumber: num,
          custSor: 'org',
          custId,
        },
      });
      yield put(routerRedux.goBack());
    },

    // 添加联系人
    * addContactsInfo({ payload }, { call, put }) {
      console.log('addContactsInfo', payload);
      yield call(api.updatePersonnelInfo, payload);
      // 先释放loading，再解决toast delay之后，进行goBack
      yield put({
        type: 'toastM',
        message: '新增成功',
        delay: 1,
      });
    },
    * toastM({ message, delay }, { put }) {
      yield toast(message, delay);
      yield put(routerRedux.goBack());
    },
  },
  subscriptions: {},
};
