/**
 * @file models/mission.js
 * @author fengwencong
 */

import _ from 'lodash';
import api from '../api';

const EMPTY_OBJECT = {};
const EMPTY_LIST = [];

export default {
  namespace: 'mission',
  state: {
    // 任务详情
    motDetail: EMPTY_OBJECT,
    missionCenter: EMPTY_OBJECT,
    isSendSuccess: false,
    email: '',
    isSavingEmail: false,
    isSavingRecord: false,
    flagArray: EMPTY_LIST, // 记录当前点击的任务项ID
    recordPageNeedfulData: EMPTY_OBJECT, // 服务记录页面需要的数据
    batchTaskMissionIdList: EMPTY_LIST, // 代办任务页面选中的任务id的数组
  },
  reducers: {
    // 获取任务详情成功
    getMotDetailSuccess(state, action) {
      const { payload: { response, motTaskId } } = action;
      const resultData = response.resultData || EMPTY_OBJECT;
      const {
        taskPage = EMPTY_OBJECT,
        taskCustList = EMPTY_LIST,
        summary = EMPTY_OBJECT,
      } = resultData;
      const { motDetail } = state;
      const { taskCustList: preData } = motDetail[motTaskId] || EMPTY_LIST;

      return {
        ...state,
        motDetail: {
          ...motDetail,
          [motTaskId]: {
            taskPage,
            summary,
            taskCustList: taskPage.curPageNum === 1 ? taskCustList : [...preData, ...taskCustList],
          },
        },
      };
    },
    getCenterSuccess(state, action) {
      const { payload: { missionCenter: { resultData = EMPTY_OBJECT } } } = action;
      return {
        ...state,
        missionCenter: resultData,
      };
    },
    // 服务实施记录保存成功
    getSavedSIRSuccess(state, action) {
      const { payload: { saveRecordResult } } = action;
      return {
        ...state,
        saveRecordResult,
        isSavingRecord: false,
      };
    },
    getSaveRecordState(state) {
      return {
        ...state,
        isSavingRecord: true,
      };
    },
    sendMailSuccess(state, action) {
      const { payload: { isSendSuccess } } = action;
      return {
        ...state,
        isSavingEmail: false,
        isSendSuccess,
      };
    },
    getReceiverMailAddRequest(state) {
      return {
        ...state,
        isSavingEmail: true,
      };
    },
    getReceiverMailAddrSuccess(state, action) {
      const { payload: { email } } = action;
      return {
        ...state,
        email,
      };
    },
    getFlagArraySuccess(state, action) {
      const { payload: { motTaskId: flag } } = action;
      const { flagArray } = state;
      return {
        ...state,
        flagArray: [...flagArray, flag],
      };
    },
    removeFlagArraySuccess(state) {
      return {
        ...state,
        flagArray: EMPTY_LIST,
      };
    },
    // 保存服务记录页面需要的数据
    saveRecordPageNeedfulDataSuccess(state, action) {
      const { payload } = action;
      return {
        ...state,
        recordPageNeedfulData: payload,
      };
    },
    // 保存代办任务中选中的多条任务，用于刷任务详情页面的缓存
    saveBatchTaskMissionIdListSuccess(state, action) {
      const { payload: { missionIdList } } = action;
      const { batchTaskMissionIdList } = state;
      return {
        ...state,
        batchTaskMissionIdList: [
          ...batchTaskMissionIdList,
          ...missionIdList,
        ],
      };
    },
    // 如若进入相亲页面刷新了这条任务，应该把这条任务的任务id从数组中去掉
    removeOneTaskMissionIdSuccess(state, action) {
      const { payload: { missionId } } = action;
      const { batchTaskMissionIdList } = state;
      // 对批量处理的任务id组成的数组进行去重
      const uniqedMissionIdList = _.uniq(batchTaskMissionIdList);
      // 去重之后进行过滤，去掉已经刷新过的这条任务
      const filteredMissionIdlist = _.filter(uniqedMissionIdList, item => item !== missionId);
      return {
        ...state,
        batchTaskMissionIdList: [
          ...filteredMissionIdlist,
        ],
      };
    },
  },
  effects: {
    // 获取任务详情
    * fetchMotDetail({ payload: { motTaskId = 1, pageNum = 1, pageSize = 10 } }, { call, put }) {
      const response = yield call(api.getMotDetail, { motTaskId, pageNum, pageSize });
      yield put({
        type: 'getMotDetailSuccess',
        payload: {
          response,
          motTaskId,
        },
      });
    },
    * getCenter({ payload }, { call, put }) {
      const missionCenter = yield call(api.getMissionCenter);
      yield put({
        type: 'getCenterSuccess',
        payload: {
          missionCenter,
        },
      });
    },
    * sendMail({ payload: query }, { call, put }) {
      yield put({
        type: 'getReceiverMailAddRequest',
      });
      const response = yield call(api.sendMail, query);
      if (response.resultData) {
        const { isSuccess } = response.resultData;
        yield put({
          type: 'sendMailSuccess',
          payload: {
            isSendSuccess: isSuccess,
          },
        });
      }
    },
    * getReceiverMailAddr({ payload: query }, { call, put }) {
      const response = yield call(api.getReceiverMailAddr, query);
      if (response.resultData) {
        const { email } = response.resultData;
        yield put({
          type: 'getReceiverMailAddrSuccess',
          payload: {
            email,
          },
        });
      }
    },
    * saveSIRecord({ payload: query }, { call, put }) {
      yield put({
        type: 'getSaveRecordState',
      });
      const saveRecordResult = yield call(api.saveServiceImplementRecord, query);
      // 此处在保存成功后
      yield put({
        type: 'getSavedSIRSuccess',
        payload: {
          saveRecordResult,
        },
      });
    },
  },
  subscriptions: {},
};
