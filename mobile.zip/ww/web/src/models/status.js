/**
 * @file models/tatusjs
 *  跨页面状态保持，如a页面tab index变化后，跳到b页面再回到a页面时，
 *  需保持原tab index状态, 此类变量全部在此文件维护
 * @author maoquan(maoquan@htsc.com)
 */

export default {
  namespace: 'status',
  state: {
    customerTabIndex: 0,
    customerDetailTabIndex: {},
  },
  reducers: {
    changeCustomerTabIndex(state, { payload }) {
      return {
        ...state,
        customerTabIndex: payload,
      };
    },
    changeCustomerDetailTabIndex(state, action) {
      const { payload: { custId, activeKey } } = action;
      return {
        ...state,
        customerDetailTabIndex: {
          ...state.customerDetailTabIndex,
          [custId]: {
            activeKey,
          },
        },
      };
    },
  },
  effects: {},
  subscriptions: {},
};
