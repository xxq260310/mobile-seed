/**
 * @file product/DetailMoreInfo.js
 * @author xuxiaoqin
 */

import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import classnames from 'classnames';
import _ from 'lodash';
import { List } from 'antd-mobile';
import './detailMoreInfo.less';

const Item = List.Item;
const EMPTY_OBJECT = {};

export default class DetailMoreInfo extends PureComponent {

  static propTypes = {
    data: PropTypes.object,
    push: PropTypes.func,
    location: PropTypes.object,
  }

  static defaultProps = {
    push: () => { },
    data: {},
    location: {},
  }

  constructor(props) {
    super(props);
    this.state = {
      disableInvestArea: true,
      disableInvestLimit: true,
      disableInvestObjective: true,
      disableInvestStrategy: true,
    };
  }

  @autobind
  handleClick(type) {
    const { push, location: { query: { productCode, directoryCode } } } = this.props;
    push(`/product/detailDescription?investType=${type}&productCode=${productCode}&directoryCode=${directoryCode}`);
  }

  render() {
    const { data, location: { query: { productCode, directoryCode } } } = this.props;
    const productDetailData = data[`${productCode}_${directoryCode}`] || EMPTY_OBJECT;
    let { sipInfo = {} } = productDetailData;
    if (sipInfo === null) {
      sipInfo = {};
    }

    const {
      investArea = '',
      investLimit = '',
      investObjective = '',
      investStrategy = '',
     } = sipInfo;

    if (!_.isEmpty(investArea)) {
      this.state.disableInvestArea = false;
    }
    if (!_.isEmpty(investLimit)) {
      this.state.disableInvestLimit = false;
    }
    if (!_.isEmpty(investObjective)) {
      this.state.disableInvestObjective = false;
    }
    if (!_.isEmpty(investStrategy)) {
      this.state.disableInvestStrategy = false;
    }

    const investLimitClass = classnames({
      invest_limit: true,
      invest_disable: _.isEmpty(investLimit),
    });

    const investAreaClass = classnames({
      invest_area: true,
      invest_disable: _.isEmpty(investArea),
    });

    const investObjectiveClass = classnames({
      invest_objective: true,
      invest_disable: _.isEmpty(investObjective),
    });

    const investStrategyClass = classnames({
      invest_strategy: true,
      invest_disable: _.isEmpty(investStrategy),
    });

    return (
      <div className="productDetailMoreInfoSection">
        <Item
          className={investLimitClass}
          arrow="horizontal"
          multipleLine
          onClick={() => this.handleClick('investLimit')}
          disabled={this.state.disableInvestLimit}
        >
          <div className="more">投资限制</div>
        </Item>
        <Item
          className={investObjectiveClass}
          arrow="horizontal"
          multipleLine
          onClick={() => this.handleClick('investObjective')}
          disabled={this.state.disableInvestObjective}
        >
          <div className="more">投资目标</div>
        </Item>
        <Item
          className={investAreaClass}
          arrow="horizontal"
          multipleLine
          onClick={() => this.handleClick('investArea')}
          disabled={this.state.disableInvestArea}
        >
          <div className="more">投资范围</div>
        </Item>
        <Item
          className={investStrategyClass}
          arrow="horizontal"
          multipleLine
          onClick={() => this.handleClick('investStrategy')}
          disabled={this.state.disableInvestStrategy}
        >
          <div className="more">投资策略</div>
        </Item>
      </div>
    );
  }
}
