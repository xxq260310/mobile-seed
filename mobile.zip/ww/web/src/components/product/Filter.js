import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import _ from 'lodash';
import './filter.less';

class Filter extends PureComponent {
  static propTypes = {
    onOpenChange: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    replace: PropTypes.func.isRequired,
  };

  static defaultProps = {
    getList: () => {},
    location: {},
    replace: () => {},
  }

  constructor(props) {
    super(props);

    this.state = {
      filter: {
        riskLevel: '',
        bfMaturityMin: '',
        bfMaturityMax: '',
        firstParticipationMin: '',
        firstParticipationMax: '',
      },
    };
  }

  componentWillMount() {
    const {
      riskLevel = '',
      bfMaturityMin = '',
      bfMaturityMax = '',
      firstParticipationMin = '',
      firstParticipationMax = '',
    } = this.props.location.query;
    this.setState({
      filter: {
        riskLevel,
        bfMaturityMin,
        bfMaturityMax,
        firstParticipationMin,
        firstParticipationMax,
      },
    });
  }

  @autobind
  getClass(key, val) {
    const { filter } = this.state;
    if (typeof filter[key] === 'string') {
      if (filter[key] === val) {
        return 'filtSel';
      }
    } else if (filter[key] instanceof Array) {
      if (_.find(filter[key], str => str === val)) {
        return 'filtSel';
      }
    }
    return '';
  }

  @autobind
  handleStatusSel(val) {
    const prevFilter = this.state.filter;
    const { accountStatus: status } = prevFilter;
    if (_.find(status, str => str === val)) {
      status.splice(_.findIndex(status, str => str === val), 1);
    } else {
      status.push(val);
    }
    this.setState({
      filter: {
        ...prevFilter,
        accountStatus: status,
      },
    });
  }

  @autobind
  handleRiskSel(val) {
    const prevFilter = this.state.filter;
    const { riskLevel } = prevFilter;
    if (riskLevel === val) {
      this.setState({
        filter: {
          ...prevFilter,
          riskLevel: '',
        },
      });
    } else {
      this.setState({
        filter: {
          ...prevFilter,
          riskLevel: val,
        },
      });
    }
  }

  @autobind
  handleMaturitySel(val) {
    const prevFilter = this.state.filter;
    const { bfMaturityMin } = prevFilter;
    if (bfMaturityMin === val) {
      this.setState({
        filter: {
          ...prevFilter,
          bfMaturityMin: '',
          bfMaturityMax: '',
        },
      });
    } else {
      let min = '';
      let max = '';
      switch (val) {
        case '0':
          min = '0';
          max = '30';
          break;
        case '30':
          min = '30';
          max = '90';
          break;
        case '90':
          min = '90';
          max = '360';
          break;
        case '360':
          min = '360';
          max = '';
          break;
        default:
          min = '';
          max = '';
          break;
      }
      this.setState({
        filter: {
          ...prevFilter,
          bfMaturityMin: min,
          bfMaturityMax: max,
        },
      });
    }
  }

  @autobind
  handleParticipationSel(val) {
    const prevFilter = this.state.filter;
    const { firstParticipationMin } = prevFilter;
    if (firstParticipationMin === val) {
      this.setState({
        filter: {
          ...prevFilter,
          firstParticipationMin: '',
          firstParticipationMax: '',
        },
      });
    } else {
      let min = '';
      let max = '';
      switch (val) {
        case '0':
          min = '0';
          max = '50000';
          break;
        case '50000':
          min = '50000';
          max = '300000';
          break;
        case '300000':
          min = '300000';
          max = '1000000';
          break;
        case '1000000':
          min = '1000000';
          max = '';
          break;
        default:
          min = '';
          max = '';
          break;
      }
      this.setState({
        filter: {
          ...prevFilter,
          firstParticipationMin: min,
          firstParticipationMax: max,
        },
      });
    }
  }

  @autobind
  filterSub() {
    const { replace, location: { query } } = this.props;
    replace({
      pathname: '/product',
      query: {
        ...query,
        riskLevel: this.state.filter.riskLevel,
        bfMaturityMin: this.state.filter.bfMaturityMin,
        bfMaturityMax: this.state.filter.bfMaturityMax,
        firstParticipationMin: this.state.filter.firstParticipationMin,
        firstParticipationMax: this.state.filter.firstParticipationMax,
      },
    });
    this.props.onOpenChange();
  }

  @autobind
  filterReset() {
    this.setState({
      filter: {
        riskLevel: '',
        bfMaturityMin: '',
        bfMaturityMax: '',
        firstParticipationMin: '',
        firstParticipationMax: '',
      },
    });
  }

  render() {
    return (
      <div className="filterWrapper">
        <div className="filterScroll">
          <h3>
            <div>投资者风险等级建议</div>
          </h3>
          <div className="filterBox">
            <div className="flexBox">
              <p
                className={this.getClass('riskLevel', '1')}
                onClick={() => this.handleRiskSel('1')}
              >
                高风险
              </p>
              <p
                className={this.getClass('riskLevel', '2')}
                onClick={() => this.handleRiskSel('2')}
              >
                中高风险
              </p>
              <p
                className={this.getClass('riskLevel', '3')}
                onClick={() => this.handleRiskSel('3')}
              >
                中等风险
              </p>
            </div>
            <div className="flexBox">
              <p
                className={this.getClass('riskLevel', '4')}
                onClick={() => this.handleRiskSel('4')}
              >
                中低风险
              </p>
              <p
                className={this.getClass('riskLevel', '5')}
                onClick={() => this.handleRiskSel('5')}
              >
                低风险
              </p>
            </div>
          </div>
          <h3>
            <div>投资期限</div>
          </h3>
          <div className="filterBox">
            <div className="flexBox">
              <p
                className={this.getClass('bfMaturityMin', '0')}
                onClick={() => this.handleMaturitySel('0')}
              >
                小于1个月
              </p>
              <p
                className={this.getClass('bfMaturityMin', '30')}
                onClick={() => this.handleMaturitySel('30')}
              >
                1-3个月
              </p>
              <p
                className={this.getClass('bfMaturityMin', '90')}
                onClick={() => this.handleMaturitySel('90')}
              >
                3-12个月
              </p>
            </div>
            <div className="flexBox">
              <p
                className={this.getClass('bfMaturityMin', '360')}
                onClick={() => this.handleMaturitySel('360')}
              >
                大于12个月
              </p>
            </div>
          </div>
          <h3>
            <div>起购金额</div>
          </h3>
          <div className="filterBox">
            <div className="flexBox">
              <p
                className={this.getClass('firstParticipationMin', '0')}
                onClick={() => this.handleParticipationSel('0')}
              >
                5万以内
              </p>
              <p
                className={this.getClass('firstParticipationMin', '50000')}
                onClick={() => this.handleParticipationSel('50000')}
              >
                5-30万
              </p>
              <p
                className={this.getClass('firstParticipationMin', '300000')}
                onClick={() => this.handleParticipationSel('300000')}
              >
                30-100万
              </p>
            </div>
            <div className="flexBox">
              <p
                className={this.getClass('firstParticipationMin', '1000000')}
                onClick={() => this.handleParticipationSel('1000000')}
              >
                100万以上
              </p>
            </div>
          </div>
        </div>
        <div className="filterBtn">
          <div className="filterReset" onClick={this.filterReset}>重置</div>
          <div className="filterSub" onClick={this.filterSub}>确定</div>
        </div>
      </div>
    );
  }
}

export default Filter;
