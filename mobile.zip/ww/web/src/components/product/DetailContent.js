/**
 * @file product/DetailHeader.js
 * @author xuxiaoqin
 */

import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import _ from 'lodash';
import { List, Flex, Modal } from 'antd-mobile';

import './detailContent.less';

const ListItem = List.Item;
const FlexItem = Flex.Item;
// const EMPTY_LIST = [];
const EMPTY_OBJECT = {};
export default class ProductDetailContent extends PureComponent {

  static propTypes = {
    data: PropTypes.object,
    push: PropTypes.func,
    location: PropTypes.object.isRequired,
  }

  static defaultProps = {
    push: () => { },
    data: {},
  }

  constructor(props) {
    super(props);
    this.state = {
      isShowInfo: false,
      name: '',
      detailInfo: '',
    };
  }

  setDetailInfoHeight() {
    // 设置一下弹出dialog的高度
    const modalBody = document.querySelector('.am-modal .am-modal-body');
    if (modalBody) {
      modalBody.style.maxHeight = `${document.documentElement.clientHeight * 0.4}px`;
    }
  }

  formatDate(date) {
    if (!_.isEmpty(date) && date !== '- -') {
      const tempDateArray = date.split(/[-/]/);
      return `${tempDateArray[0]}年${tempDateArray[1]}月${tempDateArray[2]}日`;
    }
    return '/';
  }

  @autobind
  handleClick() {
    const { push, location: { query: { productCode, directoryCode } } } = this.props;
    push(`/product/detailMoreInfo?productCode=${productCode}&directoryCode=${directoryCode}`);
  }

  @autobind
  handleInfoClick(name, info) {
    this.setState({
      isShowInfo: true,
      name,
      detailInfo: info,
    }, this.setDetailInfoHeight);
  }

  @autobind
  handleInfoClose() {
    this.setState({ isShowInfo: false });
  }

  filterAllSpace(data) {
    let tempHtml = '';
    if (!data) {
      tempHtml = '- -';
    } else if (data.match(/^[ ]+$/)) {
      tempHtml = '- -';
    } else {
      tempHtml = data;
    }

    return tempHtml;
  }

  render() {
    const { data = EMPTY_OBJECT } = this.props;
    let {
      startSalesDate,
      endSalesDate,
    } = data;

    if (startSalesDate === null) {
      startSalesDate = '';
    }

    if (endSalesDate === null) {
      endSalesDate = '';
    }

    const startSalesDateHtml = this.formatDate(startSalesDate);
    const endSalesDateHtml = this.formatDate(endSalesDate);

    const dateHtml = `${startSalesDateHtml}-${endSalesDateHtml}`;

    const { name, isShowInfo, detailInfo } = this.state;

    const closedPeriodHtml = this.filterAllSpace(data.closedPeriod);

    const openPeriodHtml = this.filterAllSpace(data.openPeriod);

    return (
      <div className="productDetailContentSection">
        <div className="introduction">
          <span>基金简介</span>
        </div>
        <div className="description">
          <Flex className="flex-container" direction="row" justify="start" align="center" wrap="nowrap">
            <FlexItem>
              <div className="detailItemTitle">
                <i className="managerIcon" />
                <span className="managerTitle">基金经理</span>
              </div>
            </FlexItem>
            <FlexItem>
              <div className="detailItemContent">
                {data.managers || '- -'}
              </div>
            </FlexItem>
          </Flex>
          <div className="list-separator" />
          <Flex className="flex-container" direction="row" justify="start" align="center" wrap="nowrap">
            <FlexItem>
              <div className="detailItemTitle">
                <i className="companyIcon" />
                <span className="companyTitle">基金公司</span>
              </div>
            </FlexItem>
            <FlexItem>
              <div className="detailItemContent">
                {data.managementCom || '- -'}
              </div>
            </FlexItem>
          </Flex>
          <div className="list-separator" />
          <Flex className="flex-container" direction="row" justify="start" align="center" wrap="nowrap">
            <FlexItem>
              <div className="detailItemTitle">
                <i className="closeIcon" />
                <span className="closeTitle">封闭期</span>
              </div>
            </FlexItem>
            <FlexItem>
              <div className="detailItemContent" onClick={() => this.handleInfoClick('封闭期', closedPeriodHtml)}>
                {closedPeriodHtml}
              </div>
            </FlexItem>
          </Flex>
          <div className="list-separator" />
          <Flex className="flex-container" direction="row" justify="start" align="center" wrap="nowrap">
            <FlexItem>
              <div className="detailItemTitle">
                <i className="openIcon" />
                <span className="openTitle">开放期</span>
              </div>
            </FlexItem>
            <FlexItem>
              <div className="detailItemContent" onClick={() => this.handleInfoClick('开放期', openPeriodHtml)} >
                {openPeriodHtml}
              </div>
            </FlexItem>
          </Flex>
          <div className="list-separator" />
          <Flex className="flex-container" direction="row" justify="start" align="center" wrap="nowrap">
            <FlexItem>
              <div className="detailItemTitle">
                <i className="sellIcon" />
                <span className="sellTitle">预计销售时间</span>
              </div>
            </FlexItem>
            <FlexItem>
              <div className="detailItemContent">
                {dateHtml}
              </div>
            </FlexItem>
          </Flex>
          <div className="list-separator" />
          <ListItem className="moreSection" arrow="horizontal" multipleLine onClick={this.handleClick}>
            <div className="more">更多信息</div>
          </ListItem>
        </div>
        {// 每次都重新创建modal弹框，若重用弹框，会记住滑动的offset，不符合需求。
          isShowInfo
          ?
            <Modal
              title={name}
              transparent
              maskClosable={false}
              visible={isShowInfo}
              footer={[{ text: '确定', onPress: this.handleInfoClose }]}
              onClose={this.handleInfoClose}
            >
              <div dangerouslySetInnerHTML={{ __html: detailInfo }} />
            </Modal> : null
        }
      </div>
    );
  }
}
