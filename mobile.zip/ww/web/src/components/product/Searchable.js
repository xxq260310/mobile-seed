/**
 * @file components/product/Searchable.js
 * 产品搜索组件
 * @author wangjunjun(junjun.wang@cienet.com.cn)
 */

import React, { PropTypes, PureComponent } from 'react';
import { SearchBar, List } from 'antd-mobile';
import { autobind } from 'core-decorators';
import localforage from 'localforage';
import _ from 'lodash';

import helper from '../../utils/helper';
import Icon from '../common/Icon';
import './searchable.less';

const Item = List.Item;

const SHOW_MODE = {
  NORMAL: 'NORMAL',
  SEARCHING: 'SEARCHING',
};

const HISTORY_KEY = 'PRODUCT_HISTORY_KEYWORD';

/**
 * iphone下的safari隐私模式会导致setItem抛出异常
 * 如果有异常就静默失败
 */
const setItem = (key, value) => localforage
  .setItem(key, value)
  .catch(() => {});

export default (ComposedComponent) => {
  class SearchableComponent extends PureComponent {

    static propTypes = {
      push: PropTypes.func,
      replace: PropTypes.func,
      goBack: PropTypes.func,
      location: PropTypes.object.isRequired,
    }

    static defaultProps = {
      goBack: () => {},
      push: () => {},
      replace: () => {},
    }

    constructor(props) {
      super(props);
      const { location: { query: { keywords } } } = props;
      this.state = {
        mode: SHOW_MODE.NORMAL,
        value: this.isInResultPage() ? decodeURIComponent(keywords) : '',
        historyList: [],
        historyListHeight: 0,
      };
      this.syncHistoryToState();
    }

    componentDidMount() {
      this.setHistoryListHeight();
    }

    componentWillReceiveProps(nextProps) {
      const isInResultPage = this.isInResultPage();
      const { location: { query: { keywords } } } = nextProps;
      this.setState({
        mode: isInResultPage ? SHOW_MODE.NORMAL : (this.state.mode || SHOW_MODE.NORMAL),
        value: isInResultPage ? decodeURIComponent(keywords) : '',
      });
      this.syncHistoryToState();
    }

    componentDidUpdate() {
      const touchEle = document.querySelector('.am-tab-bar-tabpane-active');
      if (touchEle) {
        if (this.state.mode === SHOW_MODE.SEARCHING) {
          touchEle.addEventListener('touchmove', helper.hideKeyboard, false);
        } else {
          touchEle.removeEventListener('touchmove', helper.hideKeyboard, false);
        }
      }
      this.setHistoryListHeight();
    }

    setHistoryListHeight() {
      this.setState({
        historyListHeight: helper.getAvailableHeight({ el: ['.fixed-header'] }),
      });
    }

    getNavMethod() {
      const { push, replace } = this.props;
      const isInResultPage = this.isInResultPage();
      return isInResultPage ? replace : push;
    }

    async getHistoryList() {
      let historyList = await localforage.getItem(HISTORY_KEY);
      if (!historyList) {
        historyList = [];
        await setItem(HISTORY_KEY, historyList);
      }
      return historyList;
    }

    async saveHistory(keywords) {
      let historyList = await this.getHistoryList();
      if (_.includes(historyList, keywords)) {
        historyList = historyList.filter(item => item !== keywords);
      }
      historyList.unshift(keywords);
      if (historyList.length > 10) {
        historyList.pop();
      }
      await setItem(HISTORY_KEY, historyList);
      this.setState({
        historyList,
      });
    }

    @autobind
    async removeHistory(keywords) {
      let historyList = await this.getHistoryList();
      if (_.includes(historyList, keywords)) {
        historyList = historyList.filter(item => item !== keywords);
      }
      await setItem(HISTORY_KEY, historyList);
      this.setState({
        historyList,
      });
    }

    syncHistoryToState() {
      this.getHistoryList().then(
        historyList => this.setState({
          historyList,
        }),
      );
    }

    isInResultPage() {
      const { location } = this.props;
      return /search-result/.test(location.pathname);
    }

    @autobind
    handleRemoveClick(e, keywords) {
      e.preventDefault();
      e.stopPropagation();
      this.removeHistory(keywords);
    }

    @autobind
    handleHistoryItemClick(keywords) {
      this.handleSubmit(keywords);
    }

    @autobind
    handleFocus() {
      if (this.state.mode === SHOW_MODE.NORMAL
        && !this.isInResultPage()) {
        this.setState({ mode: SHOW_MODE.SEARCHING });
      }
    }

    @autobind
    handleChange(text) {
      const stateMap = { value: text };
      if (text === '') {
        stateMap.mode = SHOW_MODE.SEARCHING;
      }
      this.setState(stateMap);
    }

    @autobind
    handleCancel() {
      const { goBack } = this.props;
      if (this.isInResultPage()) {
        goBack();
      } else {
        this.setState({
          mode: SHOW_MODE.NORMAL,
          value: '',
        });
      }
    }

    @autobind
    async handleSubmit(keywords) {
      if (!keywords) {
        return;
      }
      // blur以收回键盘
      const searchElem = document.querySelector('input[type=search]');
      if (searchElem) {
        searchElem.blur();
      }
      const { location: { query } } = this.props;
      await this.saveHistory(keywords);
      this.getNavMethod()({
        pathname: '/product/search-result',
        query: {
          ...query,
          keywords: encodeURIComponent(keywords),
        },
      });
    }

    renderHistoryHeader() {
      return (<p>历史搜索结果</p>);
    }

    @autobind
    renderCrossIcon(keywords) {
      return (
        <Icon
          type="close"
          data-item={keywords}
          onClick={e => this.handleRemoveClick(e, keywords)}
        />
      );
    }

    renderClockIcon() {
      return (
        <Icon type="clock" />
      );
    }

    renderHistory() {
      const { historyListHeight, historyList } = this.state;
      return (
        <List
          renderHeader={this.renderHistoryHeader}
          className="history-list"
          style={{ height: historyListHeight }}
        >
          {historyList.map(
            keywords => (
              <Item
                thumb={this.renderClockIcon()}
                key={encodeURIComponent(keywords)}
                extra={this.renderCrossIcon(keywords)}
                onClick={() => this.handleHistoryItemClick(keywords)}
              >{keywords}</Item>
            ),
          )}
        </List>
      );
    }

    render() {
      const { mode, value } = this.state;
      let mainElems;
      if (mode === SHOW_MODE.NORMAL) {
        mainElems = <ComposedComponent {...this.props} />;
      } else if (mode === SHOW_MODE.SEARCHING) {
        mainElems = this.renderHistory();
      }
      return (
        <div className="product-search">
          <div className="product-header fixed-header">
            <SearchBar
              className="product-header-search"
              placeholder="产品名称/产品号"
              value={value}
              onFocus={this.handleFocus}
              onChange={this.handleChange}
              onCancel={this.handleCancel}
              onSubmit={this.handleSubmit}
              showCancelButton={mode !== SHOW_MODE.NORMAL}
            />
          </div>
          {mainElems}
        </div>
      );
    }
  }
  return SearchableComponent;
};
