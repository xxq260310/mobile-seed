/**
 * @file product/DetailHeader.js
 * @author xuxiaoqin
 */

import React, { PropTypes, PureComponent } from 'react';
// import { autobind } from 'core-decorators';
// import classnames from 'classnames';
import _ from 'lodash';
import './detailHeader.less';

const EMPTY_OBJECT = {};
export default class ProductDetailHeader extends PureComponent {

  static propTypes = {
    // 产品基本信息数据
    data: PropTypes.object,
    push: PropTypes.func,
  }

  static defaultProps = {
    push: () => { },
    data: {},
  }

  filterMoney(assetData) {
    let tempData = '0元';
    if (assetData && assetData.toString().indexOf('.') !== -1) {
      // 小数
      const temp = assetData.toString().split('.');
      if (temp[0].length >= 1 && temp[0].length <= 3) {
        tempData = `${Number.parseFloat(assetData).toFixed(0)}元`;
      } else if (temp[0].length > 3 && temp[0].length < 9) {
        tempData = `${(Number.parseFloat(temp[0]) / 10000).toFixed(0)}万元`;
      } else if (temp[0].length > 8) {
        tempData = `${(Number.parseFloat(temp[0]) / 100000000).toFixed(0)}亿元`;
      }
    } else if (assetData && assetData.toString().length >= 0
      && assetData.toString().length <= 4) {
      tempData = `${assetData}元`;
    } else if (assetData !== null && assetData.toString().length > 4
      && assetData.toString().length < 9) {
      tempData = `${(assetData / 10000).toFixed(0)}万元`;
    } else if (assetData !== null && assetData.toString().length >= 9) {
      tempData = `${(assetData / 100000000).toFixed(0)}亿元`;
    }

    return tempData;
  }

  render() {
    const { data = EMPTY_OBJECT } = this.props;

    let risk = '';
    if (data.riskLevel) {
      switch (data.riskLevel) {
        case 1:
          risk = '高风险';
          break;
        case 2:
          risk = '中高风险';
          break;
        case 3:
          risk = '中风险';
          break;
        case 4:
          risk = '中低风险';
          break;
        case 5:
          risk = '低风险';
          break;
        default:
          risk = '- -';
      }
    } else {
      risk = '- -';
    }

    let firistParticipationHtml = '- -';
    if (data.firistParticipation) {
      firistParticipationHtml = this.filterMoney(data.firistParticipation);
    }

    return (
      <div className="productDetailHeaderSection">
        <div className="description">
          <div className="productName">{data.prdtName || '- -'}</div>
          <div className="productInfo">
            <div className="productCode">{data.prdtCode || '- -'}</div>
            <div className="productCategory">{data.categoryName || '- -'}</div>
          </div>
          <div className="value">
            <div className="latestValue">{data.unitNav || '- -'}</div>
            <div className="latestDescription">
              最新净值({!_.isEmpty(data.netDate) ? data.netDate.replace(/[-/]/g, '-').slice(0, 10) : '- -'})更新
            </div>
          </div>
        </div>
        <div className="riskSection">
          <div className="asset">
            <div className="assetValue">
              <span>{(firistParticipationHtml && firistParticipationHtml !== '- -'
                && parseInt(firistParticipationHtml, 10)) || '- -'}</span>
              <span>{(firistParticipationHtml && firistParticipationHtml !== '- -'
                && firistParticipationHtml
                  .slice(parseInt(firistParticipationHtml, 10).toString().length,
                  firistParticipationHtml.length)) || ''}</span>
            </div>
            <div className="assetDescription">首次购买</div>
          </div>
          <div className="risk">
            <div className="riskLevel">{risk}</div>
            <div className="riskDescription">风险等级</div>
          </div>
        </div>
      </div>
    );
  }
}
