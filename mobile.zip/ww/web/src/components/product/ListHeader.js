/**
 * @file product/ListHeader.js
 * @author fengwencong
 */
import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import { Menu } from 'antd-mobile';
import classnames from 'classnames';

import { options } from '../../config';
import Icon from '../../components/common/Icon';
import './listheader.less';

const statusOptions = options.statusOptions;
const sortOptions = options.sortOptions;
const productOptions = options.productOptions;

const columnLimit = '2';
const columnFund = '5';
const sortDown = '1';
const sortUp = '2';

export default class ProductHeader extends PureComponent {

  static propTypes = {
    onOpenChange: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    replace: PropTypes.func.isRequired,
    maskShow: PropTypes.bool.isRequired,
    popMaskShow: PropTypes.func.isRequired,
  }

  constructor(props) {
    super(props);
    // 此产品首页有三个menu
    const { location: { query } } = this.props;
    const productMenuInit = [];
    const statusMenuInit = [];
    const sortMenuInit = [];

    // 计算出产品类型的初始值
    if (query.prdTypeCode) {
      // prdTypeCode的前8位是具体产品的类型代号
      productMenuInit.push(query.prdTypeCode.substring(0, 8));
      productMenuInit.push(query.prdTypeCode);
    } else {
      productMenuInit.push('all');
    }
    // 计算出交易状态的初始值
    if (query.salesStatus) {
      statusMenuInit.push(query.salesStatus);
    } else {
      statusMenuInit.push('all');
    }
    // 计算出排序的初始值
    if (query.sortColumn && query.sortType) {
      sortMenuInit.push(this.getSortSelectValue(query.sortColumn, query.sortType));
    } else {
      sortMenuInit.push('init');
    }

    this.state = {
      productMenuShow: false,
      statusMenuShow: false,
      sortMenuShow: false,
      productMenuValue: productMenuInit,
      statusMenuValue: statusMenuInit,
      sortMenuValue: sortMenuInit,
      sortColumn: query.sortColumn ? query.sortColumn : columnLimit,
      sortType: query.sortType ? query.sortType : sortDown,
      productName: query.prdTypeCode ? this.getProductMenuLabel(query.prdTypeCode) : '产品类型',
      statusName: statusMenuInit[0] === 'all'
      ? '交易状态' : this.getStatusMenuLabel(statusMenuInit[0]),
      sortName: this.getSortMenuLabel(sortMenuInit[0]),
      productClass: productMenuInit[0] === 'all' ? 'all' : 'sel',
      statusClass: statusMenuInit[0] === 'all' ? 'all' : 'sel',
      sortClass: sortMenuInit[0] === 'init' ? 'all' : 'sel',
    };
  }

  componentWillReceiveProps(nextProps) {
    const { maskShow } = nextProps;
    if (!maskShow) {
      this.setState({
        productMenuShow: false,
        statusMenuShow: false,
        sortMenuShow: false,
      });
    }
  }

  @autobind
  getStatusMenuLabel(val) {
    let tempVal = val;
    if (!tempVal) {
      tempVal = 'all';
    }
    if (tempVal === 'all') {
      return '交易状态';
    }
    const filteredMenu = statusOptions.filter(item => item.value === tempVal);
    return filteredMenu[0].label;
  }
  @autobind
  getSortMenuLabel(val) {
    let tempVal = val;
    if (!tempVal) {
      tempVal = 'init';
    }
    const filteredMenu = sortOptions.filter(item => item.value === tempVal);
    return filteredMenu[0].label;
  }

  @autobind
  getSortSelectValue(sortColumn, sortType) {
    const add = Number(sortColumn) + Number(sortType);
    let sortValue = 'init';
    if (add === 3) {
      // 期限由高到低
      sortValue = 'init';
    }
    if (add === 4) {
      // 期限由低到高
      sortValue = 'sort2';
    }
    if (add === 6) {
      // 起购金额由高到低
      sortValue = 'sort3';
    }
    if (add === 7) {
      // 起购金额由低到高
      sortValue = 'sort4';
    }
    return sortValue;
  }

  @autobind
  getProductMenuLabel(value) {
    let label = '';
    productOptions.forEach((dataItem) => {
      if (dataItem.children && value) {
        dataItem.children.forEach((cItem) => {
          if (cItem.value === value) {
            if (cItem.text) {
              label = `${cItem.text}`;
            } else {
              label = `${cItem.label}`;
            }
          }
        });
      }
    });
    return label;
  }

  // 之前写的产品类型选择下拉框的事件
  @autobind
  handleProductMenuChange(value) {
    const produtSelect = value[1] || 'all';
    const { replace, location: { query } } = this.props;
    const productName = this.getProductMenuLabel(produtSelect);
    replace({
      pathname: '/product',
      query: {
        ...query,
        prdTypeCode: produtSelect === 'all' ? '' : produtSelect,
      },
    });
    // TODO 此处需要隐藏下拉选项框和蒙层
    this.props.popMaskShow(false);
    this.setState({
      productMenuShow: false,
      productName,
      productMenuValue: [produtSelect.substring(0, 8), produtSelect],
      productClass: produtSelect === 'all' ? 'all' : 'sel',
    });
  }

  @autobind
  handleStatusMenuChange(val) {
    const statusSelect = val[0];
    const statusName = this.getStatusMenuLabel(statusSelect);
    const { replace, location: { query } } = this.props;
    replace({
      pathname: '/product',
      query: {
        ...query,
        salesStatus: statusSelect === 'all' ? '' : statusSelect,
      },
    });
    // TODO 此处需要隐藏下拉框选项和蒙层
    this.props.popMaskShow(false);
    this.setState({
      statusMenuShow: false,
      statusName,
      statusMenuValue: [statusSelect],
      statusClass: statusSelect === 'all' ? 'all' : 'sel',
    });
  }

  @autobind
  handleSortMenuChange(val) {
    const sortSelect = val[0];
    const sortName = this.getSortMenuLabel(sortSelect);
    const { replace, location: { query } } = this.props;
    let sortColumn = columnLimit;
    let sortType = sortDown;
    switch (sortSelect) {
      case 'init':
        sortColumn = columnLimit;
        sortType = sortDown;
        break;
      case 'sort2':
        sortColumn = columnLimit;
        sortType = sortUp;
        break;
      case 'sort3':
        sortColumn = columnFund;
        sortType = sortDown;
        break;
      case 'sort4':
        sortColumn = columnFund;
        sortType = sortUp;
        break;
      default:
        sortColumn = columnLimit;
        sortType = sortDown;
        break;
    }
    replace({
      pathname: '/product',
      query: {
        ...query,
        sortColumn,
        sortType,
      },
    });
    // 隐藏蒙层和下拉选项框
    this.props.popMaskShow(false);
    this.setState({
      sortColumn,
      sortType,
      sortMenuShow: false,
      sortName,
      sortMenuValue: [sortSelect],
      sortClass: sortSelect === 'init' ? 'all' : 'sel',
    });
  }

  @autobind
  menuClick(whichMenu) {
    const { popMaskShow } = this.props;
    const { productMenuShow, statusMenuShow, sortMenuShow } = this.state;
    if (whichMenu === 'product') {
      this.setState({
        productMenuShow: !productMenuShow,
        statusMenuShow: false,
        sortMenuShow: false,
      });
      if (!productMenuShow) {
        popMaskShow(true);
      } else {
        popMaskShow(false);
      }
    }
    if (whichMenu === 'status') {
      this.setState({
        statusMenuShow: !statusMenuShow,
        productMenuShow: false,
        sortMenuShow: false,
      });
      if (!statusMenuShow) {
        popMaskShow(true);
      } else {
        popMaskShow(false);
      }
    }
    if (whichMenu === 'sort') {
      this.setState({
        sortMenuShow: !sortMenuShow,
        statusMenuShow: false,
        productMenuShow: false,
      });
      if (!sortMenuShow) {
        popMaskShow(true);
      } else {
        popMaskShow(false);
      }
    }
  }
  @autobind
  handleProdTypeMenuClick() {
    this.menuClick('product');
  }

  @autobind
  handleStatusMenuClick() {
    this.menuClick('status');
  }

  @autobind
  handleSortMenuClick() {
    this.menuClick('sort');
  }

  @autobind
  filterClick() {
    this.setState({
      productMenuShow: false,
      statusMenuShow: false,
      sortMenuShow: false,
    });
    this.props.popMaskShow(false);
    this.props.onOpenChange();
  }

  render() {
    const {
      productMenuShow,
      statusMenuShow,
      sortMenuShow,
      productMenuValue,
      statusMenuValue,
      sortMenuValue,
      productName,
      statusName,
      sortName,
      productClass,
      statusClass,
      sortClass,
    } = this.state;

    const productMenu = (
      <Menu
        className="productMenu"
        data={productOptions}
        value={productMenuValue}
        onChange={this.handleProductMenuChange}
        height={document.documentElement.clientHeight * 0.5}
      />
    );

    const statusMenu = (
      <Menu
        className="productMenu"
        level="1"
        data={statusOptions}
        value={statusMenuValue}
        onChange={this.handleStatusMenuChange}
        height="auto"
      />
    );

    const sortMenu = (
      <Menu
        className="productMenu"
        level="1"
        data={sortOptions}
        value={sortMenuValue}
        onChange={this.handleSortMenuChange}
        height="auto"
      />
    );

    const productMenuClass = classnames({
      cusType: productClass === 'all',
      cusTypeSel: productClass !== 'all',
      cusTypeUp: productMenuShow,
      cusTypeDown: !productMenuShow,
    });

    const statusMenuClass = classnames({
      cusType: statusClass === 'all',
      cusTypeSel: statusClass !== 'all',
      cusTypeUp: statusMenuShow,
      cusTypeDown: !statusMenuShow,
    });

    const sortMenuClass = classnames({
      cusType: sortClass === 'all',
      cusTypeSel: sortClass !== 'all',
      cusTypeUp: sortMenuShow,
      cusTypeDown: !sortMenuShow,
    });

    return (
      <div className="listHeader">
        <div className="typeBlank" onClick={this.handleProdTypeMenuClick}>
          <div className={productMenuClass}>
            {productName || '产品类型'}
            <b />
          </div>
        </div>
        <div className="typeBlank" onClick={this.handleStatusMenuClick}>
          <div className={statusMenuClass}>
            {statusName || '交易状态'}
            <b />
          </div>
        </div>
        <div className="typeBlank sortWidth" onClick={this.handleSortMenuClick}>
          <div className={sortMenuClass}>
            {sortName || '期限由高到低'}
            <b />
          </div>
        </div>
        <div className="filterBlank" onClick={this.filterClick}>
          <p>筛选</p><Icon type="filter" />
        </div>
        {/* 产品类型下拉框 */}
        {productMenuShow ? productMenu : null}
        {statusMenuShow ? statusMenu : null}
        {sortMenuShow ? sortMenu : null}
      </div>
    );
  }
}
