import React, { PropTypes, PureComponent } from 'react';
// import ReactDOM from 'react-dom';
import { autobind } from 'core-decorators';
import { Flex, SwipeAction } from 'antd-mobile';
import './targetListItem.less';

const FlexItem = Flex.Item;
const EMPTY_OBJECT = {};
// const EMPTY_LIST = [];

export default class TargetListItem extends PureComponent {
  static propTypes = {
    data: PropTypes.object,
    location: PropTypes.object,
    push: PropTypes.func,
    ignoreRecommendCustomer: PropTypes.func.isRequired,
    empInfoData: PropTypes.object,
    changeSendEmailResult: PropTypes.func.isRequired,
    getServiceList: PropTypes.func.isRequired,
    ignoreCustomerResult: PropTypes.object.isRequired,
    changeIgnoreResult: PropTypes.func.isRequired,
  };

  static defaultProps = {
    data: {},
    location: {},
    push: () => { },
    empInfoData: {},
  }

  constructor(props) {
    super(props);

    const { empInfoData } = this.props;

    const { rowId: empRowId } = empInfoData;

    const motDataSource = {
      custRowId: '',
      custType: '',
      empRowId,
      type: 'Email',
      isEnable: false,
      serviceContent: '',
      custNumber: '',
    };

    this.state = {
      isLoading: false,
      motData: motDataSource,
      currentTargetCustomer: '',
      resultData: null,
      productCode: '',
      clientName: '',
      ignoreResult: null,
    };
  }

  componentWillReceiveProps(nextProps) {
    const {
      ignoreCustomerResult,
      changeIgnoreResult,
    } = nextProps;
    const { currentTargetCustomer } = this.state;
    const { resultData: ignoreResult = null } = ignoreCustomerResult[currentTargetCustomer]
      || EMPTY_OBJECT;
    const { confirmCode } = ignoreResult || EMPTY_OBJECT;

    if (ignoreResult !== this.state.ignoreResult) {
      if (confirmCode === 1) {
        this.setState({
          ignoreResult: null,
        });

        const result = null;
        changeIgnoreResult({ currentTargetCustomer, result });
      }
    }
  }

  /**
  * 处理用户点击事件
  */
  @autobind
  handleIgnoreClick(clientIdSign, productCode, directoryCode) {
    const { ignoreRecommendCustomer } = this.props;
    ignoreRecommendCustomer({
      clientIdSign,
      productCode,
      directoryCode,
      source: '01',
    });

    this.setState({
      currentTargetCustomer: `${clientIdSign}`,
    });
  }

  // 点击item
  @autobind
  handleClick(event, custType, custId, custNumber) {
    if (event.target.nodeName.toLowerCase() === 'i' && event.target.id !== 'custType') {
      return;
    }
    const { push } = this.props;
    push({
      pathname: '/customer/detail',
      query: {
        custId,
        custNumber,
        custSor: custType === 'prod' ? 'org' : custType,
      },
    });
  }

  render() {
    const {
      clientId = '--',
      clientName = '--',
      reason,
      custType = '--',
      custId = '--',
      clientIdSign = '--',
    } = this.props.data;

    const { location: { query: { directoryCode, productCode } } } = this.props;

    return (
      <div className="target-item">
        <SwipeAction
          key={clientId}
          className="swipe-list"
          autoClose
          right={[
            {
              text: '不适合',
              onPress: () => this.handleIgnoreClick(clientIdSign,
                productCode, directoryCode, custId, clientId, custType),
              style: { backgroundColor: '#ff655e', color: 'white' },
            },
          ]}
        >
          <Flex className="flex-container" direction="row" justify="start" align="center" wrap="nowrap">
            <FlexItem>
              <div
                className="header-section"
                onClick={(event) => {
                  this.handleClick(event, custType, custId, clientId);
                }}
              >
                <i className={custType} id="custType" />
                <div className="client-section">
                  <div className="name">{clientName || '--'}</div>
                  <div className="id">{clientId || '--'}</div>
                </div>
              </div>
              <div className="item-separator" />
              <div className="reason-section">
                <div
                  className="reason"
                >原因：{reason || '无'}</div>
              </div>
            </FlexItem>
          </Flex>
        </SwipeAction>
      </div>
    );
  }
}
