/**
 * @file product/SearchList.js
 * @author wangjunjun
 */

import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import { ListView } from 'antd-mobile';

import { prepareDataSource } from '../../utils/listView';
import Toast from '../../components/common/Toast';
import cordova, { openUrl } from '../../utils/cordova';
import helper from '../../utils/helper';
import SearchItem from './SearchItem';
import Message from '../message';
import { constants } from '../../config';
import api from '../../api';

export default class SearchList extends PureComponent {

  static propTypes = {
    searchInfo: PropTypes.object.isRequired,
    replace: PropTypes.func.isRequired,
    push: PropTypes.func.isRequired,
    doSearch: PropTypes.func.isRequired,
    isLoaded: PropTypes.bool.isRequired,
    location: PropTypes.object.isRequired,
    saveQuery: PropTypes.func.isRequired,
  };

  static defaultProps = {
  }

  constructor(props) {
    super(props);
    const { searchInfo: { list } } = props;
    this.state = {
      dataSource: prepareDataSource(list),
      isLoading: false,
      messageHeight: 0,
      listViewHeight: 0,
    };
  }

  componentDidMount() {
    const touchEle = document.querySelector('.product-search-list');
    touchEle.addEventListener('touchmove', helper.hideKeyboard, false);
    this.setMessageHeight();
  }

  componentWillReceiveProps(nextProps) {
    const { searchInfo: { list } } = nextProps;
    if (list !== this.props.searchInfo.list) {
      this.setState({
        dataSource: prepareDataSource(list),
        isLoading: false,
      });
    }
  }

  componentDidUpdate() {
    this.setMessageHeight();
  }

  @autobind
  onEndReached() {
    const { searchInfo: { page } } = this.props;
    const { isLoading } = this.state;
    if (!isLoading
      && (page.curPageNum < page.totalPageNum)
      && cordova.isConnected()
    ) {
      this.setState({ isLoading: true }, this.refreshMore);
    }
  }

  setMessageHeight() {
    this.setState({
      messageHeight: helper.getAvailableHeight({ el: ['.fixed-header', '.am-list-header'] }),
      listViewHeight: helper.getAvailableHeight({ el: ['.fixed-header'] }),
    });
  }

  @autobind
  handleClick(data) {
    const { directoryCode, productCategory, productCode } = data;
    const { push, saveQuery, location: { query } } = this.props;
    saveQuery({
      type: 'product',
      query,
    });
    // 产品code为1，代表公募
    // 产品code为2，代表私募
    // 产品code为3，代表紫金
    if (productCategory === 2) {
      push({
        pathname: '/product/detailWithMenu',
        query: {
          productCode,
          directoryCode,
          isShowNavBar: 'Y',
        },
      });
    } else if (productCategory === 3) {
      const authInfo = api.getAuthInfo();
      openUrl({
        path: `/${constants.zlUrl}/zzlc2/zjlc/zjlc.htm?directoryCode=${directoryCode}&productCode=${productCode}&empId=${authInfo.empId}&deviceId=${authInfo.deviceId}&token=${authInfo.token}&isShowMenu=Y`,
        title: '产品详情-紫金',
      });
    } else if (productCategory === 1) {
      const authInfo = api.getAuthInfo();
      openUrl({
        path: `/${constants.zlUrl}/cwjj/jzx/index.htm?directoryCode=${directoryCode}&productCode=${productCode}&empId=${authInfo.empId}&deviceId=${authInfo.deviceId}&token=${authInfo.token}&isShowMenu=Y`,
        title: '产品详情-公募',
      });
    } else {
      Toast.info('该产品无详情页面', 1);
    }
  }

  @autobind
  refreshMore() {
    const {
      doSearch,
      searchInfo: { page },
      location: { query },
    } = this.props;
    const params = { ...query, keywords: decodeURIComponent(query.keywords) };
    doSearch({
      ...params,
      pageNum: page.curPageNum + 1,
    });
  }

  renderHeader() {
    return (
      <p>产品搜索结果</p>
    );
  }

  @autobind
  renderRow(rowData, sectionID, rowID) {
    const { location: { query: { keywords } } } = this.props;
    let extra = keywords;
    if (/\D/.test(keywords)) {
      extra = '';
    }
    return (
      <SearchItem
        key={`${sectionID}-${rowID}`}
        data={rowData}
        query={keywords}
        extra={extra}
        onClick={() => this.handleClick(rowData)}
      />
    );
  }

  renderSeparator(sectionID, rowID) {
    return (
      <div
        key={`${sectionID}-${rowID}`}
        className="list-separator"
      />
    );
  }

  @autobind
  renderFooter() {
    const { isLoaded, searchInfo: { page, list } } = this.props;
    const { isLoading, messageHeight } = this.state;
    let text = '';
    let messageType = '';
    if (list.length === 0) {
      if (isLoaded) {
        messageType = 'notfound';
      }
    } else if (!cordova.isConnected()) {
      messageType = 'network';
    } else if (isLoading) {
      text = '加载中...';
    } else if (page.curPageNum > 1) {
      if (page.curPageNum === page.totalPageNum) {
        text = '已经到底了';
      } else {
        text = '上拉加载更多';
      }
    }
    if (messageType) {
      return (
        <Message
          type={messageType}
          height={messageHeight}
        />
      );
    }
    return (
      <div>
        {text}
      </div>
    );
  }

  render() {
    const { dataSource, listViewHeight } = this.state;
    return (
      <div className="product-search-list-view">
        <ListView
          className="product-search-list"
          style={{ height: listViewHeight }}
          dataSource={dataSource}
          initialListSize={constants.initialListSize}
          renderHeader={this.renderHeader}
          renderFooter={this.renderFooter}
          renderRow={this.renderRow}
          renderSeparator={this.renderSeparator}
          pageSize={10}
          scrollRenderAheadDistance={500}
          scrollEventThrottle={20}
          onEndReached={this.onEndReached}
          onEndReachedThreshold={10}
          useZscroller
        />
      </div>
    );
  }

}
