import React, { PropTypes, PureComponent } from 'react';
import ReactDOM from 'react-dom';
import { Flex } from 'antd-mobile';
// import _ from 'lodash';
import { autobind } from 'core-decorators';
// import { connect } from 'react-redux';
import cordova from '../../utils/cordova';
import Toast from '../../components/common/Toast';
import './targetCustomer.less';

const Item = Flex.Item;

export default class TargetCustomer extends PureComponent {
  static propTypes = {
    push: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
  };

  static defaultProps = {
  };

  componentDidMount() {
    this.setHeight();
  }

  @autobind
  onClick() {
    if (!cordova.isConnected()) {
      Toast.info('网络异常', 1);
      return;
    }
    const { push, location: { query: { directoryCode, productCode } } } = this.props;
    push({
      pathname: '/product/targetCustomer',
      query: {
        productCode,
        directoryCode,
        isShowNavBar: 'Y',
        isHasHistory: 'Y',
      },
    });
  }

  setHeight() {
    // 更新高度
    const rootElem = ReactDOM.findDOMNode(document.querySelectorAll('.freshable-container')[0]); // eslint-disable-line
    const height = Number.parseFloat(rootElem.clientHeight)
      - (1.6 * Number.parseFloat(document.documentElement.style.fontSize));
    rootElem.style.height = `${height}px`;
  }

  render() {
    return (
      <Flex direction="row" justify="start" align="center" wrap="nowrap" className="targetCustomer">
        <Item onClick={this.onClick}>
          <div className="target">
            <i className="targetCust" />
            <span>查看目标客户</span>
          </div>
        </Item>
      </Flex>
    );
  }
}
