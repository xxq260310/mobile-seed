import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import { List } from 'antd-mobile';

import './searchItem.less';

const Item = List.Item;
const Brief = Item.Brief;

export default class SearchItem extends PureComponent {
  static propTypes = {
    query: PropTypes.string,
    data: PropTypes.object.isRequired,
    extra: PropTypes.string,
    onClick: PropTypes.func,
  };

  static defaultProps = {
    query: '',
    extra: '',
    onClick: () => {},
  }

  @autobind
  handleClick() {
    const { onClick } = this.props;
    onClick();
  }

  markRed(text, keyword) {
    return text.replace(
      new RegExp(decodeURI(keyword), 'g'),
      `<i style="font-style:normal;color:#ff655e;">${decodeURI(keyword)}</i>`,
      );
  }

  render() {
    const { data: { productName, productCode }, query } = this.props;
    return (
      <Item
        onClick={this.handleClick}
      >
        <span dangerouslySetInnerHTML={{ __html: this.markRed(productName, query) }} />
        <Brief>
          <em
            dangerouslySetInnerHTML={{ __html: this.markRed(productCode, query) }}
          />
        </Brief>
      </Item>
    );
  }
}
