import React, { PropTypes } from 'react';
import _ from 'lodash';

import './listItem.less';
import { openUrl } from '../../utils/cordova';
import api from '../../api';
import Toast from '../../components/common/Toast';
import { constants } from '../../config';
import Icon from '../../components/common/Icon';

class ListItem extends React.Component {
  static propTypes = {
    productCode: PropTypes.string,
    productName: PropTypes.string,
    categoryName: PropTypes.string,
    status: PropTypes.number,
    expectedYield: PropTypes.number,
    bfMaturity: PropTypes.number,
    firstParticipation: PropTypes.number,
    recommendedOpinion: PropTypes.string,
    push: PropTypes.func.isRequired,
    productCategory: PropTypes.number,
    productId: PropTypes.number,
    directoryCode: PropTypes.string,
    performanceType: PropTypes.number,
    unitNav: PropTypes.number,
    annuYield: PropTypes.number,
    onClick: PropTypes.func,
  };

  static defaultProps = {
    productCode: '--',
    productName: '--',
    categoryName: '--',
    status: 1,
    expectedYield: 0,
    bfMaturity: 0,
    firstParticipation: 0,
    recommendedOpinion: '--',
    push: () => { },
    productCategory: 0,
    productId: 0,
    directoryCode: '--',
    performanceType: 1,
    unitNav: 0,
    annuYield: 0,
    onClick: () => {},
  }

  /* eslint-disable */

  handleClick(productId, directoryCode, productCategory, productCode) {
    const { push, onClick } = this.props;
    // 产品code为1，代表公募
    // 产品code为2，代表私募
    // 产品code为3，代表紫金
    if (productCategory === 2) {
      push({
        pathname: '/product/detailWithMenu',
        query: {
          productCode,
          directoryCode,
          isShowNavBar: 'Y',
        },
      });
    } else if (productCategory === 3) {
      const authInfo = api.getAuthInfo();
      openUrl({
        path: `/${constants.zlUrl}/zzlc2/zjlc/zjlc.htm?directoryCode=${directoryCode}&productCode=${productCode}&empId=${authInfo.empId}&deviceId=${authInfo.deviceId}&token=${authInfo.token}&isShowMenu=Y`,
        title: '产品详情-紫金',
      });
    } else if (productCategory === 1) {
      const authInfo = api.getAuthInfo();
      openUrl({
        path: `/${constants.zlUrl}/cwjj/jzx/index.htm?directoryCode=${directoryCode}&productCode=${productCode}&empId=${authInfo.empId}&deviceId=${authInfo.deviceId}&token=${authInfo.token}&isShowMenu=Y`,
        title: '产品详情-公募',
      });
    } else {
      Toast.info('该产品无详情页面', 1);
    }
    onClick();
  }

  /* eslint-enable */

  filterMoney(assetData) {
    let tempData = '0元';
    if (assetData && assetData.toString().indexOf('.') !== -1) {
      // 小数
      const temp = assetData.toString().split('.');
      if (temp[0].length >= 1 && temp[0].length <= 3) {
        tempData = `${Number.parseFloat(assetData).toFixed(0)}元`;
      } else if (temp[0].length > 3 && temp[0].length < 9) {
        tempData = `${(Number.parseFloat(temp[0]) / 10000).toFixed(0)}万元`;
      } else if (temp[0].length > 8) {
        tempData = `${(Number.parseFloat(temp[0]) / 100000000).toFixed(0)}亿元`;
      }
    } else if (assetData && assetData.toString().length >= 0
      && assetData.toString().length <= 4) {
      tempData = `${assetData}元`;
    } else if (assetData !== null && assetData.toString().length > 4
      && assetData.toString().length < 9) {
      tempData = `${(assetData / 10000).toFixed(0)}万元`;
    } else if (assetData !== null && assetData.toString().length >= 9) {
      tempData = `${(assetData / 100000000).toFixed(0)}亿元`;
    }

    return tempData;
  }

  profitShow(type, annuYield, unitNav, expectedYield) {
    let txt = '';
    switch (type) {
      case 1:
        txt = (annuYield === 0 || annuYield === null) ? '--' : (<span>{this.formatePercent(annuYield)}<i>%</i></span>);
        break;
      case 2:
        txt = (unitNav === 0 || unitNav === null) ? '--' : (<span>{this.formatePercent(unitNav)}</span>);
        break;
      case 3:
        txt = (expectedYield === 0 || expectedYield === null) ? '--' : (<span>{this.formatePercent(expectedYield)}</span>);
        break;
      default:
        txt = '--';
        break;
    }
    return txt;
  }

  profitTxtShow(type) {
    switch (type) {
      case 1:
        return '七日年化收益率';
      case 2:
        return '单位净值';
      case 3:
        return '预期收益率';
      default:
        return '--';
    }
  }

  formatePercent(d) {
    let rtnValue;
    if (d >= 100) {
      rtnValue = d.toFixed();
    } else if (d < 100 && d >= 10) {
      rtnValue = d.toFixed(1);
    } else if (d < 10) {
      rtnValue = d.toFixed(2);
    }
    return rtnValue;
  }

  formateWorth(num) {
    if (!_.includes(String(num), '.')) return num;
    const len = String(num).split('.')[1].length;
    return len >= 3 ? num.toFixed(3) : num.toFixed(len);
  }

  render() {
    const {
      productCode,
      productName,
      status,
      expectedYield,
      bfMaturity,
      firstParticipation,
      recommendedOpinion,
      productId,
      productCategory,
      directoryCode,
      performanceType,
      unitNav,
      annuYield,
    } = this.props;
    return (
      <div className="productListItem" onClick={() => this.handleClick(productId, directoryCode, productCategory, productCode, productName)}>
        <div className="productInfo">
          <div className="txtInfo">
            <h3>{productName}</h3>
            <div className="productDetail">
              <p className="proId">{productCode}</p>
              <p className={`${status === 1 ? 'proStatus' : 'proStatus pre-sale'}`}>{status === 1 ? '在售' : '预售'}</p>
            </div>
            <div className="productBuy">
              <p className="limit">投资期限:
                {bfMaturity === 0 || !bfMaturity ? '无' : `${bfMaturity}天`}</p>
              <p className="moneyStart">起购:
                {firstParticipation === 0 || !firstParticipation ? '无' : this.filterMoney(firstParticipation)}
              </p>
            </div>
          </div>
          <div className="profitInfo">
            <h3>{this.profitShow(performanceType, annuYield, unitNav, expectedYield)}</h3>
            <p>{this.profitTxtShow(performanceType)}</p>
          </div>
        </div>
        <div className="productComment">
          <Icon type="pingjia" />{recommendedOpinion || '无'}
        </div>
      </div>
    );
  }
}

export default ListItem;
