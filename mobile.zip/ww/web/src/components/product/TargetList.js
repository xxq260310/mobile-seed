/**
 * @file product/TargetList.js
 * @author xuxiaoqin
 */
import React, { PropTypes, PureComponent } from 'react';
import ReactDOM from 'react-dom';
import { autobind } from 'core-decorators';
import { RefreshControl, ListView } from 'antd-mobile';
import _ from 'lodash';

import { prepareDataSource } from '../../utils/listView';
import { renderIcon, renderLoading, distanceToRefresh } from '../../components/common/PullToRefreshable';
import helper from '../../utils/helper';
import ListItem from './TargetListItem';
import Message from '../message';
import cordova from '../../utils/cordova';
import { checkListPTR } from '../../decorators/checkNetwork';
import { checkErrData } from '../../decorators/checkErrorData';

import './targetList.less';

const EMPTY_LIST = [];
const EMPTY_OBJECT = {};

export default class TargetList extends PureComponent {

  static propTypes = {
    list: PropTypes.object.isRequired,
    getList: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    pageNum: PropTypes.number,
    push: PropTypes.func.isRequired,
    ignoreRecommendCustomer: PropTypes.func.isRequired,
    empInfoData: PropTypes.object,
    changeSendEmailResult: PropTypes.func.isRequired,
    getServiceList: PropTypes.func.isRequired,
    ignoreCustomerResult: PropTypes.object.isRequired,
    changeIgnoreResult: PropTypes.func.isRequired,
    isFetching: PropTypes.bool.isRequired,
    reportRefresh: PropTypes.func.isRequired,
    // deleteTargetList: PropTypes.func.isRequired,
  }

  static defaultProps = {
    pageNum: 1,
    empInfoData: {},
  }

  constructor(props) {
    super(props);

    const { resultList = EMPTY_LIST } = props.list || EMPTY_OBJECT;

    this.state = {
      dataSource: prepareDataSource(resultList),
      isLoading: false,
      isRefreshing: false,
      isLoaded: false,
      messageHeight: 0,
    };
  }

  componentDidMount() {
    this.setHeight();
    this.setMessageHeight();
  }

  @checkErrData({ loadingName: 'isRefreshing' })
  componentWillReceiveProps(nextProps) {
    const { list: { page = EMPTY_OBJECT, resultList = EMPTY_LIST } } = nextProps;
    const { list: preList = EMPTY_OBJECT } = this.props;
    const {
      // page: prePage = EMPTY_OBJECT,
      resultList: preResultList = EMPTY_LIST,
     } = preList;

    if (resultList !== preResultList) {
      let stateMap = {
        isLoading: false,
      };
      const needUpdateDatasource = true;
      // 刷新没数据的时候不要更新数据源
      // 否则会导致循环刷新
      if (page.curPageNum === 1) {
        // 只判断第一项就行，避免大数据判断引起的性能问题
        // if (_.isEqual(page, prePage) && _.isEqual(resultList[0], preResultList[0])) {
        //   needUpdateDatasource = false;
        // }
      }
      if (needUpdateDatasource) {
        stateMap = {
          ...stateMap,
          dataSource: prepareDataSource(resultList),
        };
      }

      this.setState(stateMap);
    }
  }

  componentDidUpdate() {
    this.setHeight();
    this.setMessageHeight();
  }

  @autobind
  onEndReached() {
    const { isLoading } = this.state;
    const { list: { page = EMPTY_OBJECT } } = this.props;
    if (!isLoading
      && (page.curPageNum < page.totalPageNum)
      && cordova.isConnected()
    ) {
      this.setState(
        { isLoading: true },
        this.refreshMore,
      );
    }
  }

  @autobind
  @checkListPTR()
  onRefresh() {
    const { location: { query }, getList, reportRefresh } = this.props;
    getList({
      ...query,
      pageNum: 1,
    });
    reportRefresh({
      actionSource: '目标客户',
    });
  }

  setHeight() {
    // 更新列表高度
    if (this.listElem) {
      const listElem = ReactDOM.findDOMNode(this.listElem); // eslint-disable-line
      const height = helper.getAvailableHeight();
      listElem.style.height = `${height}px`;
    }
  }

  setMessageHeight() {
    this.setState({
      messageHeight: helper.getAvailableHeight({ el: ['.am-list-body', '.am-tab-bar-bar'] }),
    });
  }

  @autobind
  refreshMore() {
    const { getList, list: { page },
      location: { query } } = this.props;
    getList({
      ...query,
      pageNum: page.curPageNum + 1,
    });
  }

  @autobind
  renderRow(rowData, sectionID, rowID) {
    if (_.isEmpty(rowData)) {
      return null;
    }

    const { push,
      location,
      location: { query: { directoryCode, productCode } },
      changeSendEmailResult,
      empInfoData,
      ignoreRecommendCustomer,
      getServiceList,
      ignoreCustomerResult,
      changeIgnoreResult,
     } = this.props;

    return (
      <ListItem
        key={`${sectionID}-${rowID}`}
        data={{
          ...rowData,
          directoryCode,
          productCode,
        }}
        changeSendEmailResult={changeSendEmailResult}
        empInfoData={empInfoData}
        ignoreRecommendCustomer={ignoreRecommendCustomer}
        push={push}
        location={location}
        getServiceList={getServiceList}
        ignoreCustomerResult={ignoreCustomerResult}
        changeIgnoreResult={changeIgnoreResult}
      />
    );
  }

  renderSeparator(sectionID, rowID) {
    return (
      <div
        key={`${sectionID}-${rowID}`}
        className="list-separator"
      />
    );
  }

  @autobind
  renderFooter() {
    const { isLoading, isLoaded, messageHeight } = this.state;
    const { list: { page = EMPTY_OBJECT, resultList = EMPTY_LIST } } = this.props;
    let text = '';
    let messageType = '';
    let messageText = '';
    if (resultList.length === 0) {
      if (isLoaded) {
        messageType = 'notfound';
        messageText = '暂无目标客户';
      }
    } else if (!cordova.isConnected()) {
      messageType = 'network';
    } else if (isLoading) {
      text = '加载中...';
    } else if (page.curPageNum > 1) {
      if (page.curPageNum === page.totalPageNum) {
        text = '已经到底了';
      } else {
        text = '上拉加载更多';
      }
    }
    if (messageType) {
      return (
        <Message
          type={messageType}
          height={messageHeight}
          text={messageText}
        />
      );
    }
    return (
      <div>
        {text}
      </div>
    );
  }

  render() {
    const { dataSource, isRefreshing } = this.state;
    return (
      <ListView
        className="target-list"
        ref={ref => (this.listElem = ref)}
        dataSource={dataSource}
        renderFooter={this.renderFooter}
        renderRow={this.renderRow}
        renderSeparator={this.renderSeparator}
        pageSize={10}
        scrollRenderAheadDistance={500}
        scrollEventThrottle={20}
        onEndReached={this.onEndReached}
        onEndReachedThreshold={10}
        useBodyScroll={false}
        refreshControl={<RefreshControl
          refreshing={isRefreshing}
          onRefresh={this.onRefresh}
          distanceToRefresh={distanceToRefresh}
          icon={renderIcon()}
          loading={renderLoading()}
        />}
      />
    );
  }
}
