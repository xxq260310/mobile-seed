/**
 * @file profile/InfoItem.js
 * @author sunweibin
 */
import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import { Progress } from 'antd-mobile';
import Icon from '../../components/common/Icon';
import SalesPieWidget from './SalesPieWidget';
// import TotalOpenCus from './TotalOpenCus';
import './infoItem.less';

class InfoItem extends PureComponent {
  static propTypes = {
    data: PropTypes.object,
  };

  static defaultProps = {
    data: undefined,
  }

  @autobind
  getData(key, returnNum = false) {
    if (this.props.data) {
      return (this.props.data[key] || this.props.data[key] === 0) ? this.props.data[key] : '--';
    }
    if (returnNum) {
      return 0;
    }
    return '--';
  }

  numFormat(num) {
    // 默认传递的数字至少都在万元以上
    let unit = '万元';
    let newNum = num;
    if (newNum !== '--') {
      // 超过1亿
      if (newNum >= 10000) {
        newNum /= 10000;
        unit = '亿元';
      }
      if (newNum > 1000 || newNum < -1000) {
        newNum = parseFloat(newNum).toFixed(1);
      } else if (newNum.toString().indexOf('.') > 0 && newNum.toString().split('.')[1].length > 1) {
        newNum = parseFloat(newNum).toFixed(2);
      }
      return (
        <div className="numLabel">
          {newNum}
          <span className="unit">{unit}</span>
        </div>
      );
    }
    return (
      <div className="numLabel">
        {'--'}
      </div>
    );
  }
  // 针对传递过来的基金数字进行NAN处理
  fixNumberIssue(num) {
    if (num !== '--') {
      return parseFloat(num).toFixed(2);
    }
    return 0;
  }
  // 针对百分比数字做处理
  fixPercentNumber(num) {
    let newNum = Number(num);
    if (isNaN(newNum)) {
      return {
        value: 0,
        show: '--',
      };
    }
    if (newNum <= 0) {
      newNum = 0;
    } else if (newNum >= 1) {
      newNum = 100;
    } else {
      newNum = parseFloat(newNum * 100).toFixed(0);
    }
    return {
      value: newNum,
      show: newNum,
    };
  }

  render() {
    const publicFund = this.getData('publicFund');
    const sipFund = this.getData('sipFund');
    const camFund = this.getData('camFund');
    const sypzFund = this.getData('sypzFund');
    const motTaskRate = this.fixPercentNumber(this.getData('motTaskRate'));
    const cusServiceRate = this.fixPercentNumber(this.getData('cusServiceRate'));
    // const ttfPeopleNum = this.getData('ttfPeopleNum');
    // const qquanPeopleNum = this.getData('qquanPeopleNum');
    // const zlcfPeopleNum = this.getData('zlcfPeopleNum');
    // const ggtPeopleNum = this.getData('ggtPeopleNum');
    // const rzrqPeopleNum = this.getData('rzrqPeopleNum');

    const pieChartData = { publicFund, sipFund, camFund, sypzFund };
    // const totalOpenData = {
    //   ttfPeopleNum,
    //   qquanPeopleNum,
    //   zlcfPeopleNum,
    //   ggtPeopleNum,
    //   rzrqPeopleNum,
    // };
    return (
      <div className="customerWrapper">
        <div className="my-sale-info add-new-slient">
          <h3><Icon type="kehuhl" />新增客户</h3>
          <div className="flexBox cusNewBox">
            <div className="cusBlank margin-right box-bk">
              <div className="numLabel">{this.getData('netNewCusNumber', true)}</div>
              <div className="txtLabel">净新增有效户</div>
            </div>
            <div className="cusBlank box-bk">
              <div className="numLabel">{this.getData('netNewFLSCusNumber', true)}</div>
              <div className="txtLabel">净新增非零客户数</div>
            </div>
          </div>
          <div className="flexBox cusNewBox">
            <div className="cusBlank margin-right box-bk">
              <div className="numLabel">{this.getData('netNewGDCusNumber', true)}</div>
              <div className="txtLabel">净新增高端产品户</div>
            </div>
            <div className="cusBlank box-bk">
              <div className="numLabel">{this.getData('netNewCPCusNumber', true)}</div>
              <div className="txtLabel">净新增产品户</div>
            </div>
          </div>
        </div>
        <div className="my-sale-info amount-assets">
          <h3><Icon type="zichanliang" />资产量</h3>
          <div className="flexBox cusNewBox">
            <div className="cusBlank margin-right box-bk">
              {this.numFormat(this.getData('netNewCusAsset'))}
              <div className="txtLabel">净新增客户资产</div>
            </div>
            <div className="cusBlank box-bk">
              {this.numFormat(this.getData('totalZHVolume'))}
              <div className="txtLabel">累计综合交易量</div>
            </div>
          </div>
          <div className="flexBox cusNewBox">
            <div className="cusBlank margin-right box-bk">
              {this.numFormat(this.getData('totalJCVolume'))}
              <div className="txtLabel">累计基础交易量</div>
            </div>
            <div className="cusBlank box-bk">
              {this.numFormat(this.getData('totalNetCommission'))}
              <div className="txtLabel">股基累计净佣金</div>
            </div>
          </div>
        </div>
        <div className="my-sale-info products-sales">
          <h3><Icon type="licaichanpin" />理财产品销售</h3>
          { /* TODO:理财产品销售 */ }
          <SalesPieWidget assetData={pieChartData} />
        </div>
        { /* <div className="my-sale-data my-total-open">
          <div className="sale-box">
            <h3>累计开通客户数</h3>
            <div className="box-bk data-box">
              <TotalOpenCus totalCusData={totalOpenData} />
            </div>
          </div>
        </div> */ }
        <div className="my-sale-mot">
          <h3><Icon type="fugaishuai" />MOT覆盖率</h3>
          <div className="flexBox cusNewBox">
            <div className="sale-box margin-right">
              <div className="box-bk process-box mot-bar">
                <div className="procontent">
                  <div className="pro-percent">{motTaskRate.show}<span>%</span></div>
                  <div className="process-name">必做MOT完成率</div>
                  <Progress percent={motTaskRate.value} position="normal" appearTransition />
                </div>
              </div>
            </div>
            <div className="sale-box">
              <div className="box-bk process-box service-bar">
                <div className="procontent">
                  <div className="pro-percent">{cusServiceRate.show}<span>%</span></div>
                  <div className="process-name">客户服务覆盖率</div>
                  <Progress percent={cusServiceRate.value} position="normal" appearTransition />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default InfoItem;
