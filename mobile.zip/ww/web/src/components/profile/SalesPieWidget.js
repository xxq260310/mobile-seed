/**
 * @fileOverview profile/SalesPie.js
 * @author sunweibin
 */

import React, { PureComponent, PropTypes } from 'react';
// import Icon from '../common/Icon';
import './SalesPieWidget.less';


export default class SalesPieWidget extends PureComponent {
  static propTypes = {
    assetData: PropTypes.object,
  }

  static defaultProps = {
    assetData: {},
  }

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      isShowPieData: false,
    };
  }

  numFormat(num) {
    // 默认传递的数字至少都在万元以上
    let unit = '万元';
    let newNum = num;
    if (newNum !== '--') {
      // 超过1亿
      if (newNum >= 10000) {
        newNum /= 10000;
        unit = '亿元';
      }
      if (newNum > 1000 || newNum < -1000) {
        newNum = parseFloat(newNum).toFixed(1);
      } else if (newNum.toString().indexOf('.') > 0 && newNum.toString().split('.')[1].length > 1) {
        newNum = parseFloat(newNum).toFixed(2);
      }
      return (
        <div className="numLabel">{newNum}<span>{unit}</span></div>
      );
    }
    return (
      <div className="numLabel">{'--'}</div>
    );
  }
  render() {
    const { assetData: { publicFund, sipFund, camFund, sypzFund } } = this.props;
    return (
      <div>
        <div className="flexBox cusNewBox">
          <div className="cusBlank margin-right box-bk">
            {this.numFormat(publicFund || '--')}
            <div className="txtLabel">公募</div>
          </div>
          <div className="cusBlank box-bk">
            {this.numFormat(camFund || '--')}
            <div className="txtLabel">紫金</div>
          </div>
        </div>
        <div className="flexBox cusNewBox">
          <div className="cusBlank margin-right box-bk">
            {this.numFormat(sipFund || '--')}
            <div className="txtLabel">OTC</div>
          </div>
          <div className="cusBlank box-bk">
            {this.numFormat(sypzFund || '--')}
            <div className="txtLabel">私募</div>
          </div>
        </div>
      </div>
    );
  }
}
