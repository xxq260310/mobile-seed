/**
 * @file profile/Info.js
 * @author fengwencong
 * @move sunweibin
 */

import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import { SegmentedControl } from 'antd-mobile';
import InfoItem from './InfoItem';
import './info.less';

export default class CustomerInfo extends PureComponent {
  static propTypes = {
    data: PropTypes.object,
    tabIndex: PropTypes.number,
    changeTabIndex: PropTypes.func,
  }

  static defaultProps = {
    data: {},
    tabIndex: 0,
    changeTabIndex: () => {},
  }

  constructor(props) {
    super(props);

    this.state = {
      data: props.data,
    };
  }

  componentWillReceiveProps(nextProps) {
    const { data } = nextProps;
    if (data !== this.props.data) {
      this.setState({
        data,
      });
    }
  }

  @autobind
  handleSegmentedControlChange(e) {
    // 保存TabIndex数据到store里面
    this.props.changeTabIndex(parseInt(e.nativeEvent.selectedSegmentIndex, 10));
  }

  render() {
    const { data } = this.state;
    const { tabIndex: activeIndex } = this.props;
    return (
      <div className="infoTab">
        <div className="segmentedControl-bar">
          <SegmentedControl
            selectedIndex={activeIndex}
            values={['本月', '本季', '今年以来']}
            onChange={this.handleSegmentedControlChange}
          />
        </div>
        <div className="items-container">
          <div
            className="items-list"
            style={{
              left: `${-activeIndex * 100}%`,
            }}
          >
            <div className="item-wraper">
              <InfoItem data={data[0]} />
            </div>
            <div className="item-wraper">
              <InfoItem data={data[1]} />
            </div>
            <div className="item-wraper">
              <InfoItem data={data[2]} />
            </div>
          </div>
        </div>
      </div>
    );
  }
}
