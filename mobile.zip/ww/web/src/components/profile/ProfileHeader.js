/**
 * @fileOview components/profile/ProfilHeader.js
 * @author sunweibin
 */

import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import Icon from '../common/Icon';
import './profileheader.less';
import avatar from '../../../static/img/avatar.png';

export default class ProfileHeader extends PureComponent {

  static propTypes = {
    avatar: PropTypes.string.isRequired,
    empName: PropTypes.string.isRequired,
    empId: PropTypes.string.isRequired,
    push: PropTypes.func,
    headerClick: PropTypes.func,
  }

  static defaultProps = {
    avatar: '',
    empName: '',
    empId: '',
    push: () => {},
    headerClick: () => {
      console.log('您未注册点击事件');
    },
  }

  @autobind
  handleHeaderClick() {
    this.props.headerClick();
  }

  render() {
    // 取出信息
    const { empName, empId/* , avatar */ } = this.props;

    return (
      <div className="profile-header">
        <a onClick={this.handleHeaderClick} className="profile_set_up"><Icon type="shezhi1" /></a>
        <div className="avatar">
          <div className="img-board">
            <img className="img-response" src={avatar} alt="avatar" />
          </div>
        </div>
        <div className="brief">
          <div className="brief-name">{empName}</div>
          <div className="brief-code">{empId}</div>
        </div>
      </div>
    );
  }
}
