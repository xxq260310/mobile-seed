/**
 * @file mission/MotCustList.js
 * @author liutingting
 */
import React, { PropTypes, PureComponent } from 'react';
import ReactDOM from 'react-dom';
import { autobind } from 'core-decorators';
import { RefreshControl, ListView, Modal } from 'antd-mobile';

import cordova from '../../utils/cordova';
import { renderIcon, renderLoading, distanceToRefresh } from '../common/PullToRefreshable';
import { prepareDataSource } from '../../utils/listView';
import MotCustItem from './MotCustItem';
import Message from '../message';
import { checkListPTR } from '../../decorators/checkNetwork';
import { checkErrData } from '../../decorators/checkErrorData';
import './motCustList.less';

const EMPTY_LIST = [];
const EMPTY_OBJECT = {};

export default class MotCustList extends PureComponent {

  static propTypes = {
    list: PropTypes.object,
    location: PropTypes.object.isRequired,
    motTaskId: PropTypes.string.isRequired,
    motTaskName: PropTypes.string.isRequired,
    push: PropTypes.func.isRequired,
    refresh: PropTypes.func.isRequired,
    isFetching: PropTypes.bool.isRequired,
    pageNum: PropTypes.number,
    descFoldStatus: PropTypes.bool.isRequired, // 记录折叠状态，用于重新 render listview
    callBackFunc: PropTypes.func.isRequired, // 用于渲染引导蒙层展示
    showGuideAgain: PropTypes.func.isRequired, // 用于 点击list的item时 渲染引导蒙层展示
    reportSwipeAction: PropTypes.func.isRequired,
    reportRefresh: PropTypes.func.isRequired,
  }

  static defaultProps = {
    list: {
      taskPage: EMPTY_OBJECT,
      taskCustList: EMPTY_LIST,
    },
    motTaskId: '--',
    motTaskName: '--',
    pageNum: 1,
  }

  constructor(props) {
    super(props);
    const { list: { taskCustList } } = props;
    this.state = {
      dataSource: prepareDataSource(taskCustList),
      isLoading: false,
      isRefreshing: false,
      isLoaded: false,
      messageHeight: 0,
      currentMotTaskName: '',
      currentDetailInfo: '',
      // 弹出info dialog
      isShowInfo: false,
    };
  }

  componentDidMount() {
    this.setHeight();
  }

  @checkErrData({ loadingName: 'isRefreshing' })
  componentWillReceiveProps(nextProps) {
    const { list: { taskCustList } } = nextProps;
    const { list: preList } = this.props;
    const { taskCustList: preTaskCustList } = preList;

    if (taskCustList !== preTaskCustList) {
      const stateMap = {
        isLoading: false,
        dataSource: prepareDataSource(taskCustList),
      };
      this.setState(stateMap);
    }
  }

  componentDidUpdate() {
    this.setHeight();
  }

  // 下拉刷新
  @autobind
  @checkListPTR()
  onRefresh() {
    const { location: { query }, refresh, reportRefresh } = this.props;
    refresh({
      ...query,
      pageNum: 1,
    });
    reportRefresh({
      actionSource: '任务详情',
    });
  }
  // 上拉加载
  @autobind
  onEndReached() {
    const { isLoading } = this.state;
    const { list: { taskPage } } = this.props;
    if (!isLoading
      && (taskPage && taskPage.curPageNum < taskPage.totalPageNum)
      && cordova.isConnected()
    ) {
      this.setState(
        { isLoading: true },
        this.refreshMore,
      );
    }
  }
  // 设置列表高度
  setHeight() {
    if (this.listElem) {
      const listElem = ReactDOM.findDOMNode(this.listElem); // eslint-disable-line
      const height = document.documentElement.clientHeight
        - listElem.getBoundingClientRect().top;
      listElem.style.height = `${height}px`;

      // 更新 列表高度messageHeight
      this.setState({
        messageHeight: height,
      });
      // 调用容器组件方法
      this.props.callBackFunc(height);
    }
  }
  // 设置一下弹出dialog的高度
  setDetailInfoHeight() {
    const modalBody = document.querySelector('.am-modal .am-modal-body');
    if (modalBody) {
      modalBody.style.maxHeight = `${document.documentElement.clientHeight * 0.4}px`;
    }
  }
  // 请求第2页和之后的数据
  @autobind
  refreshMore() {
    const { refresh, list: { taskPage }, location: { query } } = this.props;
    refresh({
      ...query,
      pageNum: taskPage.curPageNum + 1,
    });
  }
  // 点击 ‘更多’，展示modal 弹框
  @autobind
  handleInfoClick(rowData) {
    const { motTaskName, taskSeqDetailInfo } = rowData;
    this.setState({
      isShowInfo: true,
      currentMotTaskName: motTaskName,
      currentDetailInfo: taskSeqDetailInfo,
    }, this.setDetailInfoHeight);
  }
  // 关闭modal 弹框
  @autobind
  handleInfoClose() {
    this.setState({ isShowInfo: false });
  }

  @autobind
  renderRow(rowData, sectionID, rowID) {
    const {
      push,
      location,
      motTaskId,
      motTaskName,
      reportSwipeAction,
      showGuideAgain,
    } = this.props;
    return (
      <MotCustItem
        key={`${sectionID}-${rowID}`}
        data={{ ...rowData, motTaskId, motTaskName, rowID }}
        push={push}
        onInfoClick={this.handleInfoClick}
        location={location}
        rowID={rowID}
        reportSwipeAction={reportSwipeAction}
        handleClick={showGuideAgain}
      />
    );
  }

  @autobind
  renderSeparator(sectionID, rowID) {
    const { dataSource } = this.state;
    // row是从0开始的
    const row = parseInt(rowID.substring(1), 10) + 1;
    // 消除最后一行的分割线
    return (
      dataSource.getRowCount() === row ? null :
      <div
        key={`${sectionID}-${rowID}`}
        className="list-separator"
      />
    );
  }

  @autobind
  renderFooter() {
    const { isLoading, isLoaded, messageHeight } = this.state;
    const { list: { taskPage = EMPTY_OBJECT, taskCustList = EMPTY_LIST } } = this.props;
    let text = '';
    let messageType = '';
    if (!cordova.isConnected() && (!taskCustList || taskCustList.length === 0)) {
      messageType = 'network';
    } else if ((!taskCustList || taskCustList.length === 0) && isLoaded) {
      messageType = 'notfound';
    } else if (isLoading) {
      text = '加载中...';
    } else if (taskPage && taskPage.curPageNum > 1) {
      if (taskPage.curPageNum === taskPage.totalPageNum) {
        text = '已经到底了';
      } else {
        text = '上拉加载更多';
      }
    }
    if (messageType) {
      return (
        <Message
          type={messageType}
          height={messageHeight}
        />
      );
    }
    return (
      <div>
        {text}
      </div>
    );
  }

  render() {
    const {
      dataSource,
      isRefreshing,
      currentMotTaskName,
      currentDetailInfo,
      isShowInfo,
    } = this.state;
    const detailInfo = currentDetailInfo || '暂无信息';
    return (
      <div
        className="page mot-cust-list"
        ref={ref => (this.listBox = ref)}
      >
        <ListView
          ref={ref => (this.listElem = ref)}
          className="list"
          dataSource={dataSource}
          renderRow={this.renderRow}
          renderSeparator={this.renderSeparator}
          renderFooter={this.renderFooter}
          pageSize={10}
          initialListSize={10}
          scrollEventThrottle={20}
          scrollRenderAheadDistance={500}
          onEndReached={this.onEndReached}
          onEndReachedThreshold={10}
          refreshControl={<RefreshControl
            refreshing={isRefreshing}
            onRefresh={this.onRefresh}
            distanceToRefresh={distanceToRefresh}
            icon={renderIcon()}
            loading={renderLoading()}
          />}
        />
        {// 每次都重新创建modal弹框，若重用弹框，会记住滑动的offset，不符合需求。
          isShowInfo ?
            <Modal
              title={currentMotTaskName}
              transparent
              maskClosable={false}
              visible={isShowInfo}
              footer={[{ text: '确定', onPress: this.handleInfoClose }]}
              onClose={this.handleInfoClose}
            >
              <div dangerouslySetInnerHTML={{ __html: detailInfo }} />
            </Modal> : null
        }
      </div>
    );
  }
}
