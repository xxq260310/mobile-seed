/**
 * @file mission/MotDetailDesc.js
 * @author liutingting
 */

import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import ReactDOM from 'react-dom';
import _ from 'lodash';
import Icon from '../../components/common/Icon';
import helper from '../../utils/helper';
import './motDesc.less';

export default class MotDetailDesc extends PureComponent {

  static propTypes = {
    // 基本信息数据
    data: PropTypes.string,
    title: PropTypes.string.isRequired,
    handleClick: PropTypes.func.isRequired,
  }

  static defaultProps = {
    data: '--',
  }

  constructor(props) {
    super(props);
    this.state = {
      isFold: true, // 是否折叠
      isShowMoreInfo: false,
    };
  }

  componentDidMount() {
    this.isShowFoldNode();
  }

  componentDidUpdate() {
    this.isShowFoldNode();
  }
  // 是否显示 ‘更多’ ‘收起’ 按钮
  isShowFoldNode() {
    const { isShowMoreInfo } = this.state;
    const { data } = this.props;
    if (_.isEmpty(data)) {
      return;
    }
    if (!isShowMoreInfo) {
      const container = ReactDOM.findDOMNode(this.container); // eslint-disable-line
      const content = ReactDOM.findDOMNode(this.content); // eslint-disable-line
      // 读取节点的行高，动态设置高度
      const lineHeight = Math.ceil(parseFloat(window.getComputedStyle(content, null).getPropertyValue('line-height'))); // null 参数也可省略
      const maxLineHeight = 2 * lineHeight;
      if (content.offsetHeight > maxLineHeight) {
        container.style.height = `${maxLineHeight}px`;
        this.setState({
          isShowMoreInfo: true,
        });
      } else {
        container.style.height = `${content.offsetHeight}px`;
        this.setState({
          isShowMoreInfo: false,
        });
      }
    }
  }

  /**
   * 点击切换介绍文本展开与收缩
   */
  @autobind
  handleClick() {
    if (this.desc && this.container && this.content) {
      const desc = ReactDOM.findDOMNode(this.desc); // eslint-disable-line
      const container = ReactDOM.findDOMNode(this.container); // eslint-disable-line
      const content = ReactDOM.findDOMNode(this.content); // eslint-disable-line
      // 读取节点的行高，动态设置高度
      const lineHeight = Math.ceil(parseFloat(window.getComputedStyle(content, null).getPropertyValue('line-height'))); // null 参数也可省略
      const maxLineHeight = 2 * lineHeight;
      const { isFold } = this.state;

      if (!isFold) {
        desc.style.paddingBottom = `${helper.getRealSize(30)}px`;
        container.style.height = `${maxLineHeight}px`;
      } else {
        container.style.height = `${content.offsetHeight}px`;
        desc.style.paddingBottom = `${helper.getRealSize(60)}px`;
      }
      this.setState({ isFold: !isFold });
      this.props.handleClick(); // 调用容器组件的方法
    }
  }
  @autobind
  foldNode() {
    const { isFold } = this.state;
    return (
      isFold ?
      (
        <button className="btn" onClick={() => this.handleClick()}>
          更多
          <Icon className="down-icon" type="zhankai" />
        </button>
      )
      :
      (
        <button className="btn up" onClick={() => this.handleClick()}>
          收起
          <Icon className="up-icon" type="shouqi" />
        </button>
      )
    );
  }

  render() {
    const { data = '--', title } = this.props || {};
    const { isShowMoreInfo } = this.state;
    if (_.isEmpty(data)) {
      return (
        <div className="desc  empty-data">
          <div className="top">
            <Icon className="notice-icon" type="tixing" />
            <div className="title">{title}</div>
          </div>
        </div>
      );
    }
    return (
      <div className="desc" ref={ref => (this.desc = ref)}>
        <div className="top">
          <Icon className="notice-icon" type="tixing" />
          <div className="title">{title}</div>
        </div>
        <div className="container" ref={ref => (this.container = ref)}>
          <div className="content" ref={ref => (this.content = ref)}>{data}</div>
        </div>
        {
          isShowMoreInfo ? this.foldNode() : null
        }
      </div>
    );
  }
}
