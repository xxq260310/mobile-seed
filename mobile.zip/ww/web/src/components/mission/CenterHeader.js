/**
 * @file mission/CenterList.js
 * @author fengwencong
 */
import React, { PropTypes, PureComponent } from 'react';

import Icon from '../common/Icon';
import './centerheader.less';

export default class CenterHeader extends PureComponent {

  static propTypes = {
    data: PropTypes.object.isRequired,
    onOpenChange: PropTypes.func.isRequired,
  }

  render() {
    const {
      endTodayCount = 0,
      totalCount = 0,
    } = this.props.data;
    return (
      <div className="centerHead">
        <div className="missionHead">
          <div className="title">任务中心</div>
          <div className="headPart">
            <div className="headNum">{endTodayCount}</div>
            <div className="headLabel">今日到期</div>
          </div>
          <div className="line" />
          <div className="headPart">
            <div className="headNum">
              {totalCount > 99 ? <span>99<sup>+</sup></span> : totalCount}
            </div>
            <div className="headLabel">今日可做</div>
          </div>
        </div>
        <div className="listHead">
          <div className="redLine" />
          <div className="title">任务列表</div>
          <div className="centerHeadFilter" onClick={this.props.onOpenChange}>
            <div className="filter-title">筛选</div>
            <Icon type="xiangxia" className="filter-icon" />
          </div>
        </div>
      </div>
    );
  }
}
