/**
 * @file mission/CenterList.js
 * @author fengwencong
 */
import React, { PropTypes, PureComponent } from 'react';
import ReactDOM from 'react-dom';
import { autobind } from 'core-decorators';
import { RefreshControl, ListView } from 'antd-mobile';
import _ from 'lodash';

import { constants } from '../../config';
import helper from '../../utils/helper';
import { prepareDataSource } from '../../utils/listView';
import cordova from '../../utils/cordova';
import { renderIcon, renderLoading, distanceToRefresh } from '../../components/common/PullToRefreshable';
import CenterListItem from './CenterListItem';
import Message from '../message';
import { checkListPTR } from '../../decorators/checkNetwork';
import { checkErrData } from '../../decorators/checkErrorData';
import './centerList.less';

const EMPTY_OBJECT = {};

export default class CenterList extends PureComponent {

  static propTypes = {
    data: PropTypes.object.isRequired,
    getCenter: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    replace: PropTypes.func.isRequired,
    push: PropTypes.func.isRequired,
    reportDetail: PropTypes.func,
    onOpenChange: PropTypes.func.isRequired,
    isFetching: PropTypes.bool.isRequired,
    reportRefresh: PropTypes.func.isRequired,
  }

  static defaultProps = {
    reportDetail: () => { },
  }

  constructor(props) {
    super(props);

    const { motTaskList = [] } = props.data;
    this.state = {
      dataSource: prepareDataSource(this.handleFilter(motTaskList, props)),
      isLoading: false,
      isLoaded: motTaskList.length > 0,
      listHeight: 0,
    };
  }

  componentDidMount() {
    this.setHeight();
  }

  @checkErrData()
  componentWillReceiveProps(nextProps) {
    const { data, location: { query } } = nextProps;
    const { location: { query: oldQuery } } = this.props;
    const { motTaskList = [] } = data;
    if (data !== this.props.data || !_.isEqual(query, oldQuery)) {
      const newList = this.handleFilter(motTaskList, nextProps);
      this.setState({
        dataSource: prepareDataSource(newList),
      });
    }
    // 条件变化
    if (!_.isEqual(query, oldQuery)) {
      this.resetScroll();
    }
  }

  componentDidUpdate() {
    this.setHeight();
  }

  @autobind
  @checkListPTR({ propertyName: 'isLoading' })
  onRefresh() {
    const { getCenter, location: { query }, reportRefresh } = this.props;
    getCenter({
      ...query,
    });
    reportRefresh({
      actionSource: '任务列表',
    });
  }

  setHeight() {
    // list 区域的高度
    const header = document.querySelector('.centerHead');
    const height = header ? helper.getAvailableHeight({
      el: ['.centerHead'],
    }) : helper.getAvailableHeight();
    this.setState({ listHeight: height });
    // 更新列表高度
    if (this.listElem) {
      const listElem = ReactDOM.findDOMNode(this.listElem); // eslint-disable-line
      const marginTop = document.querySelector('.centerHead').offsetHeight;
      listElem.style.height = `${height}px`;
      listElem.style.marginTop = `${marginTop}px`;
    }
  }

  @autobind
  handleFilter(list, nextProps) {
    if (_.isEmpty(list)) {
      return EMPTY_OBJECT;
    }
    const { location: { query } } = nextProps;
    if (query.motTaskExecuteType) {
      const filter = query.motTaskExecuteType.split(',');
      const newList = [];
      list.forEach(
        (line) => {
          filter.forEach(
            (fil) => {
              if (fil && line.motTaskExecuteType === fil) {
                newList.push(line);
              }
            },
          );
        },
      );
      return newList;
    }
    return list;
  }

  @autobind
  handleItemClick(rowData) {
    const { push, reportDetail } = this.props;
    const { motTaskName, motTaskId } = rowData;
    // 数据上报
    reportDetail(rowData);
    // 跳转到任务详情
    push({
      pathname: '/mission/taskDetail',
      query: {
        motTaskName,
        motTaskId,
      },
    });
  }

  resetScroll() {
    if (this.listElem) {
      this.listElem.refs.listview.scrollTo(0, 0);
    }
  }

  @autobind
  renderRow(rowData, sectionID, rowID) {
    if (_.isEmpty(rowData)) {
      return null;
    }
    return (
      <CenterListItem
        onClick={() => this.handleItemClick(rowData)}
        key={`${sectionID}-${rowID}`}
        {...rowData}
      />
    );
  }

  renderSeparator(sectionID, rowID) {
    return (
      <div
        key={`${sectionID}-${rowID}`}
        className="list-separator"
      />
    );
  }

  @autobind
  renderFooter() {
    const { isLoaded, listHeight, dataSource } = this.state;
    const { totalCount } = this.props.data;
    const separatorLine = document.querySelector('.list-separator');

    const rowCount = dataSource.getRowCount();
    let messageType = '';
    if (totalCount === 0) {
      if (!cordova.isConnected()) {
        messageType = 'network';
      } else if (isLoaded) {
        messageType = 'complete';
      }
    } else if (rowCount === 0 && isLoaded) {
      messageType = 'notfound';
    }
    // 当messageType存在时，去除下拉刷新下面残留的分割线
    if (messageType && separatorLine) {
      separatorLine.style.borderBottom = 'none';
      separatorLine.style.height = '0px';
    }
    return messageType ? (
      <Message type={messageType} height={listHeight} />
    ) : null;
  }

  render() {
    const { dataSource, isLoading } = this.state;
    return (
      <ListView
        ref={ref => (this.listElem = ref)}
        className="mission-list"
        dataSource={dataSource}
        renderFooter={this.renderFooter}
        renderRow={this.renderRow}
        renderSeparator={this.renderSeparator}
        pageSize={10}
        initialListSize={constants.initialListSize}
        scrollRenderAheadDistance={400}
        scrollEventThrottle={20}
        refreshControl={<RefreshControl
          refreshing={isLoading}
          onRefresh={this.onRefresh}
          distanceToRefresh={distanceToRefresh}
          icon={renderIcon()}
          loading={renderLoading()}
        />}
      />
    );
  }
}
