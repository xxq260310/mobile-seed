import React, { PropTypes } from 'react';
import { Progress } from 'antd-mobile';
import { autobind } from 'core-decorators';

import './centerListItem.less';

class CenterListItem extends React.Component {
  static propTypes = {
    onClick: PropTypes.func,
    motTaskId: PropTypes.string,
    motTaskCreatedTime: PropTypes.string,
    motTaskName: PropTypes.string,
    motTaskExecuteType: PropTypes.string,
    motTaskExecuteTypeName: PropTypes.string,
    motTaskExpireTime: PropTypes.string,
    motTaskProcessingItems: PropTypes.number,
    totalCusts: PropTypes.number,
    motTaskAccRate: PropTypes.number,
    processedCusts: PropTypes.number,
  };

  static defaultProps = {
    motTaskId: '--',
    motTaskCreatedTime: '--',
    motTaskName: '--',
    motTaskExecuteType: '--',
    motTaskExecuteTypeName: '--',
    motTaskExpireTime: '--',
    motTaskProcessingItems: 0,
    totalCusts: 0,
    motTaskAccRate: 0,
    processedCusts: 0,
    onClick: () => {},
  }

  @autobind
  handleClick() {
    this.props.onClick();
  }

  render() {
    const {
      motTaskName,
      motTaskExecuteTypeName,
      motTaskExpireTime,
      processedCusts,
      motTaskAccRate,
      totalCusts,
    } = this.props;
    const optionType = motTaskExecuteTypeName === '必做' ? 'surely' : 'optional';
    return (
      <div className="center-item" onClick={this.handleClick}>
        <div className="item-top">
          <div className="title">{motTaskName}</div>
          <div className={`type ${optionType}`}>{motTaskExecuteTypeName}</div>
        </div>
        <div className="item-middle">
          <Progress
            percent={motTaskAccRate || 0}
            position="normal"
            appearTransition
          />
        </div>
        <div className="item-bottom">
          <div className="finish">
            已完成
            { /* 999/999 最长支持三位数 */ }
            {processedCusts || 0}/{totalCusts || 0}
          </div>
          <div className="expire-time">
            完成时间:{motTaskExpireTime.replace(/-/g, '/')}
          </div>
        </div>
      </div>
    );
  }
}

export default CenterListItem;
