/**
 * @file mission/InfoPopover.js
 * @author liutingting
 */

import React, { PropTypes, PureComponent } from 'react';
import ReactDOM from 'react-dom';
import { Popover } from 'antd-mobile';

import './infoPopover.less';

export default class InfoPopover extends PureComponent {

  static propTypes = {
    popover: PropTypes.object.isRequired,
    list: PropTypes.object.isRequired,
    callback: PropTypes.func,
  }

  static defaultProps = {
    popover: {},
    list: {},
    callback: () => { },
  }

  constructor(props) {
    super(props);

    this.state = {
      popoverStyle: 'bottomLeft',
      removeY: 0,
    };
  }

  componentWillReceiveProps(nextProps) {
    const { popover = {} } = nextProps || {};
    const { visible } = popover;
    this.maskTouchHandle();
    if (visible && visible !== this.props.popover.visible) {
      this.initStyle();
    }
    // else if (!visible && visible !== this.props.popover.visible) { }
  }

  componentWillUpdate() {
    this.maskTouchHandle();
    const { popover: { visible } } = this.props;
    if (visible) {
      // console.log('hide ...');
    } else {
      // console.log('show ...');
    }
  }

  componentDidUpdate() {
    // console.log('componentDidUpdate ...');
  }

  componentWillUnmount() {
    // 移除事件监听
    const maskNode = document.querySelector('.am-popover-mask');
    if (maskNode) {
      ReactDOM.findDOMNode(maskNode).removeEventListener('touchstart', // eslint-disable-line
        this.maskListenHandle, false);
    }
  }

  initStyle() {
    const {
      popover: { offsetY = 0, baseRemoveY = 0 },
      list: { listScrollY = 0, listHeight = 0 },
    } = this.props || {};
    if ((offsetY + listScrollY) < listHeight) {
      this.setState({
        popoverStyle: this.state.popoverStyle,
        removeY: offsetY + listScrollY,
      });
      return null;
    }
    this.setState({
      popoverStyle: 'topLeft',
      removeY: (offsetY + listScrollY) - baseRemoveY,
    });
    return null;
  }

  resetStyle() { // 重置位置
    const {
      popover: { offsetY = 0, baseRemoveY = 0 },
      list: { listScrollY = 0, listHeight = 0 },
    } = this.props || {};
    const popoverNode = ReactDOM.findDOMNode(document.querySelector('.am-popover')); // eslint-disable-line
    if (popoverNode) {
      const nodeHeight = popoverNode.clientHeight;
      const nodeTop = popoverNode.offsetTop;
      if ((nodeHeight + nodeTop) < listHeight) {
        this.setState({
          popoverStyle: this.state.popoverStyle,
          removeY: offsetY + listScrollY,
        });
        return null;
      }
      this.setState({
        popoverStyle: 'topLeft',
        removeY: (offsetY + listScrollY) - baseRemoveY,
      });
    }
    return null;
  }

  maskTouchHandle() {
    // 蒙层背景Touch监听
    const maskNode = document.querySelector('.am-popover-mask');
    if (maskNode) {
      ReactDOM.findDOMNode(maskNode).addEventListener('touchstart', // eslint-disable-line
        this.maskListenHandle, false);
    }
  }

  maskListenHandle(e) {
    // 阻止冒泡
    e.stopPropagation();
  }

  /**
   * 点击背景清除弹窗
   */
  handleHideChange = () => {
    this.setState({
      popoverStyle: 'bottomLeft',
      removeY: 0,
    });
    this.props.callback();
  }

  render() {
    const {
      popover: {
        // offsetY = 0,
        // baseRemoveY,
        visible = true,
        contain = '' },
      // list: { listScrollY, listHeight }
    } = this.props || {};
    const { popoverStyle, removeY } = this.state;

    return (
      <Popover
        mask
        visible={visible}
        placement={popoverStyle}
        overlay={<div className="contain" dangerouslySetInnerHTML={{ __html: contain }} />}
        popupAlign={{
          overflow: { adjustY: true, adjustX: false },
          offset: [0, removeY],
          targetOffset: [0, 0],
          useCssTransform: false,
        }}
        onVisibleChange={this.handleHideChange}
      ><span /></Popover>
    );
  }
}
