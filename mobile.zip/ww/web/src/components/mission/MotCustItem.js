/**
 * @file mission/MotCustItem.js
 * @author liutingting
 */

import React, { PropTypes, PureComponent } from 'react';
import ReactDOM from 'react-dom';
import { SwipeAction } from 'antd-mobile';
import { autobind } from 'core-decorators';
import { connect } from 'react-redux';
import _ from 'lodash';
import moment from 'moment';
import 'moment/locale/zh-cn';
import helper from '../../utils/helper';
import Toast from '../../components/common/Toast';
import { callPhone } from '../../utils/cordova';
import Icon from '../common/Icon';
import { constants } from '../../config';
import './motCustItem.less';

const mapStateToProps = state => ({
  // 是否授权可以拨打电话
  canCall: state.global.canCall,
  empInfoData: state.global.empInfo,
  flagArray: state.mission.flagArray,
});

const mapDispatchToProps = {
  // 记录当前页的点击事件
  recordClickEvent: query => ({
    type: 'mission/getFlagArraySuccess',
    payload: query,
  }),
  saveRecordPageNeedfulData: query => ({
    type: 'mission/saveRecordPageNeedfulDataSuccess',
    payload: query,
  }),
};

// const EMPTY_OBJECT = {};

@connect(mapStateToProps, mapDispatchToProps)
export default class MotCustItem extends PureComponent {

  static propTypes = {
    data: PropTypes.object,
    push: PropTypes.func.isRequired,
    onInfoClick: PropTypes.func,
    empInfoData: PropTypes.object.isRequired,
    location: PropTypes.object.isRequired,
    rowID: PropTypes.string,
    reportSwipeAction: PropTypes.func.isRequired,
    handleClick: PropTypes.func.isRequired,
    flagArray: PropTypes.array.isRequired,
    recordClickEvent: PropTypes.func.isRequired,
    canCall: PropTypes.bool,
    saveRecordPageNeedfulData: PropTypes.func.isRequired,
  }

  static defaultProps = {
    data: {},
    onInfoClick: () => { },
    rowID: '',
    canCall: false,
  }

  constructor(props) {
    super(props);
    this.state = {
      isShowMoreInfo: false,
    };
  }

  componentDidMount() {
    this.isShowMoreNode();
  }

  componentDidUpdate() {
    this.isShowMoreNode();
  }

  isShowMoreNode() {
    if (this.content) {
      const content = ReactDOM.findDOMNode(this.content); // eslint-disable-line
      // 读取节点的行高，动态设置高度
      const lineHeight = Math.ceil(parseFloat(window.getComputedStyle(content, null).getPropertyValue('line-height'))); // null 参数也可省略
      // 行高为35px，大于两行，显示更多按钮
      if (content.offsetHeight > 2 * lineHeight) {
        this.setState({ isShowMoreInfo: true });
      } else {
        this.setState({ isShowMoreInfo: false });
      }
    }
  }

  @autobind
  handleCustClick() {
    const {
      empInfoData: { rowId },
      handleClick,
      recordClickEvent,
      data: {
        custNumber,
        custType,
        custRowId,
        motTaskId,
      },
      push,
      flagArray,
    } = this.props;
    const showFlag = `NOREMOVE-GUIDE-NUMBER-STORAGE-${rowId}`;
    let number = helper.getPersistItem(showFlag) || 0;
    if (!_.includes(flagArray, motTaskId) && number < constants.showCount) {
      // 发送action，记录当前点击的任务 id
      recordClickEvent({ motTaskId });
      // 如若用户对item的侧滑操作未执行，则点击展示 侧滑提示层 最多三次
      handleClick(number);
      number++;
      helper.setLocalStorageItem(showFlag, number);
      return;
    }

    // 点击用户信息跳转
    push({
      pathname: '/customer/detail',
      query: {
        custNumber,
        custId: custRowId,
        custSor: custType === 'prod' ? 'org' : custType,
        motTaskId,
      },
    });
  }

  @autobind
  checkGarde(custGrade) {
    // 检测任务等级
    let grade = '';
    switch (custGrade) {
      case '金':
        grade = 'goldCard';
        break;
      case '银':
        grade = 'silverCard';
        break;
      case '钻石':
        grade = 'diamondCard';
        break;
      case '理财':
        grade = 'financeCard';
        break;
      case '白金':
        grade = 'whiteGoldCard';
        break;
      default:
        grade = 'emptyCard';
        break;
    }
    return grade;
  }

  @autobind
  handleMenuClick() {
    console.log('click');
  }

  // 点击滑动组件的电话联系组件
  @autobind
  handleTelephoneContactClick() {
    const { data: { custPhoneNumber } } = this.props;
    if (_.isEmpty(custPhoneNumber)) {
      Toast.fail('CRM系统中没有维护该客户的联系方式', 1);
      return;
    }
    // 调用native拨打电话
    callPhone({ number: custPhoneNumber }, this.handleServiceRecord);
  }

  // 打完电话的回调，处理跳转服务记录相关数据等
  @autobind
  handleServiceRecord(callDuration) {
    const {
      push,
      data: {
        custRowId,
        custType,
        custName,
        custNumber,
        flowId,
        motTaskId,
      },
      saveRecordPageNeedfulData,
    } = this.props;
    // 服务时间
    this.zhNow = moment().locale('zh-cn').utcOffset(8);
    const serveDate = this.zhNow.format('YYYY年MM月DD日 HH:mm');
    // 保存服务记录页面所需要的数据到state中
    // serveWay: 服务方式,打电话就是电话，直接完成则服务方式在服务记录页面选择
    // serveDate: 服务日期，callDuration: 通话时长
    // eventFlowIdList: 有任务，传的任务flowId数组,无任务则不传
    // prod为产品机构，但是
    saveRecordPageNeedfulData({
      custId: custRowId,
      custName,
      custType,
      custNumber,
      serveWay: '电话',
      serveDate,
      callDuration,
      eventFlowIdList: [flowId],
      motTaskId,
    });
    push({
      pathname: '/customer/Record',
      query: {
        custId: custRowId,
        custType,
      },
    });
  }

  // 点击右侧滑动组件的直接完成按钮
  @autobind
  handleDirectCompeletClick() {
    const {
      push,
      data: {
        custRowId,
        custType,
        custName,
        custNumber,
        flowId,
        motTaskId,
      },
      saveRecordPageNeedfulData,
    } = this.props;
    // 保存服务记录页面所需要的数据到state中
    // serveWay: 服务方式,直接完成则服务方式在服务记录页面选择
    // serveDate: 服务日期,击直接完成，取服务记录页面保存的时候日期
    // eventFlowIdList: 有任务，传的任务flowId数组,无任务则不传
    saveRecordPageNeedfulData({
      custId: custRowId,
      custType,
      custName,
      custNumber,
      motTaskId,
      eventFlowIdList: [flowId],
    });
    push({
      pathname: '/customer/Record',
      query: {
        custId: custRowId,
        custType,
      },
    });
  }

  @autobind
  reportLog() {
    const { data, reportSwipeAction } = this.props;
    reportSwipeAction(data);
    // 触发侧滑item，则 侧滑提示层 不在出现
    const { empInfoData: { rowId } } = this.props;
    const showFlag = `NOREMOVE-GUIDE-NUMBER-STORAGE-${rowId}`;
    const number = helper.getPersistItem(showFlag) || 0;
    if (number < constants.showCount) {
      helper.setLocalStorageItem(showFlag, Number.MAX_VALUE);
    }
  }

  @autobind
  renderCommon() {
    const {
      data: {
        custType,
        custName,
        taskReqStatus,
        custGrade,
        custGender,
        custAge,
        taskSeqDetailInfo,
        custPhoneNumber,
        custWaitForTaskNum,
        motTaskName,
      },
      onInfoClick,
    } = this.props;
    // 后端可能将taskSeqDetailInfo传成null
    const detailInfo = !_.isEmpty(taskSeqDetailInfo) ? taskSeqDetailInfo : '暂无信息';
    const text = detailInfo.replace(/<[^>]+?>/g, '');
    const { isShowMoreInfo } = this.state;
    return (
      <div className="mot-item">
        <div className="item-up" onClick={() => this.handleCustClick()}>
          <div className="left">
            <div className={`${custType}-avatar avatar`} />
          </div>
          <div className="middle">
            <div className="first-row">
              <div className={`name ${custType}-name`}>{custName || '--'}</div>
              <div className={`card ${this.checkGarde(custGrade)}`} />
            </div>
            <div className="second-row">
              {
                custType === 'per' ?
                  <div className="per-info">
                    <div className="sex">{custGender || '--'}</div>
                    <div className="age">{`${custAge}岁` || '--'}</div>
                  </div>
                  :
                  null
              }
              <div className="telephone">{custPhoneNumber || '--'}</div>
            </div>
          </div>
          <div className="right">
            <div className="line" />
            {
              (custWaitForTaskNum && custWaitForTaskNum !== '0') ?
                (
                  <div className="task">
                    待办任务
                  <div className="count">{custWaitForTaskNum}</div>
                  </div>

                )
                : null
            }
            <Icon className="more-icon" type="more" />
            {
              taskReqStatus === 'Y' ?
                <Icon className="finish-icon" type="wancheng2" />
                : null
            }
          </div>
        </div>
        <div className="item-below">
          <div className="container">
            <div className="content" ref={ref => (this.content = ref)}>{text}</div>
          </div>
        </div>
        {
          isShowMoreInfo ?
            <button className="btn" onClick={() => onInfoClick({ motTaskName, taskSeqDetailInfo })}>
              <div className="more">更多</div>
              <Icon className="down-icon" type="zhankai" />
            </button>
            : null
        }
      </div>
    );
  }

  // 渲染右侧滑动组件的right
  @autobind
  renderSwipeActionRight() {
    const { canCall } = this.props;
    const isAndorid = helper.isAndorid();
    let swipeActionRight = [
      {
        text: '直接完成',
        onPress: this.handleDirectCompeletClick,
        style: {
          backgroundColor: '#ffc856',
          color: 'white',
        },
      },
    ];
    // 授权并且是安卓用户才能显示电话联系按钮
    if (canCall && isAndorid) {
      const increasedRight = [
        {
          text: '电话联系',
          onPress: this.handleTelephoneContactClick,
          style: {
            backgroundColor: '#ff655e',
            color: 'white',
          },
        },
      ];
      swipeActionRight = [...swipeActionRight, ...increasedRight];
    }
    return swipeActionRight;
  }

  render() {
    const { data: { taskReqStatus }, canCall } = this.props;
    const isAndorid = helper.isAndorid();
    let swipeActionClassName = 'swipe-list';
    if (canCall && isAndorid) {
      swipeActionClassName = 'swipe-list canCall-list';
    }
    return (
      taskReqStatus === 'Y' ?
        this.renderCommon() :
        <SwipeAction
          className={swipeActionClassName}
          autoClose
          right={this.renderSwipeActionRight()}
          onOpen={this.reportLog}
        >
          {this.renderCommon()}
        </SwipeAction>
    );
  }
}
