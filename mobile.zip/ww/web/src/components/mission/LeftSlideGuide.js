/**
 * @file mission/LeftSlideGuide.js
 * @author yangquanjian
*/
import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import { connect } from 'react-redux';
import classnames from 'classnames';
import helper from '../../utils/helper';
import './leftSlideGuide.less';
import guideImg from '../../../static/img/swipeGuide.png';
import clickGuide from '../../../static/img/clickGuide.png';
import { constants } from '../../config';

const mapStateToProps = state => ({
  token: state.global.token,
  empInfo: state.global.empInfo,
});

@connect(mapStateToProps, null)
export default class LeftSlideGuide extends PureComponent {

  static propTypes = {
    empInfo: PropTypes.object.isRequired,
    list: PropTypes.array,
    listHeight: PropTypes.number.isRequired,
    showNumber: PropTypes.number.isRequired,
  }
  static defaultProps = {
    list: [],
  }
  constructor(props) {
    super(props);
    this.state = {
      isShowing: false,
    };
  }

  componentWillReceiveProps(nextProps) {
    const { empInfo: { rowId }, list } = this.props;
    const storage = `NOREMOVE-GUIDE-STORAGE-${rowId}`;
    const storageVal = helper.getPersistItem(storage) || null;
    if (list.length === 0 && nextProps.list.length > 0 && storageVal === null) {
      this.setState({
        isShowing: true,
      }, this.recordShowGuide);
    }
    // 点击 list的item 最多让引导层出现 3 次,number 为本地化存储的（引导页显示）次数
    const showFlag = `NOREMOVE-GUIDE-NUMBER-STORAGE-${rowId}`;
    const number = helper.getPersistItem(showFlag) || 0;
    const flag = number <= constants.showCount;
    if (flag && nextProps.showNumber > -1 && nextProps.showNumber < constants.showCount) {
      this.setState({
        isShowing: true,
      });
    }
  }

  recordShowGuide() {
    const { empInfo: { rowId } } = this.props;
    const storage = `NOREMOVE-GUIDE-STORAGE-${rowId}`;
    helper.setLocalStorageItem(storage, storage);
  }

  @autobind
  handlClick() {
    this.setState({
      isShowing: false,
    });
  }

  render() {
    const pop = classnames({
      guidebox: true,
      'pop-show': this.state.isShowing,
    });
    const { listHeight, empInfo: { rowId } } = this.props;
    const style = { height: listHeight };
    const storage = `NOREMOVE-GUIDE-STORAGE-${rowId}`;
    const storageVal = helper.getPersistItem(storage) || null;
    return (
      <div className={pop} id="guidebox">
        <div className="inner" style={style}>
          <div className="imgbox">
            {
              storageVal
              ?
                <img src={clickGuide} alt="左滑引导" />
              :
                <img src={guideImg} alt="左滑引导" />
            }
          </div>
          <div className="btn-dv">
            <button onClick={this.handlClick} />
          </div>
        </div>
      </div>
    );
  }
}

