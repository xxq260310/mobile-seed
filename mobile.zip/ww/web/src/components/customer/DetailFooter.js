/**
 * @file customer/DetailFooter.js
 * @author xuxiaoqin
 */

import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import './detailFooter.less';

export default class CustomerDetailFooter extends PureComponent {

  static propTypes = {
    data: PropTypes.object.isRequired,
    push: PropTypes.func.isRequired,
    // 最后一次服务时间
    lastCommission: PropTypes.string,
    // 客户号
    custId: PropTypes.string,
    // 经济客户号
    custNumber: PropTypes.string,
    // 客户类型
    custSor: PropTypes.string,

    motTaskId: PropTypes.string,

    custMotCount: PropTypes.number.isRequired,
  }

  static defaultProps = {
    push: () => { },
    lastCommission: '',
    custId: '',
    custNumber: '',
    custSor: '',
    motTaskId: '',
  }

  constructor(props) {
    super(props);

    this.state = {
      isLoading: false,
    };
  }

  /**
   * 处理用户点击事件
   */
  @autobind
  handleClick(type) {
    const { push, custId, custNumber, custSor, data, motTaskId } = this.props;
    if (type === 'serviceRecord') {
      push({
        pathname: '/customer/serviceList',
        query: {
          custId,
          custSor,
          custNumber,
        },
      });
    } else if (type === 'contact') {
      const location = {
        pathname: custSor === 'per' ? '/customer/custContactPer' : '/customer/custContactOrg',
        query: {
          custNumber,
          custSor,
          custId,
          custName: data.custName,
        },
      };
      push(location);
    } else if (type === 'custBusiness') {
      push({
        pathname: '/customer/custBusinessInfo',
        query: {
          custId,
          custSor,
        },
      });
    } else if (type === 'custTaskList') {
      push({
        pathname: '/customer/custTaskList',
        query: {
          custId,
          custSor,
          custNumber,
          motTaskId,
          custName: data.custName,
        },
      });
    }
  }

  render() {
    const { custMotCount } = this.props;

    return (
      <div className="detailFooterSection">
        <div className="detailFooterMenu">
          <div className="dbmissionSection" onClick={() => { this.handleClick('custTaskList'); }}>
            <i alt="mission" className="dbmission" />
            {
              (custMotCount && custMotCount !== 0)
                ? <span className="taskNumTip">{custMotCount}</span> : null
            }
            <p>待办任务</p>
          </div>
          <div className="contactSection" onClick={() => { this.handleClick('contact'); }}>
            <i alt="contact" className="contact" />
            <p>联系方式</p>
          </div>
          <div className="serRecordSection" onClick={() => { this.handleClick('serviceRecord'); }}>
            <i alt="serRecord" className="serRecord" />
            <p>服务记录</p>
          </div>
          <div className="businessSection" onClick={() => { this.handleClick('custBusiness'); }}>
            <i alt="business" className="business" />
            <p>已开通业务</p>
          </div>
        </div>
      </div>
    );
  }
}
