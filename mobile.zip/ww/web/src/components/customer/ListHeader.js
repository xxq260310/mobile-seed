/**
 * @file customer/ListHeader.js
 * @author fengwencong
 */
import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import { Menu } from 'antd-mobile';
import classnames from 'classnames';

import { options } from '../../config';
import Icon from '../../components/common/Icon';
import './listheader.less';

const custTypeOptions = options.custTypeOptions;
const custLevelOptions = options.custLevelOptions;

export default class CustomerHeader extends PureComponent {

  static propTypes = {
    onOpenChange: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    replace: PropTypes.func.isRequired,
    maskShow: PropTypes.bool.isRequired,
    popMaskShow: PropTypes.func.isRequired,
  }

  constructor(props) {
    super(props);

    const { location: { query } } = this.props;
    // 查看客户性质的初始值
    const custTypeMenuInit = [];
    const custLevMenuInit = [];
    if (query.custNature) {
      custTypeMenuInit.push(query.custNature);
    } else {
      custTypeMenuInit.push('all');
    }
    if (query.custLevel) {
      custLevMenuInit.push(query.custLevel);
    } else {
      custLevMenuInit.push('all');
    }

    this.state = {
      orderType: query.orderType ? query.orderType : 'desc',
      typeClass: custTypeMenuInit[0] === 'all' ? 'all' : 'sel',
      typeMenuValue: custTypeMenuInit,
      typeMenuShow: false,
      typeName: custTypeMenuInit[0] === 'all'
      ? '客户性质' : this.getMenuLabel(custTypeMenuInit[0], custTypeOptions),
      levClass: custLevMenuInit[0] === 'all' ? 'all' : 'sel',
      levMenuShow: false,
      levelMenuValue: custLevMenuInit,
      levelName: custLevMenuInit[0] === 'all'
      ? '所有等级' : this.getMenuLabel(custLevMenuInit[0], custLevelOptions),
    };
  }

  componentWillReceiveProps(nextProps) {
    const { maskShow } = nextProps;
    if (!maskShow) {
      this.setState({
        levMenuShow: false,
        typeMenuShow: false,
      });
    }
  }

  @autobind
  getMenuLabel(val, menus) {
    let tempVal = val;
    if (!tempVal) {
      tempVal = 'all';
    }
    const filteredMenu = menus.filter(item => item.value === tempVal);
    return filteredMenu[0].label;
  }

  @autobind
  handleTypeChange(selected) {
    const typeSelect = selected[0];
    const typeName = this.getMenuLabel(typeSelect, custTypeOptions);
    const { replace, location: { query } } = this.props;
    replace({
      pathname: '/customer',
      query: {
        ...query,
        custNature: typeSelect === 'all' ? '' : typeSelect,
      },
    });
    // TODO 此处需要隐藏下拉框和蒙层
    this.props.popMaskShow(false);
    this.setState({
      typeMenuShow: false,
      typeMenuValue: [typeSelect],
      typeName,
      typeClass: typeSelect === 'all' ? 'all' : 'sel',
    });
  }

  @autobind
  handleLevChange(selected) {
    const levSelect = selected[0];
    const levelName = this.getMenuLabel(levSelect, custLevelOptions);
    const { replace, location: { query } } = this.props;
    replace({
      pathname: '/customer',
      query: {
        ...query,
        custLevel: levSelect === 'all' ? '' : levSelect,
      },
    });
    // TODO 此处需要隐藏下拉框和蒙层
    this.props.popMaskShow(false);
    this.setState({
      levMenuShow: false,
      levelMenuValue: [levSelect],
      levelName,
      levClass: levSelect === 'all' ? 'all' : 'sel',
    });
  }

  @autobind
  handleSortChange() {
    const { replace, location: { query } } = this.props;
    const { orderType } = this.state;
    let newSort = '';
    if (orderType === 'desc') {
      this.setState({
        orderType: 'asc',
      });
      newSort = 'asc';
    } else {
      this.setState({
        orderType: 'desc',
      });
      newSort = 'desc';
    }
    replace({
      pathname: '/customer',
      query: {
        ...query,
        orderType: newSort,
      },
    });
  }

  @autobind
  handleMenuClick(whichMenu) {
    const { popMaskShow } = this.props;
    const { typeMenuShow, levMenuShow } = this.state;
    if (whichMenu === 'type') {
      if (!typeMenuShow) {
        popMaskShow(true);
      } else {
        popMaskShow(false);
      }
      // 客户性质菜单
      this.setState({
        typeMenuShow: !typeMenuShow,
        levMenuShow: false,
      });
    } else {
      if (!levMenuShow) {
        popMaskShow(true);
      } else {
        popMaskShow(false);
      }
      // 客户等级菜单
      this.setState({
        typeMenuShow: false,
        levMenuShow: !levMenuShow,
      });
    }
  }
  @autobind
  handleTypeMenuClick() {
    this.handleMenuClick('type');
  }

  @autobind
  handleLevMenuClick() {
    this.handleMenuClick('level');
  }

  @autobind
  handleSortClick() {
    this.setState({
      typeMenuShow: false,
      levMenuShow: false,
    });
    this.props.popMaskShow(false);
    this.handleSortChange();
  }

  @autobind
  filterClick() {
    this.setState({
      typeMenuShow: false,
      levMenuShow: false,
    });
    this.props.popMaskShow(false);
    this.props.onOpenChange();
  }

  render() {
    const {
      typeMenuShow,
      levMenuShow,
      typeName,
      levelName,
      typeMenuValue,
      levelMenuValue,
      levClass,
      typeClass,
      orderType,
    } = this.state;

    const custTypeMenu = (
      <Menu
        className="custMenu"
        level="1"
        value={typeMenuValue}
        data={custTypeOptions}
        onChange={this.handleTypeChange}
        height="atuo"
      />
    );
    const custLevMenu = (
      <Menu
        className="custMenu"
        level="1"
        value={levelMenuValue}
        data={custLevelOptions}
        onChange={this.handleLevChange}
        height="atuo"
      />
    );

    const custTypeClass = classnames({
      cusLev: typeClass === 'all',
      cusLevSel: typeClass !== 'all',
      cusLevUp: typeMenuShow,
      cusLevDown: !typeMenuShow,
    });

    const custLevClass = classnames({
      cusLev: levClass === 'all',
      cusLevSel: levClass !== 'all',
      cusLevUp: levMenuShow,
      cusLevDown: !levMenuShow,
    });

    const sortIconClass = classnames({
      sortUp: orderType !== 'desc',
    });

    return (
      <div className="listHeader">
        <div className="sortBlank">
          <div className={custTypeClass} onClick={this.handleTypeMenuClick}>
            {typeName || '客户性质'}
            <b />
          </div>
        </div>
        <div className="sortBlank">
          <div className={custLevClass} onClick={this.handleLevMenuClick}>
            {levelName || '所有等级'}
            <b />
          </div>
        </div>
        <div className="sortBlank" onClick={this.handleSortClick}>
          <p>开户时间</p><i className={sortIconClass} />
        </div>
        <div className="filterBlank" onClick={this.filterClick}>
          <p>筛选</p><Icon type="filter" />
        </div>
        {typeMenuShow ? custTypeMenu : null}
        {levMenuShow ? custLevMenu : null}
      </div>
    );
  }
}
