/**
 * @file customer/DetailHeader.js
 * @author xuxiaoqin
 */

import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import classnames from 'classnames';
import _ from 'lodash';
import './detailHeader.less';
import Icon from '../common/Icon';
// import AccountFilter from './AccountFilter';

export default class CustomerDetailHeader extends PureComponent {

  static propTypes = {
    // 基本信息数据
    data: PropTypes.object.isRequired,
    push: PropTypes.func,
    // 客户类型
    custSor: PropTypes.string.isRequired,
    // 经济客户号
    custNumber: PropTypes.string.isRequired,
    // 客户号
    custId: PropTypes.string.isRequired,
  }

  static defaultProps = {
    push: () => { },
    data: {},
    custSor: '',
    custNumber: '',
    custId: '',
  }

  // filterTotalAsset(assetData) {
  //   let tempData = '0元';
  //   if (assetData && assetData.toString().indexOf('.') !== -1) {
  //     // 小数
  //     const temp = assetData.toString().split('.');
  //     if (temp[0].length >= 1 && temp[0].length <= 3) {
  //       tempData = `${Number.parseFloat(assetData).toFixed(1)}元`;
  //     } else if (temp[0].length > 3 && temp[0].length < 9) {
  //       tempData = `${(Number.parseFloat(temp[0]) / 10000).toFixed(1)}万元`;
  //     } else if (temp[0].length > 8) {
  //       tempData = `${(Number.parseFloat(temp[0]) / 100000000).toFixed(1)}亿元`;
  //     }
  //   } else if (assetData && assetData.toString().length >= 0
  //     && assetData.toString().length <= 3) {
  //     tempData = `${assetData}元`;
  //   } else if (assetData !== null && assetData.toString().length > 3
  //     && assetData.toString().length < 9) {
  //     tempData = `${(assetData / 10000).toFixed(1)}万元`;
  //   } else if (assetData !== null && assetData.toString().length >= 9) {
  //     tempData = `${(assetData / 100000000).toFixed(1)}亿元`;
  //   }

  //   return tempData;
  // }

  /**
   * 跳转基本信息页面
   */
  @autobind
  handleClick() {
    const { push, custId, custNumber, custSor } = this.props;
    push({
      pathname: '/customer/custBasic',
      query: {
        custId,
        custNumber,
        custSor,
      },
    });
  }

  filterMoney(assetData) {
    let tempData = '0.0元';
    if (assetData && assetData.toString().indexOf('.') !== -1) {
      // 小数
      const temp = assetData.toString().split('.');
      if (temp[0].length >= 1 && temp[0].length <= 4) {
        tempData = `${Number.parseFloat(assetData).toFixed(1)}元`;
      } else if (temp[0].length > 4 && temp[0].length < 9) {
        tempData = `${(Number.parseFloat(temp[0]) / 10000).toFixed(1)}万元`;
      } else if (temp[0].length >= 9) {
        tempData = `${(Number.parseFloat(temp[0]) / 100000000).toFixed(1)}亿元`;
      }
    } else if (assetData && assetData.toString().length >= 1
      && assetData.toString().length <= 4) {
      tempData = `${assetData.toFixed(1)}元`;
    } else if (assetData && assetData.toString().length > 4
      && assetData.toString().length < 9) {
      tempData = `${(assetData / 10000).toFixed(1)}万元`;
    } else if (assetData && assetData.toString().length >= 9) {
      tempData = `${(assetData / 100000000).toFixed(1)}亿元`;
    }

    return tempData;
  }

  filterDataSource({ dataSource, custId, custSor }) {
    let detailData = {};
    if (!_.isEmpty(dataSource)) {
      if (custSor === 'per') {
        /** 个人客户 */
        detailData = {
          custGender: dataSource.gender || '- -',
          custAge: dataSource.age || '- -',
          custGrade: dataSource.custGrade || '- -',
          custType: 'per',
          custName: dataSource.custName ? `${dataSource.custName.slice(0, 1)}**` : '- -',
          custId: custId || '- -',
          custTotalAsset: dataSource.totAsset,
          econNum: dataSource.econNum || '',
          industry: '',
          acctType: '',
        };
      } else if (custSor === 'org' || custSor === 'prod') {
        /** 机构客户 */
        detailData = {
          /** 所属行业 */
          industry: dataSource.industry || '- -',
          /** 机构类型 */
          acctType: dataSource.acctType || '- -',
          custGrade: dataSource.custGrade || '- -',
          custType: 'org',
          custName: dataSource.custName ? `${dataSource.custName.slice(0, 1)}**公司` : '- -',
          custId: custId || '- -',
          custTotalAsset: dataSource.totAsset,
          econNum: dataSource.econNum || '',
          custAge: '',
          custGender: '',
        };
      }
    }

    return detailData;
  }

  render() {
    const { data: dataSource = {}, custId, custSor } = this.props;

    const more = {
      className: 'more',
      type: 'more',
    };

    if (_.isEmpty(dataSource)) {
      return (
        <div className="detailHeaderSection" onClick={this.handleClick}>
          <div className="basic">
            <div className="headerLeft">
              <i className="perCustIconSection" />
              <div className="nameSection">
                <span className="custName">--</span>
                <div className="gradeIdSection">
                  <span className="custId">--</span>
                </div>
              </div>
            </div>
            <div className="asset">
              <i className="emptyCard" />
              <span className="sex">--</span>
              <span className="split">/</span>
              <span className="age">--</span>
              <Icon {...more} />
            </div>
          </div>
          <div className="basicSplit" />
          <div className="totalAssetSection">
            <div className="assetName">总资产</div>
            <div className="assetValue">
              <span>--</span>
            </div>
          </div>
        </div>
      );
    }

    const filteredData = this.filterDataSource({ dataSource, custId, custSor });

    let custTotalAssetHtml = '--';
    if (filteredData.custTotalAsset) {
      custTotalAssetHtml = this.filterMoney(filteredData.custTotalAsset * 10000);
    }

    const grade = classnames({
      emptyCard: !_.isEmpty(filteredData.custGrade) && filteredData.custGrade.toString().indexOf('空') !== -1,
      goldCard: !_.isEmpty(filteredData.custGrade) && filteredData.custGrade.toString().indexOf('金') !== -1,
      silverCard: !_.isEmpty(filteredData.custGrade) && filteredData.custGrade.toString().indexOf('银') !== -1,
      diamondCard: !_.isEmpty(filteredData.custGrade) && filteredData.custGrade.toString().indexOf('钻石') !== -1,
      financeCard: !_.isEmpty(filteredData.custGrade) && filteredData.custGrade.toString().indexOf('理财') !== -1,
      whiteGoldCard: !_.isEmpty(filteredData.custGrade) && filteredData.custGrade.toString().indexOf('白金') !== -1,
    });

    if (filteredData.custType === 'per') {
      return (
        <div className="detailHeaderSection" onClick={this.handleClick}>
          <div className="basic">
            <div className="headerLeft">
              <i className={filteredData.custType} />
              <div className="nameSection">
                <div className="">
                  <span className="custName">{filteredData.custName}</span>
                  <i className={grade} />
                </div>
                <div className="gradeIdSection">
                  <span className="sex">{filteredData.custGender}</span>
                  <span className="age">{filteredData.custAge}岁</span>
                  <span className="custId">{filteredData.econNum}</span>
                </div>
              </div>
            </div>
            <div className="asset">
              <Icon {...more} onClick={this.handleClick} />
            </div>
          </div>
          <div className="basicSplit" />
          <div className="totalAssetSection">
            <div className="assetName">总资产</div>
            <div className="assetValue">
              <span>{(custTotalAssetHtml && custTotalAssetHtml !== '--'
                && custTotalAssetHtml.replace(/[元万亿]/g, '')) || '--'}
              </span>
              <span>{(custTotalAssetHtml && custTotalAssetHtml !== '--'
                && custTotalAssetHtml
                  .slice(custTotalAssetHtml.replace(/[元万亿]/g, '').length,
                  custTotalAssetHtml.length)) || ''}
              </span>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="detailHeaderSection" onClick={this.handleClick}>
        <div className="basic">
          <div className="headerLeft">
            <i className={filteredData.custType} />
            <div className="nameSection">
              <div className="">
                <span className="custName">{filteredData.custName}</span>
                <i className={grade} />
              </div>
              <div className="gradeIdSection">
                <span className="age">{filteredData.industry}</span>
                <span className="custId">{filteredData.econNum}</span>
              </div>
            </div>
          </div>
          <div className="asset">
            <Icon {...more} onClick={this.handleClick} />
          </div>
        </div>
        <div className="basicSplit" />
        <div className="totalAssetSection">
          <div className="assetName">总资产</div>
          <div className="assetValue">
            <span>{(custTotalAssetHtml && custTotalAssetHtml !== '--'
              && custTotalAssetHtml.replace(/[元万亿]/g, '')) || '--'}
            </span>
            <span>{(custTotalAssetHtml && custTotalAssetHtml !== '--'
              && custTotalAssetHtml
                .slice(custTotalAssetHtml.replace(/[元万亿]/g, '').length,
                custTotalAssetHtml.length)) || ''}
            </span>
          </div>
        </div>
      </div>
    );
  }
}
