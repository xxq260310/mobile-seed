/**
 * @file customer/List.js
 * @author fengwencong
 */
import React, { PropTypes, PureComponent } from 'react';
import ReactDOM from 'react-dom';
import { autobind } from 'core-decorators';
import { RefreshControl, ListView } from 'antd-mobile';
import _ from 'lodash';

import { prepareDataSource } from '../../utils/listView';
import { renderIcon, renderLoading, distanceToRefresh } from '../../components/common/PullToRefreshable';
import ListItem from './ListItem';
import Message from '../message';
import cordova from '../../utils/cordova';
import helper from '../../utils/helper';
import { constants } from '../../config';
import { checkListPTR } from '../../decorators/checkNetwork';
import { checkErrData } from '../../decorators/checkErrorData';

import './list.less';

const EMPTY_LIST = [];

export default class CustomerList extends PureComponent {

  static propTypes = {
    list: PropTypes.object.isRequired,
    getList: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    replace: PropTypes.func.isRequired,
    pageNum: PropTypes.number,
    push: PropTypes.func.isRequired,
    isFetching: PropTypes.bool.isRequired,
    reportRefresh: PropTypes.func.isRequired,
  }

  static defaultProps = {
    pageNum: 1,
  }

  constructor(props) {
    super(props);

    const { resultList = EMPTY_LIST } = props.list;
    const { location: { query } } = this.props;

    this.state = {
      dataSource: prepareDataSource(resultList, true),
      isLoading: false,
      isRefreshing: false,
      isLoaded: false,
      orderType: query.orderType ? query.orderType : 'desc',
      typeClass: query.custNature ? 'sel' : 'all',
      levClass: query.custLevel ? 'sel' : 'all',
      messageHeight: 0,
    };
  }

  componentDidMount() {
    this.setHeight();
    this.setMessageHeight();
  }

  @checkErrData({ loadingName: 'isRefreshing' })
  componentWillReceiveProps(nextProps) {
    const { list: { page, resultList } } = nextProps;
    const { list: preList } = this.props;
    const { page: prePage, resultList: preResultList } = preList;
    if (nextProps.list !== this.props.list) {
      let stateMap = {
        isLoading: false,
      };
      let needUpdateDatasource = true;
      // 刷新没数据的时候不要更新数据源
      // 否则会导致循环刷新
      if (page.curPageNum === 1) {
        // 只判断第一项就行，避免大数据判断引起的性能问题
        if (_.isEqual(page, prePage) && _.isEqual(resultList[0], preResultList[0])) {
          needUpdateDatasource = false;
        }
      }
      if (needUpdateDatasource) {
        stateMap = {
          ...stateMap,
          dataSource: prepareDataSource(resultList, true),
        };
      }
      this.setState(stateMap);
    }
  }

  componentDidUpdate() {
    this.setHeight();
    this.setMessageHeight();
  }

  @autobind
  onEndReached() {
    const { isLoading } = this.state;
    const { list: { page } } = this.props;
    if (!isLoading
      && (page.curPageNum < page.totalPageNum)
      && cordova.isConnected()
    ) {
      this.setState(
        { isLoading: true },
        this.refreshMore,
      );
    }
  }

  @autobind
  @checkListPTR()
  onRefresh() {
    const { location: { query }, getList, reportRefresh } = this.props;
    getList({
      ...query,
      pageNum: 1,
    });
    reportRefresh({
      actionSource: '客户列表',
    });
  }

  setHeight() {
    // 更新列表高度
    if (this.listElem) {
      const listElem = ReactDOM.findDOMNode(this.listElem); // eslint-disable-line
      const header = document.querySelector('.listHeader');
      const height = header ? helper.getAvailableHeight({
        el: ['.listHeader', '.fixed-header'],
      }) : helper.getAvailableHeight();
      listElem.style.height = `${height}px`;
      const marginTop = document.querySelector('.listHeader').offsetHeight + document.querySelector('.fixed-header').offsetHeight;
      listElem.style.marginTop = `${marginTop}px`;
    }
  }

  setMessageHeight() {
    this.setState({
      messageHeight: helper.getAvailableHeight({ el: ['.am-list-body', '.am-tab-bar-bar'] }),
    });
  }

  @autobind
  getIconClass() {
    const { orderType } = this.state;
    if (orderType === 'desc') {
      return '';
    }
    return 'sortUp';
  }

  @autobind
  getTypeClass() {
    const { typeClass } = this.state;
    return typeClass === 'all' ? 'cusType' : 'cusTypeSel';
  }

  @autobind
  getLevClass() {
    const { levClass } = this.state;
    return levClass === 'all' ? 'cusLev' : 'cusLevSel';
  }

  scrollTo(y) {
    if (this.listElem) {
      this.listElem.refs.listview.scrollTo(0, y);
    }
  }

  @autobind
  handleLevChange(val) {
    const { replace, location: { query } } = this.props;
    replace({
      pathname: '/customer',
      query: {
        ...query,
        custLevel: val === 'all' ? '' : val,
      },
    });
    this.setState({
      levClass: val === 'all' ? 'all' : 'sel',
    });
  }

  @autobind
  handleTypeChange(val) {
    const { replace, location: { query } } = this.props;
    replace({
      pathname: '/customer',
      query: {
        ...query,
        custNature: val === 'all' ? '' : val,
      },
    });
    this.setState({
      typeClass: val === 'all' ? 'all' : 'sel',
    });
  }

  @autobind
  handleSortChange() {
    const { replace, location: { query } } = this.props;
    const { orderType } = this.state;
    let newSort = '';
    if (orderType === 'desc') {
      this.setState({
        orderType: 'asc',
      });
      newSort = 'asc';
    } else {
      this.setState({
        orderType: 'desc',
      });
      newSort = 'desc';
    }
    replace({
      pathname: '/customer',
      query: {
        ...query,
        orderType: newSort,
      },
    });
  }

  @autobind
  refreshMore() {
    const { getList, list: { page }, location: { query } } = this.props;
    getList({
      ...query,
      pageNum: page.curPageNum + 1,
    });
  }

  @autobind
  renderRow(rowData, sectionID, rowID) {
    if (_.isEmpty(rowData)) {
      return null;
    }
    const { push } = this.props;
    return (
      <ListItem
        key={`${sectionID}-${rowID}`}
        {...rowData}
        push={push}
      />
    );
  }

  @autobind
  renderSeparator(sectionID, rowID) {
    let el = '';
    const { list: { resultList } } = this.props;
    if (resultList.length !== 0) {
      el = (
        <div
          key={`${sectionID}-${rowID}`}
          className="list-separator"
        />
      );
    }
    return el;
  }

  @autobind
  renderFooter() {
    const { isLoading, isLoaded, messageHeight } = this.state;
    const { list: { page, resultList } } = this.props;
    let text = '';
    let messageType = '';
    if (!cordova.isConnected() && resultList.length === 0) {
      messageType = 'network';
    } else if (resultList.length === 0 && isLoaded) {
      messageType = 'notfound';
    } else if (isLoading) {
      text = '加载中...';
    } else if (page.curPageNum > 1) {
      if (page.curPageNum === page.totalPageNum) {
        text = '已经到底了';
      } else {
        text = '上拉加载更多';
      }
    }
    if (messageType) {
      return (
        <Message
          type={messageType}
          height={messageHeight}
        />
      );
    }
    return (
      <div>
        {text}
      </div>
    );
  }

  render() {
    const { dataSource, isRefreshing } = this.state;
    return (
      <ListView
        className="customer-list"
        ref={ref => (this.listElem = ref)}
        dataSource={dataSource}
        renderFooter={this.renderFooter}
        renderRow={this.renderRow}
        renderSeparator={this.renderSeparator}
        pageSize={10}
        initialListSize={constants.initialListSize}
        scrollRenderAheadDistance={500}
        scrollEventThrottle={20}
        onEndReached={this.onEndReached}
        onEndReachedThreshold={10}
        refreshControl={<RefreshControl
          refreshing={isRefreshing}
          onRefresh={this.onRefresh}
          distanceToRefresh={distanceToRefresh}
          icon={renderIcon()}
          loading={renderLoading()}
        />}
      />
    );
  }
}
