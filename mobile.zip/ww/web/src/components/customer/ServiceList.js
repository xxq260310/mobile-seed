/**
 * @file customer/ServiceList.js
 * @author xuxiaoqin
 */
import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import { RefreshControl, ListView } from 'antd-mobile';

import { renderIcon, renderLoading, distanceToRefresh } from '../common/PullToRefreshable';
import cordova from '../../utils/cordova';
import { prepareDataSource } from '../../utils/listView';
import helper from '../../utils/helper';
import ServiceListItem from './ServiceListItem';
import Message from '../message';
import { checkErrData } from '../../decorators/checkErrorData';
import './serviceList.less';

export default class ServiceList extends PureComponent {

  static propTypes = {
    list: PropTypes.array,
    pageNum: PropTypes.number,
    hasMore: PropTypes.bool,
    custId: PropTypes.string.isRequired,
    isFetching: PropTypes.bool.isRequired,
    refresh: PropTypes.func.isRequired,
    push: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    reportRefresh: PropTypes.func.isRequired,
  }

  static defaultProps = {
    hasMore: null,
    pageNum: 1,
    list: [],
  }

  constructor(props) {
    super(props);
    const { list } = props;
    this.state = {
      dataSource: prepareDataSource(list),
      isLoading: false,
      isLoaded: false,
      messageHeight: 0,
    };
  }

  componentDidMount() {
    this.setMessageHeight();
  }

  @checkErrData()
  componentWillReceiveProps(nextProps) {
    const { list } = nextProps;
    if (list !== this.props.list) {
      this.setState({
        dataSource: prepareDataSource(list),
      });
    }
  }

  componentDidUpdate() {
    this.setMessageHeight();
  }

  @autobind
  onRefresh() {
    const { custId, refresh, reportRefresh } = this.props;
    const { isLoading } = this.state;
    if (!isLoading) {
      this.setState(
        { isLoading: true },
        () => {
          if (!cordova.isConnected()) {
            setTimeout(
              () => {
                this.setState({ isLoading: false });
              },
              1000,
            );
            return;
          }
          refresh({ custId });
        },
      );
    }
    reportRefresh({
      actionSource: '服务记录',
    });
  }

  @autobind
  onEndReached() {
    const { isLoading } = this.state;
    const { hasMore, refresh, custId, pageNum, list } = this.props;
    // 每页10条，确定前一页大于等于10条时，再请求下一页
    if (
      !isLoading &&
      list.length >= 10 &&
      hasMore &&
      cordova.isConnected()
    ) {
      this.setState(
        { isLoading: true },
        () => {
          refresh({
            custId,
            pageNum: pageNum + 1,
          });
        },
      );
    }
  }

  setMessageHeight() {
    this.setState({
      messageHeight: helper.getAvailableHeight(),
    });
  }

  renderSeparator(sectionID, rowID) {
    return (
      <div
        key={`${sectionID}-${rowID}`}
        className="list-separator"
      />
    );
  }

  @autobind
  renderRow(rowData, sectionID, rowID) {
    const { push, custId } = this.props;
    return (
      <ServiceListItem
        key={`${sectionID}-${rowID}`}
        data={{ ...rowData, custId, rowID, sectionID }}
        push={push}
      />
    );
  }

  @autobind
  renderFooter() {
    const { isLoading, isLoaded, messageHeight } = this.state;
    const { pageNum, hasMore, list } = this.props;
    let text = '';
    let messageType = '';
    if (!cordova.isConnected() && list.length === 0) {
      messageType = 'network';
    } else if (list.length === 0 && isLoaded) {
      messageType = 'notfound';
    } else if (isLoading && pageNum !== 1) {
      text = '加载中...';
    } else if (pageNum > 1) {
      if (!hasMore) {
        text = '已经到底了';
      } else {
        text = '上拉加载更多';
      }
    }
    if (messageType) {
      return (
        <Message
          type={messageType}
          height={messageHeight}
        />
      );
    }
    return (
      <div>
        {text}
      </div>
    );
  }

  render() {
    const { dataSource, isLoading } = this.state;
    if (!dataSource) {
      return null;
    }
    return (
      <div className="service-record">
        <ListView
          className="service-list"
          dataSource={dataSource}
          renderRow={this.renderRow}
          renderSeparator={this.renderSeparator}
          renderFooter={this.renderFooter}
          onEndReached={this.onEndReached}
          pageSize={10}
          scrollEventThrottle={20}
          scrollRenderAheadDistance={400}
          style={{ height: helper.getAvailableHeight() }}
          refreshControl={<RefreshControl
            refreshing={isLoading}
            onRefresh={this.onRefresh}
            distanceToRefresh={distanceToRefresh}
            icon={renderIcon()}
            loading={renderLoading()}
          />}
        />
      </div>
    );
  }
}
