/**
 * @file customer/EditPersonalContact.js
 * @author xuxiaoqin
 */

import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import { SwipeAction, Toast, Radio } from 'antd-mobile';
import _ from 'lodash';
import classnames from 'classnames';
import { checkFormate as checkFormat, disableMultiTouch } from '../../utils/helper';
import Icon from '../../components/common/Icon';
import './editPersonalContact.less';
import { localConst } from '../../config';

// const Item = List.Item;
// const RadioItem = Radio.RadioItem;

// {
//   "custNumber":"02022399", //客户号 必传
//     "custSor":"per", //客户类型 必传
//       "homeAddresses": [
//         {
//           "mainFlag": false, //是否主要
//           "validFlag": true, //是否合法，默认true，如果删除则把这个字段职位false即可
//           "contactType": "117112",
//           "nation": "中国",
//           "nationCd": "111156",
//           "province": null,
//           "provinceCd": "",
//           "city": null,
//           "cityCd": "",
//           "address": "南JSGJQ48 14896986Gt17",
//           "zip": "210092",
//           "rowId": "ADDRI-20121124-00028755748" //如果是修改必传，新增不传
//         }
//       ]
// }

const more = {
  className: 'more',
  type: 'more',
};

const addIcon = {
  className: 'addIcon',
  type: 'weibiaoti--',
};
const ADDRESS_TYPE_MAP = localConst.ADDRESS_TYPE_MAP;

const ADDRESS_TYPE = _.values(ADDRESS_TYPE_MAP);

const TEL_TYPE_MAP = localConst.TEL_TYPE_MAP;

const COMMON_TYPE_MAP = localConst.COMMON_TYPE_MAP;

const COMMON_TITLE_MAP = localConst.COMMON_TITLE_MAP;

const EMPTY_LIST = [];

export default class EditPersonalContact extends PureComponent {

  static propTypes = {
    data: PropTypes.object,
    push: PropTypes.func.isRequired,
    type: PropTypes.string.isRequired,
    location: PropTypes.object.isRequired,
    addOrUpdateContactPer: PropTypes.func.isRequired,
    go: PropTypes.func.isRequired,
    goBack: PropTypes.func.isRequired,
    goBackCount: PropTypes.number,
    updateGoBackLevel: PropTypes.func.isRequired,
    storeSaveData: PropTypes.func.isRequired,
  }

  static defaultProps = {
    push: () => { },
    data: {},
    goBackCount: 1,
  }

  constructor(props) {
    super(props);

    this.state = {
      isLoading: false,
      radioValue: '',
      isAddressChecked: false,
      dataSource: props.data,
      addressRadioValueArray: [],
    };

    // 设置主要初始化
    const { data, location: { query: { type } } } = this.props;
    if (type === 'tel') {
      if (data.cellPhones && data.cellPhones.length > 0) {
        data.cellPhones.map((i) => {
          if (i.mainFlag) {
            this.state = { ...this.state, radioValue: i.contactValue };
          }
          return true;
        });
      }
    } else if (type === 'email') {
      if (data.emailAddresses && data.emailAddresses.length > 0) {
        data.emailAddresses.map((i) => {
          if (i.mainFlag) {
            this.state = { ...this.state, radioValue: i.contactValue };
          }
          return true;
        });
      }
    } else if (type === 'address') {
      const len = Object.keys(ADDRESS_TYPE_MAP).length;
      const tempArray = [];
      for (let i = 0; i < len; i++) {
        if (data[ADDRESS_TYPE[i]]) {
          const handleData = data[ADDRESS_TYPE[i]];
          if (!_.isArray(handleData)) {
            if (handleData.mainFlag) {
              tempArray.push(
                {
                  rowId: handleData.rowId,
                  selectValue: `${handleData.province || ''}${handleData.city || ''}${handleData.address || ''}`,
                });
            }
          } else {
            handleData.map((j) => {
              if (j.mainFlag) {
                tempArray.push({
                  rowId: j.rowId,
                  selectValue: `${j.province || ''}${j.city || ''}${j.address || ''}`,
                });
              }
              return true;
            });
          }
        }
      }
      // 初始化radio状态集合
      this.state = {
        ...this.state,
        addressRadioValueArray: tempArray,
      };
    }
  }

  componentDidMount() {
    document.addEventListener('touchstart', disableMultiTouch, false);
    document.addEventListener('touchmove', disableMultiTouch, false);
  }

  componentWillReceiveProps(nextProps) {
    const { data: newData } = nextProps;
    const { data: prevData, location: { query: { type } } } = this.props;
    if (prevData !== newData) {
      this.setState({
        dataSource: newData,
      });
      // 设置主要更新
      if (type === 'tel') {
        if (newData.cellPhones && newData.cellPhones.length > 0) {
          newData.cellPhones.map((i) => {
            if (i.mainFlag) {
              this.setState({ radioValue: i.contactValue });
            }
            return true;
          });
        }
      } else if (type === 'email') {
        if (newData.emailAddresses && newData.emailAddresses.length > 0) {
          newData.emailAddresses.map((i) => {
            if (i.mainFlag) {
              this.setState({ radioValue: i.contactValue });
            }
            return true;
          });
        }
      } else if (type === 'address') {
        const len = Object.keys(ADDRESS_TYPE_MAP).length;
        const tempArray = [];
        for (let k = 0; k < len; k++) {
          const handleData = newData[ADDRESS_TYPE[k]];
          if (handleData) {
            if (!_.isArray(handleData)) {
              if (handleData.mainFlag) {
                tempArray.push(
                  {
                    rowId: handleData.rowId,
                    selectValue: `${handleData.province || ''}${handleData.city || ''}${handleData.address || ''}`,
                  });
              }
            } else {
              handleData.map((m) => {
                if (m && m.mainFlag) {
                  tempArray.push({
                    rowId: m.rowId,
                    selectValue: `${m.province || ''}${m.city || ''}${m.address || ''}`,
                  });
                }
                return true;
              });
            }
          }
        }
        // 更新radio选中状态集合
        this.setState({
          addressRadioValueArray: tempArray,
        });
      }
    }
  }

  componentWillUnmount() {
    document.removeEventListener('touchstart', disableMultiTouch, false);
    document.removeEventListener('touchmove', disableMultiTouch, false);
  }

  @autobind
  onRadioChange(value, rowId, typeName) {
    const { addOrUpdateContactPer,
      location: { query: { type, custId, custNumber, custSor } } } = this.props;
    const { dataSource, radioValue } = this.state;
    let postBody = {
      custId,
      custNumber,
      custSor,
    };
    if (radioValue !== value) {
      if (type === 'tel') {
        dataSource.cellPhones.map((i) => {
          if (i.rowId === rowId) {
            const newData = {
              ...i,
              rowId,
              mainFlag: true,
            };
            postBody = {
              ...postBody,
              [TEL_TYPE_MAP[typeName]]: [newData],
            };
            addOrUpdateContactPer(postBody);
          }
          return true;
        });
      } else if (type === 'email') {
        dataSource.emailAddresses.map((i) => {
          if (i.rowId === rowId) {
            const newData = {
              ...i,
              rowId,
              mainFlag: true,
            };
            postBody = {
              ...postBody,
              [COMMON_TYPE_MAP[type]]: [newData],
            };
            addOrUpdateContactPer(postBody);
          }
          return true;
        });
      }
    }

    // 只有后台成功之后，才将页面上的radio置换
    // this.setState({
    //   radioValue: value,
    // });
  }

  @autobind
  onAddressRadioChange(rowId, typeName) {
    const { addOrUpdateContactPer,
      location: { query: { type, custId, custNumber, custSor } } } = this.props;
    const { dataSource, addressRadioValueArray } = this.state;
    let postBody = {
      custId,
      custNumber,
      custSor,
    };

    if (type === 'address') {
      const oldData = dataSource[ADDRESS_TYPE_MAP[typeName]];
      if (!_.isArray(oldData)) {
        // 身份证地址
        if (addressRadioValueArray.length < 1) {
          // 不存在，则直接设置为true
          const newData = {
            ...oldData,
            rowId,
            mainFlag: true,
          };
          postBody = {
            ...postBody,
            [ADDRESS_TYPE_MAP[typeName]]: newData,
          };
          addOrUpdateContactPer(postBody);

          this.setState({
            addressRadioValueArray: {
              rowId,
              selectValue: `${oldData.province || ''}${oldData.city || ''}${oldData.address || ''}`,
            },
          });
        } else {
          // 存在，但是不是那一条，才设置为true，不然不发起请求
          addressRadioValueArray.map((j) => {
            if (j.rowId !== oldData.rowId) {
              const newData = {
                ...oldData,
                rowId,
                mainFlag: true,
              };
              postBody = {
                ...postBody,
                [ADDRESS_TYPE_MAP[typeName]]: newData,
              };
              addOrUpdateContactPer(postBody);
              const newAddressRadioValueArray = [
                ...addressRadioValueArray,
                {
                  rowId,
                  selectValue: `${oldData.province || ''}${oldData.city || ''}${oldData.address || ''}`,
                },
              ];
              this.setState({
                addressRadioValueArray: newAddressRadioValueArray,
              });
            }
            return true;
          });
        }
      } else {
        oldData.map((i) => {
          if (i.rowId === rowId) {
            if (addressRadioValueArray.length < 1) {
              // 不存在，则直接设置为true
              const newData = {
                ...i,
                rowId,
                mainFlag: true,
              };
              postBody = {
                ...postBody,
                [ADDRESS_TYPE_MAP[typeName]]: [newData],
              };
              addOrUpdateContactPer(postBody);
              this.setState({
                addressRadioValueArray: {
                  rowId,
                  selectValue: `${i.province || ''}${i.city || ''}${i.address || ''}`,
                },
              });
            } else {
              // 存在，但是不是那一条，才设置为true，不然不发起请求
              addressRadioValueArray.map((j) => {
                if (j.rowId !== i.rowId) {
                  const newData = {
                    ...i,
                    rowId,
                    mainFlag: true,
                  };
                  postBody = {
                    ...postBody,
                    [ADDRESS_TYPE_MAP[typeName]]: [newData],
                  };
                  addOrUpdateContactPer(postBody);
                  const newAddressRadioValueArray = [
                    ...addressRadioValueArray,
                    {
                      rowId,
                      selectValue: `${i.province || ''}${i.city || ''}${i.address || ''}`,
                    },
                  ];
                  this.setState({
                    addressRadioValueArray: newAddressRadioValueArray,
                  });
                }
                return true;
              });
            }
          }
          return true;
        });
      }
    }
  }

  @autobind
  checkIsExistIdAddress(addressType) {
    const { dataSource } = this.state;
    if (dataSource[ADDRESS_TYPE_MAP[addressType]]
      && !_.isArray(dataSource[ADDRESS_TYPE_MAP[addressType]])) {
      // 存在身份证地址
      return true;
    }
    return false;
  }

  @autobind
  handleDeleteClick(rowId, editType) {
    const { addOrUpdateContactPer,
      location: { query: { custId, custNumber, custSor, type } } } = this.props;
    const { dataSource } = this.state;
    let postBody = {
      custId,
      custNumber,
      custSor,
    };
    if (type === 'address') {
      const deleteAddressType = ADDRESS_TYPE_MAP[editType];
      const addressData = dataSource[deleteAddressType];
      if (!_.isArray(addressData)) {
        // 删除身份证地址
        const newData = addressData;
        newData.validFlag = false;
        postBody = {
          ...postBody,
          [deleteAddressType]: newData,
        };
        addOrUpdateContactPer(postBody);
      } else {
        // 删除其他类型地址
        addressData.map((i) => {
          if (i.rowId === rowId) {
            const newData = i;
            newData.validFlag = false;
            postBody = {
              ...postBody,
              [deleteAddressType]: [newData],
            };
            addOrUpdateContactPer(postBody);
          }
          return true;
        });
      }
    } else if (type === 'tel' || type === 'email' || type === 'qq' || type === 'wechat') {
      let deleteType = '';
      switch (type) {
        case 'tel':
          deleteType = TEL_TYPE_MAP[editType];
          break;
        case 'email':
          deleteType = COMMON_TYPE_MAP[type];
          break;
        case 'qq':
          deleteType = COMMON_TYPE_MAP[type];
          break;
        case 'wechat':
          deleteType = COMMON_TYPE_MAP[type];
          break;
        default:
          deleteType = '';
      }
      const deleteData = dataSource[deleteType];
      deleteData.map((i) => {
        if (i.rowId === rowId) {
          const deleteObject = i;
          deleteObject.validFlag = false;
          postBody = {
            ...postBody,
            [deleteType]: [deleteObject],
          };
          addOrUpdateContactPer(postBody);
        }
        return true;
      });
    }
  }

  @autobind
  handleMoreClick(typeName = '', contactValue = '', rowId = '', province, city, cityCd, provinceCd) {
    const { push, location: { query: { type, custId, custNumber, custSor } },
      storeSaveData } = this.props;
    if (type === 'tel') {
      push({
        pathname: '/customer/editPerContactDetail',
        query: {
          type,
          custId,
          custNumber,
          custSor,
          originType: typeName,
          telType: typeName,
          telValue: contactValue,
          rowId,
        },
        state: {
          onSavePerContact: (newData) => {
            this.saveEditInfo(newData);
          },
        },
      });
      // 存储saveFunction
      // goBack会丢失state里面的数据
      storeSaveData({
        onSavePerContact: (newData) => {
          this.saveEditInfo(newData);
        },
      });
    } else if (type === 'address') {
      push({
        pathname: '/customer/editPerContactDetail',
        query: {
          type,
          custId,
          custNumber,
          custSor,
          originType: typeName,
          addressType: typeName,
          addressValue: contactValue,
          rowId,
          province,
          provinceCd,
          city,
          cityCd,
        },
        state: {
          onSavePerContact: (newData) => {
            this.saveEditInfo(newData);
          },
        },
      });
      // 存储saveFunction
      // goBack会丢失state里面的数据
      storeSaveData({
        onSavePerContact: (newData) => {
          this.saveEditInfo(newData);
        },
      });
    } else if (type === 'email' || type === 'qq' || type === 'wechat') {
      const title = `编辑${COMMON_TITLE_MAP[type]}`;
      const defaultValue = contactValue;
      const isAdd = 'N';
      push({
        pathname: '/common',
        query: {
          type,
          title: encodeURIComponent(title),
          defaultValue: encodeURIComponent(defaultValue),
        },
        state: {
          onSave: (value) => {
            this.saveCommonInfo({
              value,
              rowId,
              originValue: defaultValue,
              isAdd,
              type,
            });
          },
        },
      });
    }
  }

  @autobind
  saveCommonInfo(newData) {
    const { addOrUpdateContactPer,
      location: { query: { custId, custNumber, custSor } },
      goBackCount, goBack, go, updateGoBackLevel } = this.props;
    const { value, isAdd, rowId, type } = newData;
    const { isEmail } = checkFormat;
    if (type === 'email') {
      if (value) {
        if (value.indexOf(' ') !== -1 || !isEmail(value)) {
          Toast.info('邮箱格式错误', 1);
          return false;
        } else if (value.length > 50) {
          Toast.info('邮箱限制在50个字符内', 1);
          return false;
        }
      }
    }

    if (type === 'qq') {
      if (value && value.length > 50) {
        Toast.info('QQ限制在50个字符内', 1);
        return false;
      }
    }

    let postBody = {
      custId,
      custNumber,
      custSor,
    };
    if (isAdd === 'Y') {
      postBody = {
        ...postBody,
        [COMMON_TYPE_MAP[type]]: [{
          mainFlag: false,
          contactValue: value,
          validFlag: true,
        }],
      };
      addOrUpdateContactPer(postBody);
    } else if (isAdd === 'N') {
      const { dataSource } = this.state;
      const oldEditData = dataSource[COMMON_TYPE_MAP[type]] || EMPTY_LIST;
      oldEditData.map((i) => {
        if (i.rowId === rowId) {
          const newEditData = {
            mainFlag: i.mainFlag,
            contactValue: value,
            validFlag: true,
            rowId,
          };
          postBody = {
            ...postBody,
            [COMMON_TYPE_MAP[type]]: [newEditData],
          };
          addOrUpdateContactPer(postBody);
        }
        return true;
      });
    }

    if (goBackCount === 1) {
      goBack();
    } else {
      go(-goBackCount);
      // 恢复返回级数
      updateGoBackLevel({ count: 1 });
    }

    return true;
  }

  @autobind
  handleAddClick() {
    const { push, location: { query: { type, custId, custNumber, custSor } },
      storeSaveData } = this.props;
    const queryString = {
      type, custId, custNumber, custSor, isAdd: 'Y',
    };

    if (type === 'tel' || type === 'address') {
      push({
        pathname: '/customer/editPerContactDetail',
        query: queryString,
        state: {
          onSavePerContact: (newData) => {
            this.saveEditInfo(newData);
          },
        },
      });
      // 存储saveFunction
      // goBack会丢失state里面的数据
      storeSaveData({
        onSavePerContact: (newData) => {
          this.saveEditInfo(newData);
        },
      });
    } else if (type === 'email' || type === 'qq' || type === 'wechat') {
      const title = `编辑${COMMON_TITLE_MAP[type]}`;
      const defaultValue = '';
      const isAdd = 'Y';
      push({
        pathname: '/common',
        query: {
          type,
          title: encodeURIComponent(title),
          defaultValue: encodeURIComponent(defaultValue),
        },
        state: {
          onSave: (value) => {
            this.saveCommonInfo({
              value,
              isAdd,
              type,
            });
          },
        },
      });
    }
  }

  @autobind
  saveEditInfo(newData) {
    const {
      addOrUpdateContactPer,
      go,
      goBack,
      updateGoBackLevel,
     } = this.props;
    const {
      type,
      originType,
      rowId,
      addressType,
      addressValue,
      telType,
      telValue,
      province,
      provinceCd,
      city,
      cityCd,
      isAdd,
      custId,
      custNumber,
      custSor,
      goBackCount,
      mainFlag = false,
     } = newData;

    const { isCellphone, isTelephone } = checkFormat;

    let errorMessage = '';
    if (type === 'tel') {
      if (!telType) {
        errorMessage = '电话类型不能为空';
      } else if (telType === '手机') {
        if (!telValue) {
          errorMessage = '手机号不能为空';
        } else if (!isCellphone(telValue)) {
          errorMessage = '手机号格式错误';
        }
      } else if (!telValue) {
        errorMessage = '电话不能为空';
      } else if (!isTelephone(telValue) && !isCellphone(telValue)) {
        errorMessage = '电话格式错误';
      }
    } else if (type === 'address') {
      if (!addressType && isAdd === 'Y') {
        errorMessage = '地址类型不能为空';
      } else if (!province && !city && isAdd === 'Y') {
        errorMessage = '省市不能为空';
      } else if (!addressValue) {
        errorMessage = '街道信息不能为空';
      }
    }

    if (errorMessage) {
      Toast.info(errorMessage, 1);
      return false;
    }

    const { dataSource } = this.state;

    let oldAddressData = [];
    let newAddressData = [];
    let oldTelData = [];
    let newTelData = [];
    let postBody = {
      custNumber,
      custSor,
      custId,
    };

    if (isAdd === 'Y') {
      if (type === 'address') {
        const editType = ADDRESS_TYPE_MAP[addressType];
        if (editType === 'idAddress') {
          if (!_.isEmpty(dataSource[editType])) {
            Toast.info('身份证地址不能有多个', 1);
            return false;
          }
          // 身份证地址
          newAddressData = {
            address: addressValue,
            city,
            cityCd,
            mainFlag: false,
            province,
            provinceCd,
            validFlag: true,
            nation: '中国',
            nationCd: '111156',
          };
          postBody = {
            ...postBody,
            [editType]: newAddressData,
          };
          addOrUpdateContactPer(postBody);
        } else {
          newAddressData = {
            address: addressValue,
            city,
            cityCd,
            mainFlag: false,
            province,
            provinceCd,
            validFlag: true,
            nation: '中国',
            nationCd: '111156',
          };
          postBody = {
            ...postBody,
            [editType]: [newAddressData],
          };

          addOrUpdateContactPer(postBody);
        }
      } else if (type === 'tel') {
        const editType = TEL_TYPE_MAP[telType];
        // 判断电话类型
        newTelData = {
          validFlag: true,
          contactValue: telValue,
          mainFlag,
        };
        postBody = {
          ...postBody,
          [editType]: [newTelData],
        };
        addOrUpdateContactPer(postBody);
      }
    } else if (isAdd === 'N') {
      if (type === 'address') {
        const editType = ADDRESS_TYPE_MAP[originType];
        const oldEditData = dataSource[editType];
        if (!_.isArray(oldEditData)) {
          // 身份证地址
          if (addressType !== originType) {
            // 直接将旧的地址的rowId拿给新的地址，旧的地址会自动删除，
            // 后台只支持这样
            oldAddressData = oldEditData;
            // oldAddressData.validFlag = false;
            const oldRowId = oldAddressData.rowId;
            const oldMainFlag = oldAddressData.mainFlag;
            newAddressData = {
              address: addressValue,
              city,
              cityCd,
              mainFlag: oldMainFlag,
              province,
              provinceCd,
              validFlag: true,
              nation: '中国',
              nationCd: '111156',
              rowId: oldRowId,
            };
            postBody = {
              ...postBody,
              // [editType]: oldAddressData,
              [ADDRESS_TYPE_MAP[addressType]]: ADDRESS_TYPE_MAP[addressType] === 'idAddress' ?
                newAddressData : [newAddressData],
            };
            addOrUpdateContactPer(postBody);
          } else {
            // 直接修改成新的地址
            let newEditData = oldEditData;
            newEditData = {
              ...oldEditData,
              address: addressValue,
              city,
              cityCd,
              province,
              provinceCd,
              validFlag: true,
              nation: '中国',
              nationCd: '111156',
            };
            postBody = {
              ...postBody,
              [ADDRESS_TYPE_MAP[addressType]]: ADDRESS_TYPE_MAP[addressType] === 'idAddress' ?
                newEditData : [newEditData],
            };
            addOrUpdateContactPer(postBody);
          }
        } else {
          if (this.checkIsExistIdAddress(addressType)) {
            Toast.info('身份证地址不能有多个', 1);
            return false;
          }
          oldEditData.map((i) => {
            if (i.rowId === rowId) {
              // 判断地址类型
              if (addressType !== originType) {
                // // 删掉旧的地址，新增新的地址
                // 直接将旧的地址的rowId拿给新的地址，旧的地址会自动删除，
                // 后台只支持这样
                oldAddressData = i;
                const oldRowId = oldAddressData.rowId;
                const oldMainFlag = oldAddressData.mainFlag;
                newAddressData = {
                  address: addressValue,
                  city,
                  cityCd,
                  mainFlag: oldMainFlag,
                  province,
                  provinceCd,
                  validFlag: true,
                  nation: '中国',
                  nationCd: '111156',
                  rowId: oldRowId,
                };
                postBody = {
                  ...postBody,
                  [ADDRESS_TYPE_MAP[addressType]]: ADDRESS_TYPE_MAP[addressType] === 'idAddress' ?
                    newAddressData : [newAddressData],
                };
              } else {
                // 直接修改成新的地址
                let newEditData = i;
                newEditData = {
                  ...newEditData,
                  address: addressValue,
                  city,
                  cityCd,
                  province,
                  provinceCd,
                  validFlag: true,
                  nation: '中国',
                  nationCd: '111156',
                };
                postBody = {
                  ...postBody,
                  [ADDRESS_TYPE_MAP[addressType]]: ADDRESS_TYPE_MAP[addressType] === 'idAddress' ?
                    newEditData : [newEditData],
                };
              }
              addOrUpdateContactPer(postBody);
            }
            return true;
          });
        }
      } else if (type === 'tel') {
        const editType = TEL_TYPE_MAP[originType];
        const oldEditData = dataSource[editType];
        oldEditData.map((i) => {
          if (i.rowId === rowId) {
            // 判断电话类型
            if (telType !== originType) {
              // // 删掉旧的电话，新增新的电话
              // 直接将旧的电话的rowId拿给新的电话，旧的电话会自动删除，
              // 后台只支持这样
              oldTelData = i;
              const oldRowId = oldTelData.rowId;
              const { mainFlag: oldMainFlag } = oldTelData;
              newTelData = {
                validFlag: true,
                contactValue: telValue,
                mainFlag: oldMainFlag,
                rowId: oldRowId,
              };
              postBody = {
                ...postBody,
                [TEL_TYPE_MAP[telType]]: [newTelData],
              };
            } else {
              // 直接修改成新的电话
              let newEditData = i;
              newEditData = {
                ...newEditData,
                validFlag: true,
                contactValue: telValue,
              };
              postBody = {
                ...postBody,
                [TEL_TYPE_MAP[telType]]: [newEditData],
              };
            }
            addOrUpdateContactPer(postBody);
          }
          return true;
        });
      }
    }

    if (goBackCount === 1) {
      goBack();
    } else {
      go(-goBackCount);
      // 恢复返回级数
      updateGoBackLevel({ count: 1 });
    }

    return true;
  }

  checkAddressRadioIsChecked(rowId, contactValue) {
    const data = this.state.addressRadioValueArray;
    const len = data.length;
    for (let i = 0; i < len; i++) {
      if (data[i].rowId === rowId) {
        if (data[i].selectValue === contactValue) {
          return true;
        }
      }
      return false;
    }
    return false;
  }

  formatAddress(province, provinceCd, city, address) {
    const specialProvinceCdArray = ['DF02', 'DF03', 'DF18', 'DF24', 'DF28', 'DF29', 'DF30'];
    return `${province || ''}${_.includes(specialProvinceCdArray, provinceCd) ? '' : city || ''}${address || ''}`;
  }

  // 手机、邮箱
  renderMainNode(rowId, typeName, contactValue) {
    const mainRadio = classnames({
      mainRadio: true,
      checked: this.state.radioValue === contactValue,
    });
    return (
      <SwipeAction
        key={rowId}
        className="swipe-list"
        autoClose
        right={[
          {
            text: '删除',
            onPress: () => this.handleDeleteClick(rowId, typeName),
            style: { backgroundColor: '#ddd', color: 'white' },
          },
        ]}
      >
        <div key={rowId} className="mainSection">
          <div className="right-section">
            <div className="content" onClick={() => this.handleMoreClick(typeName, contactValue, rowId)}>
              <div className="left-section">
                <div className="name">{typeName}</div>
              </div>
              <div
                className="right-section"
              >
                <div className="value">{contactValue}</div>
                <Icon {...more} />
              </div>
            </div>
            <div className="solid-separator" />
            <div className="radioSection">
              <Radio
                className={mainRadio}
                key={contactValue}
                checked={this.state.radioValue === contactValue}
                onClick={() => this.onRadioChange(contactValue, rowId, typeName)}
              >
                {'设为主要'}
              </Radio>
            </div>
          </div>
        </div>
      </SwipeAction>
    );
  }

  // 地址
  renderAddressNode(rowId, typeName, province, city,
    contactValue, address, cityCd, provinceCd) {
    const mainRadio = classnames({
      mainRadio: true,
      checked: this.checkAddressRadioIsChecked(rowId, contactValue),
    });
    return (
      <SwipeAction
        key={rowId}
        className="swipe-list"
        autoClose
        right={[
          {
            text: '删除',
            onPress: () => this.handleDeleteClick(rowId, typeName),
            style: { backgroundColor: '#ddd', color: 'white' },
          },
        ]}
      >
        <div key={rowId} className="addressSection">
          <div className="right-section">
            <div
              className="content"
              onClick={() =>
                this.handleMoreClick(
                  typeName,
                  address,
                  rowId,
                  province,
                  city,
                  cityCd,
                  provinceCd,
                )}
            >
              <div className="top-section">
                <div className="name">{typeName}</div>
                <Icon {...more} />
              </div>
              <div
                className="bottom-section"
              >
                <div className="value">{contactValue}</div>
              </div>
            </div>
            <div className="solid-separator" />
            <div className="radioSection">
              <Radio
                className={mainRadio}
                key={contactValue}
                checked={this.checkAddressRadioIsChecked(rowId, `${province || ''}${city || ''}${address || ''}`)}
                onClick={() => this.onAddressRadioChange(rowId, typeName)}
              >
                {'设为主要'}
              </Radio>
            </div>
          </div>
        </div>
      </SwipeAction >
    );
  }

  // 公用的单行
  renderCommonNode(rowId, typeName, contactValue) {
    return (
      <SwipeAction
        key={rowId}
        className="swipe-list"
        autoClose
        right={[
          {
            text: '删除',
            onPress: () => this.handleDeleteClick(rowId, typeName),
            style: { backgroundColor: '#ddd', color: 'white' },
          },
        ]}
      >
        <div className="commonSection">
          <div className="right-section" onClick={() => this.handleMoreClick(typeName, contactValue, rowId)}>
            <div className="left-section">
              <div className="commonName">{typeName}</div>
              <div className="right-separator" />
            </div>
            <div className="right-section">
              <div className="commonValue">{contactValue}</div>
              <Icon {...more} className="commonMore" />
            </div>
          </div>
        </div>
      </SwipeAction>
    );
  }

  renderNode(finalArray, type, data) {
    switch (type) {
      case 'tel':
        if (data.cellPhones && data.cellPhones.length > 0) {
          data.cellPhones.map((item) => {
            if (item.contactValue) {
              finalArray.push(
                this.renderMainNode(item.rowId, '手机', item.contactValue),
              );
            }
            return true;
          });
        }
        if (data.workTels && data.workTels.length > 0) {
          data.workTels.map((item) => {
            if (item.contactValue) {
              finalArray.push(
                this.renderCommonNode(item.rowId, '单位', item.contactValue),
              );
            }
            return true;
          });
        }
        if (data.homeTels && data.homeTels.length > 0) {
          data.homeTels.map((item) => {
            if (item.contactValue) {
              finalArray.push(
                this.renderCommonNode(item.rowId, '住宅', item.contactValue),
              );
            }
            return true;
          });
        }
        if (data.otherTels && data.otherTels.length > 0) {
          data.otherTels.map((item) => {
            if (item.contactValue) {
              finalArray.push(
                this.renderCommonNode(item.rowId, '其他', item.contactValue),
              );
            }
            return true;
          });
        }
        break;
      case 'email':
        if (data.emailAddresses && data.emailAddresses.length > 0) {
          data.emailAddresses.map((item) => {
            if (item.contactValue) {
              finalArray.push(
                this.renderMainNode(item.rowId, '邮箱', item.contactValue),
              );
            }
            return true;
          });
        }
        break;
      case 'address':
        if (data.idAddress && Object.keys(data.idAddress).length > 0) {
          const { rowId, province, city, address, cityCd, provinceCd } = data.idAddress;
          finalArray.push(
            this.renderAddressNode(rowId, '身份证地址', province || '', city || '',
              this.formatAddress(province, provinceCd, city, address), `${address}`, cityCd, provinceCd),
          );
        }
        if (data.homeAddresses && data.homeAddresses.length > 0) {
          data.homeAddresses.map((item) => {
            if (item.address) {
              finalArray.push(
                this.renderAddressNode(item.rowId, '家庭地址', item.province || '', item.city || '',
                  this.formatAddress(item.province, item.provinceCd, item.city, item.address), `${item.address}`, item.cityCd, item.provinceCd),
              );
            }
            return true;
          });
        }
        if (data.workAddresses && data.workAddresses.length > 0) {
          data.workAddresses.map((item) => {
            if (item.address) {
              finalArray.push(
                this.renderAddressNode(item.rowId, '单位地址', item.province || '', item.city || '',
                  this.formatAddress(item.province, item.provinceCd, item.city, item.address), `${item.address}`, item.cityCd, item.provinceCd),
              );
            }
            return true;
          });
        }
        if (data.otherAddresses && data.otherAddresses.length > 0) {
          data.otherAddresses.map((item) => {
            if (item.address) {
              finalArray.push(
                this.renderAddressNode(item.rowId, '其他地址', item.province || '', item.city || '',
                  this.formatAddress(item.province, item.provinceCd, item.city, item.address), `${item.address}`, item.cityCd, item.provinceCd),
              );
            }
            return true;
          });
        }
        break;
      case 'qq':
        if (data.qqNumbers && data.qqNumbers.length > 0) {
          data.qqNumbers.map((item) => {
            if (item.contactValue) {
              finalArray.push(
                this.renderCommonNode(item.rowId, 'QQ', item.contactValue),
              );
            }
            return true;
          });
        }
        break;
      case 'wechat':
        if (data.wechatNumbers && data.wechatNumbers.length > 0) {
          data.wechatNumbers.map((item) => {
            if (item.contactValue) {
              finalArray.push(
                this.renderCommonNode(item.rowId, '微信', item.contactValue),
              );
            }
            return true;
          });
        }
        break;
      default:
        break;
    }

    return finalArray;
  }

  render() {
    const { type } = this.props;
    const { dataSource } = this.state;
    if (!type || !dataSource) {
      return null;
    }

    let finalArray = [];
    finalArray = this.renderNode(finalArray, type, dataSource);

    return (
      <div className="edit-contact-section">
        {finalArray}
        <div className="addSection" onClick={() => this.handleAddClick()}>
          <Icon {...addIcon} />
          <span className="content">添加</span>
        </div>
      </div>
    );
  }
}
