/**
 * @file customer/RecordDetailItem.js
 *  历史服务记录中有更多按钮的列表
 * @author wangjunjun
 */
import React, { PureComponent, PropTypes } from 'react';
import ReactDOM from 'react-dom';
import { Flex, Modal } from 'antd-mobile';
import { autobind } from 'core-decorators';
import classnames from 'classnames';

const Item = Flex.Item;

export default class RecordDetailItem extends PureComponent {

  static propTypes = {
    label: PropTypes.string.isRequired,
    value: PropTypes.string,
  }

  static defaultProps = {
    value: '',
  }

  constructor(props) {
    super(props);
    this.state = {
      isShowMoreBtn: false,
      showModal: false,
    };
  }

  componentDidMount() {
    this.showMoreBtn();
  }

  setDetailInfoHeight() {
    // 设置一下弹出dialog的高度
    const modalBody = document.querySelector('.am-modal .am-modal-body');
    if (modalBody) {
      modalBody.style.maxHeight = `${document.documentElement.clientHeight * 0.4}px`;
    }
  }

  @autobind
  handleMore() {
    this.setState({
      showModal: true,
    }, this.setDetailInfoHeight);
  }

  @autobind
  handleClose() {
    this.setState({
      showModal: false,
    });
  }

  showMoreBtn() {
    const ele = ReactDOM.findDOMNode(this).querySelector('.detailItemContent'); // eslint-disable-line
    const height = ele.offsetHeight;
    const lineHeight = parseFloat(window.getComputedStyle(ele, null).getPropertyValue('line-height'));
    if (height >= 2.5 * Math.floor(lineHeight)) {
      this.setState({
        isShowMoreBtn: true,
      });
    }
  }

  render() {
    const { label, value } = this.props;
    const { isShowMoreBtn, showModal } = this.state;
    const moreCls = classnames({
      'more-btn': true,
      hide: !isShowMoreBtn,
    });
    const moreNode = (<div className={moreCls} onClick={this.handleMore}>更多</div>);
    return (
      <Flex className="flex-container" direction="row" justify="start" align="center" wrap="nowrap">
        <Item>
          <div className="detailItemTitle">
            {label}
          </div>
        </Item>
        <Item>
          <div className="detailItemContent">
            {value || '--'}
          </div>
          {moreNode}
        </Item>
        {
          showModal ?
            <Modal
              title={label}
              transparent
              maskClosable={false}
              visible={showModal}
              onClose={this.handleClose}
              footer={[{ text: '确定', onPress: () => { console.log('ok'); this.handleClose(); } }]}
              platform="ios"
            >
              <div dangerouslySetInnerHTML={{ __html: value }} />
            </Modal> : null
        }
      </Flex>
    );
  }
}
