/**
 * @file customer/SearchList.js
 * @author maoquan(maoquan@htsc.com)
 */

import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import { ListView } from 'antd-mobile';

import SearchItem from './SearchItem';
import { prepareDataSource } from '../../utils/listView';
import helper from '../../utils/helper';
import cordova from '../../utils/cordova';
import { constants } from '../../config';
import Message from '../message';
import './searchList.less';

export default class SearchList extends PureComponent {

  static propTypes = {
    searchInfo: PropTypes.object.isRequired,
    replace: PropTypes.func.isRequired,
    push: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired,
    doSearch: PropTypes.func.isRequired,
    isLoaded: PropTypes.bool.isRequired,
    saveQuery: PropTypes.func.isRequired,
  }

  static defaultProps = {
  }

  constructor(props) {
    super(props);
    const { searchInfo: { list } } = props;
    this.state = {
      dataSource: prepareDataSource(list),
      isLoading: false,
      messageHeight: 0,
      listViewHeight: 0,
    };
  }

  componentDidMount() {
    const touchEle = document.querySelector('.customer-search-list-view');
    touchEle.addEventListener('touchmove', helper.hideKeyboard, false);
    this.setMessageHeight();
  }

  componentWillReceiveProps(nextProps) {
    const { searchInfo: { list } } = nextProps;

    if (list !== this.props.searchInfo.list) {
      this.setState({
        dataSource: prepareDataSource(list),
        isLoading: false,
      });
    }
  }

  componentDidUpdate() {
    this.setMessageHeight();
  }

  @autobind
  onEndReached() {
    const { searchInfo: { page } } = this.props;
    const { isLoading } = this.state;
    if (!isLoading
      && (page.curPageNum < page.totalPageNum)
      && cordova.isConnected()
    ) {
      this.setState({ isLoading: true }, this.refreshMore);
    }
  }

  setMessageHeight() {
    this.setState({
      messageHeight: helper.getAvailableHeight({ el: ['.fixed-header'] }),
      listViewHeight: helper.getAvailableHeight({ el: ['.fixed-header'] }),
    });
  }

  /**
   * 根据产品分类id获取产品列表
   */
  @autobind
  refreshMore() {
    const {
      doSearch,
      searchInfo: { page },
      location: { query },
    } = this.props;
    doSearch({
      ...query,
      page: page.curPageNum + 1,
    });
  }

  @autobind
  handleClick(data) {
    const { push, location: { query }, saveQuery } = this.props;
    const {
      cusId: custId,
      brokerNumber: custNumber,
      custType,
    } = data;
    saveQuery({
      type: 'customer',
      query,
    });
    push({
      pathname: '/customer/detail',
      query: {
        custId,
        custNumber,
        custSor: custType === 'prod' ? 'org' : custType,
      },
    });
  }

  @autobind
  renderRow(rowData, sectionID, rowID) {
    const { location: { query: { keyword } } } = this.props;
    // 如果搜索条件不是纯数字，则认为是姓名搜索
    // 不需要展示搜索条件，如电话、开户号等
    let extra = keyword;
    if (/\D/.test(keyword)) {
      extra = '';
    }
    return (
      <SearchItem
        key={`${sectionID}-${rowID}`}
        data={rowData}
        extra={extra}
        query={keyword}
        onClick={() => this.handleClick(rowData)}
      />
    );
  }

  renderSeparator(sectionID, rowID) {
    return (
      <div
        key={`${sectionID}-${rowID}`}
        className="list-separator"
      />
    );
  }

  @autobind
  renderFooter() {
    const { isLoaded, searchInfo: { page, list } } = this.props;
    const { isLoading, messageHeight } = this.state;
    let text = '';
    if (list.length === 0) {
      if (!cordova.isConnected()) {
        return (
          <Message type={'network'} height={messageHeight} />
        );
      } else if (isLoaded) {
        return (
          <Message type={'notfound'} height={messageHeight} />
        );
      }
    } else if (isLoading) {
      text = '加载中...';
    } else if (page.curPageNum > 1) {
      if (page.curPageNum === page.totalPageNum) {
        text = '已经到底了';
      } else {
        text = '上拉加载更多';
      }
    }
    return (
      <div>
        {text}
      </div>
    );
  }

  @autobind
  renderHeader() {
    return (
      <p>客户搜索结果</p>
    );
  }

  render() {
    const { dataSource, listViewHeight } = this.state;
    return (
      <div className="customer-search-list-view">
        <ListView
          className="customer-search-list"
          dataSource={dataSource}
          style={{ height: listViewHeight }}
          initialListSize={constants.initialListSize}
          renderHeader={this.renderHeader}
          renderFooter={this.renderFooter}
          renderRow={this.renderRow}
          renderSeparator={this.renderSeparator}
          pageSize={10}
          scrollRenderAheadDistance={500}
          scrollEventThrottle={20}
          onEndReached={this.onEndReached}
          onEndReachedThreshold={10}
          useZscroller
        />
      </div>
    );
  }
}
