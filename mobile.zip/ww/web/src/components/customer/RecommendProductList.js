/**
 * @file customer/RecommendProductList.js
 * @author xuxiaoqin
 */

import React, { PropTypes, PureComponent } from 'react';
import { SwipeAction, List } from 'antd-mobile';
import { autobind } from 'core-decorators';
import _ from 'lodash';
import Toast from '../../components/common/Toast';
import { openUrl } from '../../utils/cordova';
import './recommendProductList.less';
import api from '../../api';
import { constants } from '../../config';

const Item = List.Item;
const EMPTY_LIST = [];

export default class RecommendProductList extends PureComponent {

  static propTypes = {
    recommendProductList: PropTypes.array,
    push: PropTypes.func,
    location: PropTypes.object,
    ignoreRecommendProduct: PropTypes.func.isRequired,
    empInfoData: PropTypes.object,
  }

  static defaultProps = {
    push: () => { },
    recommendProductList: [],
    location: {},
    empInfoData: {},
  }

  constructor(props) {
    super(props);

    const { location: { query: {
      custSor: custType,
      custId: custRowId,
      custNumber,
      } }, empInfoData } = this.props;

    const { rowId: empRowId } = empInfoData;

    const motDataSource = {
      custRowId,
      custType,
      empRowId,
      type: 'Email',
      isEnable: false,
      serviceContent: '',
      custNumber,
    };

    this.state = {
      isLoading: false,
      motData: motDataSource,
      currentTargetProduct: '',
      productCode: '',
      productName: '',
      clientName: '',
    };
  }

  @autobind
  handleIgnoreClick(clientIdSign, productCode, directoryCode) {
    const { location: { query: { custId, custNumber, custSor } },
      ignoreRecommendProduct } = this.props;
    ignoreRecommendProduct({
      custId,
      custNumber,
      custSor,
      clientIdSign,
      productCode,
      directoryCode,
      source: '01',
    });
    this.setState({
      currentTargetProduct: `${productCode}_${directoryCode}`,
    });
  }

  @autobind
  handleProductClick(event, productCode, directoryCode, prdtType) {
    if (event.target.nodeName.toLowerCase() === 'i') {
      return;
    }

    const { push } = this.props;
    // 产品code为1，代表私募产品
    // 产品code为2，代表紫金
    // 产品code为3，代表公募
    if (prdtType === 1) {
      push({
        pathname: '/product/detail',
        query: {
          productCode,
          directoryCode,
        },
      });
    } else if (prdtType === 2) {
      const authInfo = api.getAuthInfo();
      openUrl({ path: `/${constants.zlUrl}/zzlc2/zjlc/zjlc.htm?directoryCode=${directoryCode}&productCode=${productCode}&empId=${authInfo.empId}&deviceId=${authInfo.deviceId}&token=${authInfo.token}&isShowMenu=N`, title: '产品详情-紫金' });
    } else if (prdtType === 3) {
      const authInfo = api.getAuthInfo();
      openUrl({ path: `/${constants.zlUrl}/cwjj/jzx/index.htm?directoryCode=${directoryCode}&productCode=${productCode}&empId=${authInfo.empId}&deviceId=${authInfo.deviceId}&token=${authInfo.token}&isShowMenu=N`, title: '产品详情-公募' });
    } else {
      Toast.info('该产品无详情页面', 1);
    }
  }

  /**
   * 过滤数据源
   */
  @autobind
  filterData(data) {
    if (_.isEmpty(data)) {
      return EMPTY_LIST;
    }

    const filterData = data;
    const len = filterData.length;

    for (let i = 0; i < len; i++) {
      if (!_.isEmpty(filterData[i])) {
        /* eslint-disable */
        for (const key in filterData[i]) {
          if ((!_.isNumber(filterData[i][key]) && _.isEmpty(filterData[i][key]))
            || _.isEmpty(filterData[i][key].toString())) {
            filterData[i][key] = '- -';
          }
        }
        /* eslint-enable */
      }
    }
    return filterData;
  }

  formatePercent(d) {
    let rtnValue;
    if (d >= 100) {
      rtnValue = d.toFixed();
    } else if (d < 100 && d >= 10) {
      rtnValue = d.toFixed(1);
    } else if (d < 10) {
      rtnValue = d.toFixed(2);
    }
    return rtnValue;
  }

  formateWorth(num) {
    if (!_.includes(String(num), '.')) return num;
    const len = String(num).split('.')[1].length;
    return len >= 3 ? num.toFixed(3) : num.toFixed(len);
  }

  render() {
    const { recommendProductList } = this.props;
    const finalData = recommendProductList || EMPTY_LIST;
    if (_.isEmpty(finalData)) {
      return null;
    }

    const finalHtmlArray = [];
    const dataLen = finalData.length;
    if (dataLen > 0) {
      for (let j = 0; j < dataLen; j++) {
        if (!_.isEmpty(finalData[j])) {
          let yieldType = '';
          let yieldValue = '';
          if (finalData[j].performanceType === 2) {
            yieldType = '七日年化收益率';
            yieldValue = finalData[j].annuYield ? `${this.formatePercent(finalData[j].annuYield)}%` : '- -';
          } else if (finalData[j].performanceType === 3) {
            yieldType = '净值';
            yieldValue = finalData[j].unitNav ? this.formateWorth(finalData[j].unitNav) : '- -';
          } else if (finalData[j].performanceType === 1) {
            yieldType = '预期收益率';
            yieldValue = finalData[j].expectedYield ? `${this.formatePercent(finalData[j].expectedYield)}%` : '- -';
          }

          finalHtmlArray.push(
            <SwipeAction
              key={finalData[j].productCode}
              className="swipe-list"
              autoClose
              right={[
                {
                  text: '不适合',
                  onPress: () => this.handleIgnoreClick(finalData[j].clientIdSign,
                    finalData[j].productCode, finalData[j].directoryCode),
                  style: { backgroundColor: '#ddd', color: 'white' },
                },
              ]}
            >
              <Item
                className="list-item"
                extra=""
                arrow="empty"
              >
                <div
                  className="recommendSection"
                  onClick={(event) => {
                    this.handleProductClick(event, finalData[j].productCode,
                      finalData[j].directoryCode, finalData[j].prdtType);
                  }}
                >
                  <div className="scoreSection">
                    <div className="scoreContent">{finalData[j].productScore || '- -'}</div>
                    <div className="score">购买评分</div>
                  </div>
                  <div className="productSection">
                    <div className="productSectionLine">
                      <div className="productName">{finalData[j].productName || '- -'}</div>
                    </div>
                    <div className="productSectionLine fix-padding-top fix-justify">
                      <div className="productCode">{finalData[j].productCode || '- -'}</div>
                      <div className="categoryName">
                        <div className="cate">
                          {finalData[j].productCategoryName || '- -'}
                        </div>
                      </div>
                    </div>
                    <div className="productSectionLine">
                      <div className="expectedYield">
                        {`${yieldType}：${yieldValue}` || '- -'}
                      </div>
                      <div className="bfMaturity">{finalData[j].bfMaturity
                        ? `${finalData[j].bfMaturity}天` : '- -'}
                      </div>
                    </div>
                  </div>
                </div>
              </Item>
            </SwipeAction>,
          );
        }
      }
      return (
        <div className="prdtListSection">
          <List
            renderHeader={() => '为ta推荐'}
            className="productList"
          >
            {finalHtmlArray}
          </List>
        </div>
      );
    }
    return null;
  }
}
