/**
 * @file mission/CustTaskDesc.js
 * @author hongguangqing
 */
import React, { PropTypes, PureComponent } from 'react';
import ReactDOM from 'react-dom';
import { autobind } from 'core-decorators';
import { RefreshControl, ListView, Modal } from 'antd-mobile';
import _ from 'lodash';

import cordova from '../../utils/cordova';
import { renderIcon, renderLoading, distanceToRefresh } from '../common/PullToRefreshable';
import { prepareDataSource } from '../../utils/listView';
import CustTaskItem from '../customer/CustTaskItem';
import Message from '../message';
import { checkListPTR } from '../../decorators/checkNetwork';
import { checkErrData } from '../../decorators/checkErrorData';

import './custTaskDesc.less';

export default class CustTaskDesc extends PureComponent {

  static propTypes = {
    list: PropTypes.array,
    location: PropTypes.object.isRequired,
    custId: PropTypes.string.isRequired,
    push: PropTypes.func.isRequired,
    refresh: PropTypes.func.isRequired,
    isFetching: PropTypes.bool.isRequired,
    onItemSelected: PropTypes.func.isRequired,
    checkedList: PropTypes.array.isRequired,
    reportRefresh: PropTypes.func.isRequired,
  }

  static defaultProps = {
    list: [],
  }

  constructor(props) {
    super(props);
    this.state = {
      isLoaded: false,
      // dataSource: prepareDataSource(list),
      isLoading: false,
      messageHeight: 0,
      // 弹出info dialog
      isShowInfo: false,
      currentMotTaskName: '',
      currentDetailInfo: '',
      currentsuggestInfo: '',
      checkedList: [],
    };
  }

  componentDidMount() {
    this.setHeight();
  }

  @checkErrData()
  componentWillReceiveProps(nextProps) {
    const { list } = nextProps;
    if (list !== this.props.list) {
      this.setState({
        isLoaded: true,
      });
    }
  }

  componentDidUpdate() {
    this.setHeight();
  }

  @autobind
  @checkListPTR({ propertyName: 'isLoading' })
  onRefresh() {
    const { location: { query }, refresh, reportRefresh } = this.props;
    refresh({
      ...query,
    });
    reportRefresh({
      actionSource: '待办任务',
    });
  }

  setHeight() {
    // 更新列表高度
    if (this.listElem) {
      const listElem = ReactDOM.findDOMNode(this.listElem); // eslint-disable-line
      const height = document.documentElement.clientHeight
        - listElem.getBoundingClientRect().top;
      listElem.style.height = `${height}px`;
      this.setState({
        messageHeight: height,
      });
    }
  }

  setDetailInfoHeight() {
    // 设置一下弹出dialog的高度
    const modalBody = document.querySelector('.am-modal .am-modal-body');
    if (modalBody) {
      modalBody.style.maxHeight = `${document.documentElement.clientHeight * 0.4}px`;
    }
  }

  @autobind
  handleInfoClick(rowData) {
    const { eventName, contents, detailContent } = rowData;
    this.setState({
      isShowInfo: true,
      currentMotTaskName: eventName,
      currentDetailInfo: contents,
      currentsuggestInfo: detailContent,
    }, this.setDetailInfoHeight);
  }

  @autobind
  handleInfoClose() {
    this.setState({ isShowInfo: false });
  }

  @autobind
  handleItemChange(rowData, checked) {
    this.props.onItemSelected(rowData, checked);
  }

  @autobind
  renderRow(rowData) {
    const { push, custId, checkedList } = this.props;
    const checked = _.includes(checkedList, rowData.mssnId);

    return (
      <CustTaskItem
        key={rowData.mssnId}
        data={{
          ...rowData,
          custId,
        }}
        push={push}
        onInfoClick={this.handleInfoClick}
        onChange={isChecked => this.handleItemChange(rowData, isChecked)}
        checked={checked}
      />
    );
  }

  @autobind
  renderSeparator(sectionID, rowID) {
    return (
      <div
        key={`${sectionID}-${rowID}`}
        className="list-separator"
      />
    );
  }

  @autobind
  renderFooter() {
    const { messageHeight, isLoaded } = this.state;
    const { list } = this.props;
    const dataSource = prepareDataSource(list);
    let messageType = '';
    if (!cordova.isConnected()) {
      messageType = 'network';
    } else if (dataSource.getRowCount() === 0 && isLoaded) {
      messageType = 'notfound';
    }

    return messageType ? (
      <Message type={messageType} height={messageHeight} text={'暂无待办任务'} />
    ) : null;
  }

  render() {
    const {
      isLoading,
      currentMotTaskName,
      currentDetailInfo,
      currentsuggestInfo,
      isShowInfo,
    } = this.state;
    const { list } = this.props;
    const dataSource = prepareDataSource(list);
    const detailInfo = currentDetailInfo || '暂无信息';
    const suggestInfo = currentsuggestInfo || '暂无信息';
    return (
      <div
        className="page mot-cust-list cust-task-list"
      >
        <ListView
          ref={ref => (this.listElem = ref)}
          className="list"
          dataSource={dataSource}
          renderRow={this.renderRow}
          renderSeparator={this.renderSeparator}
          renderFooter={this.renderFooter}
          pageSize={10}
          initialListSize={20}
          scrollEventThrottle={20}
          scrollRenderAheadDistance={400}
          refreshControl={<RefreshControl
            refreshing={isLoading}
            onRefresh={this.onRefresh}
            distanceToRefresh={distanceToRefresh}
            icon={renderIcon()}
            loading={renderLoading()}
          />}
        />
        {// 每次都重新创建modal弹框，若重用弹框，会记住滑动的offset，不符合需求。
          isShowInfo
            ?
              <Modal
                title={currentMotTaskName}
                transparent
                maskClosable={false}
                visible={isShowInfo}
                footer={[{ text: '确定', onPress: this.handleInfoClose }]}
                onClose={this.handleInfoClose}
              >
                <div className="custTask-Modal-content">
                  <div className="title">服务策略建议:</div>
                  <div dangerouslySetInnerHTML={{ __html: detailInfo }} />
                  <div className="detail title">详细内容:</div>
                  <div dangerouslySetInnerHTML={{ __html: suggestInfo }} />
                </div>
              </Modal> : null
        }
      </div>
    );
  }
}
