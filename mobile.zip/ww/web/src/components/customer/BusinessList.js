import React, { PureComponent, PropTypes } from 'react';
import { List } from 'antd-mobile';
import _ from 'lodash';

// import Icon from '../../components/common/Icon';
import helper from '../../utils/helper';
import Message from '../../components/message';
import './businessList.less';

const Item = List.Item;

export default class CustBusinessInfo extends PureComponent {
  static propTypes = {
    notOpenArr: PropTypes.array.isRequired,
    openArr: PropTypes.array.isRequired,
    isLoaded: PropTypes.bool.isRequired,
  }
  static defaultProps = {
  }

  // 格式化时间字符串
  formatterDate(date) {
    if (!_.isEmpty(date) && date.length === 8) {
      const year = date.substring(0, 4);
      const month = date.substring(4, 6);
      const day = date.substring(6);
      return `${year}/${month}/${day}`;
    }
    return '--';
  }

  render() {
    const { isLoaded, notOpenArr, openArr } = this.props;
    if (isLoaded) {
      // 默认加载‘暂无开通业务’图片
      if (_.isEmpty(notOpenArr) && _.isEmpty(openArr)) {
        return (
          <Message
            height={helper.getAvailableHeight()}
            type={'notfound'}
            text={'暂无开通业务'}
          />
        );
      }
    }

    // 解析数据
    const openItemShow = openArr.map(item => (
      <Item
        key={item.serviceCode}
        extra={
          <div className="open-text">
            <span>开通时间：</span>
            <span className="time">{this.formatterDate(item.openingDate)}</span>
          </div>
        }
      >
        {item.serviceName}
      </Item>
    ));
    const notOpenItemShow = notOpenArr.map(item => (
      <Item
        key={item.serviceCode}
        extra={
          <div className="not-open-text">
            {item.qualifiedFlag === 'Y'
              ? (<div className="extra-div">
                <span>基本达到开通条件</span>
              </div>)
              : '未达到开通条件'
            }
          </div>
        }
      >
        {item.serviceName}
      </Item>
    ));

    return (
      <div className="custBusinessInfo">
        <List className="open-list">
          {openItemShow}
        </List>

        <List className="not-open-list">
          {notOpenArr.length > 0 ? <div className="not-business-title">未开通业务</div> : null}
          {notOpenItemShow}
        </List>
      </div>
    );
  }
}
