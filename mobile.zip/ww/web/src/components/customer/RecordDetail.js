/**
 * @file customer/RecordDetail.js
 *  历史服务记录
 * @author xuxiaoqin
 */

import React, { PureComponent, PropTypes } from 'react';
import { List } from 'antd-mobile';
import { autobind } from 'core-decorators';
import _ from 'lodash';
import moment from 'moment';
import 'moment/locale/zh-cn';

import './recordDetail.less';

export default class RecordDetail extends PureComponent {

  static propTypes = {
    data: PropTypes.object.isRequired,
    push: PropTypes.func.isRequired,
  }

  @autobind
  handleEdit() {
    const { data = {} } = this.props;
    this.props.push(`/customer/recordEdit?title=查看服务记录&&preContent=${data.serveRecord}&&canEdit=false`);
  }

  render() {
    const { data = {} } = this.props;
    if (_.isEmpty(data)) {
      return null;
    }
    const { custFeedback = '' } = data || {};
    const feedbackArray = _.split(custFeedback, '-');
    const formatServeTime = data.serveTime ? moment(data.serveTime).utcOffset(8).format('YYYY年MM月DD日 HH:mm') : '--';
    return (
      <List className="recordContent">
        <List.Item extra={data.actor || '--'} className="noArrow">客户姓名</List.Item>
        <List.Item extra={data.serveOrigin || '--'} className="noArrow">服务方式</List.Item>
        <List.Item extra={data.subtypeCd || '--'} className="noArrow">服务类型</List.Item>
        <List.Item extra={formatServeTime} className="noArrow">服务时间</List.Item>
        <List.Item
          extra={data.serveRecord || '--'}
          onClick={this.handleEdit}
          arrow="horizontal"
        >服务记录</List.Item>
        <List.Item extra={_.head(feedbackArray) || '--'} className="noArrow">客户反馈</List.Item>
        <List.Item extra={_.last(feedbackArray) || '--'} className="noArrow">反馈明细</List.Item>
      </List>
    );
  }
}
