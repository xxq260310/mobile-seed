/**
 * @file customer/CustTaskItem.js
 * @author hongguangqing
 */

import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import { List, Checkbox } from 'antd-mobile';
import './custTaskItem.less';

const CheckboxItem = Checkbox.CheckboxItem;
const defaultCheckedList = [];

export default class CustTaskItem extends PureComponent {

  static propTypes = {
    data: PropTypes.object,
    push: PropTypes.func.isRequired,
    onInfoClick: PropTypes.func,
    onChange: PropTypes.func,
    checked: PropTypes.bool.isRequired,
  }

  static defaultProps = {
    data: {},
    onInfoClick: () => { },
    onChange: () => { },
  }

  constructor(props) {
    super(props);
    this.state = {
      checkedList: defaultCheckedList,
    };
  }

  @autobind
  handleChange(e) {
    const checked = e.target.checked;
    this.props.onChange(checked);
  }

  @autobind
  handleInfoClick() {
    const { onInfoClick, data } = this.props;
    onInfoClick(data);
  }

  render() {
    const { handleInfoClick } = this;
    const { data: {
        eventName,
        processTime,
        executeType,
      },
      checked,
    } = this.props;
    const overtime = processTime.split(' ')[0].split(',')[0];
    return (
      <div className="item">
        <CheckboxItem onChange={e => this.handleChange(e, this.props.data)} checked={checked}>
          <div className="item-top">
            <div className="task-name">{eventName || '--'}</div>
            <div className="task-tip" onClick={handleInfoClick}><span className="tip">!</span></div>
          </div>
          <List.Item.Brief>
            <div className="item-bot">
              <div className="end-time">截止时间: {overtime.replace(/-/g, '/')}</div>
              <div className="task-status">{executeType === 'Chance' ? '选做' : '必做'}</div>
            </div>
          </List.Item.Brief>
        </CheckboxItem>
      </div>
    );
  }
}
