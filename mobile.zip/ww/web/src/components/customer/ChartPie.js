/**
 * @file customer/ChartPie.js
 *
 * @author xuxiaoqin
 */

import React, { PureComponent, PropTypes } from 'react';
import classnames from 'classnames';
import _ from 'lodash';
import Chart from '../chart';
import './chartPie.less';
import helper from '../../utils/helper';

const PIE_HASDATA_WIDTH = '40%';
// const PIE_HASDATA_HEIGHT = helper.getRealSize(600);
const PIE_NONEDATA_WIDTH = '100%';
const PIE_HASDATA_HEIGHT = `${helper.getRealSize(250).toString()}px`;
const PIE_NONEDATA_HEIGHT = `${helper.getRealSize(250).toString()}px`;
const PIE_HASDATA_MIN_HEIGHT = `${helper.getRealSize(250).toString()}px`;
const PIE_HASDATA_MAX_HEIGHT = `${helper.getRealSize(600).toString()}px`;

export default class ChartPieWidget extends PureComponent {
  static propTypes = {
    assetData: PropTypes.array,
  }

  static defaultProps = {
    assetData: [],
  }

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      isShowPieData: false,
    };
  }

  filterData(assetData) {
    if (assetData.indexOf('万') !== -1) {
      return Number.parseFloat(assetData.replace('万元', '')) * 10000;
    } else if (assetData.indexOf('亿') !== -1) {
      return Number.parseFloat(assetData.replace('亿元', '')) * 100000000;
    }
    return Number.parseFloat(assetData.replace('元', ''));
  }

  sortAsset(array) {
    if (array.length <= 1) {
      return array;
    }
    const left = [];
    const right = [];
    const index = Math.floor(array.length / 2);
    const flagObject = array.splice(index, 1)[0];
    const flag = Number.parseFloat(this.filterData(flagObject.maketVal));

    for (let i = 0; i < array.length; i++) {
      if (Number.parseFloat(this.filterData(array[i].maketVal)) > flag) {
        left.push(array[i]);
      } else {
        right.push(array[i]);
      }
    }

    return this.sortAsset(left).concat([flagObject], this.sortAsset(right));
  }

  render() {
    const { assetData = [] } = this.props;

    if (_.isEmpty(assetData)) {
      const nonePieOptions = {
        title: {
          text: '暂无数据',
          x: 'center',
          y: 'center',
        },
        height: PIE_NONEDATA_HEIGHT,
        width: PIE_NONEDATA_WIDTH,
      };

      const nonePieSeries = {
        name: '资产构成',
        type: 'pie',
        radius: ['40%', '60%'],
        center: ['50%', '50%'],
        label: {
          normal: {
            show: false,
          },
        },
        hoverAnimation: false,
        data: [
          {
            name: '暂无数据',
            value: 100,
          },
        ],
        color: ['#e6e5e5'],
        animation: false,
        // 不响应鼠标和触摸事件
        silent: true,
      };

      const nonePieDataClass = classnames({
        chartPieNoneSection: true,
        displayBlock: true,
        displayNone: false,
      });

      const nonePieArray = [];
      nonePieArray.push(
        <div key="noneData" className={nonePieDataClass}>
          <Chart {...nonePieOptions} className="chart-content">
            <Chart.Pie {...nonePieSeries} className="chart-pie" />
          </Chart>
        </div>,
      );

      return (
        <div>
          {
            nonePieArray
          }
          <div className="none-pie-data">暂无数据</div>
        </div>
      );
    }

    const len = assetData.length;
    const filteredData = [];
    for (let i = 0; i < len; i++) {
      if (assetData[i].maketVal !== null) {
        if (assetData[i].maketVal > 0) {
          if (assetData[i].maketVal.toString().indexOf('.') !== -1) {
            // 小数
            const temp = assetData[i].maketVal.toString().split('.');
            if (temp[0].length >= 1 && temp[0].length <= 4) {
              filteredData.push(
                {
                  categoryName: assetData[i].categoryName,
                  maketVal: `${Number.parseFloat(assetData[i].maketVal).toFixed(1)}元`,
                  categoryId: assetData[i].categoryId,
                  holdRate: Number.parseFloat(assetData[i].holdRate),
                });
            } else if (temp[0].length >= 5 && temp[0].length <= 8) {
              filteredData.push(
                {
                  categoryName: assetData[i].categoryName,
                  maketVal: `${(Number.parseFloat(temp[0]) / 10000).toFixed(1)}万元`,
                  categoryId: assetData[i].categoryId,
                  holdRate: Number.parseFloat(assetData[i].holdRate),
                });
            } else if (temp[0].length >= 9) {
              filteredData.push({
                categoryName: assetData[i].categoryName,
                maketVal: `${(Number.parseFloat(temp[0]) / 100000000).toFixed(1)}亿元`,
                categoryId: assetData[i].categoryId,
                holdRate: Number.parseFloat(assetData[i].holdRate),
              });
            }
          } else if (assetData[i].maketVal.toString().length >= 1
            && assetData[i].maketVal.toString().length <= 4) {
            filteredData.push({
              categoryName: assetData[i].categoryName,
              maketVal: `${assetData[i].maketVal.toFixed(1)}元`,
              categoryId: assetData[i].categoryId,
              holdRate: Number.parseFloat(assetData[i].holdRate),
            });
          } else if (assetData[i].maketVal.toString().length >= 5
            && assetData[i].maketVal.toString().length <= 8) {
            filteredData.push({
              categoryName: assetData[i].categoryName,
              maketVal: `${(assetData[i].maketVal / 10000).toFixed(1)}万元`,
              categoryId: assetData[i].categoryId,
              holdRate: Number.parseFloat(assetData[i].holdRate),
            });
          } else if (assetData[i].maketVal.toString().length >= 9) {
            filteredData.push({
              categoryName: assetData[i].categoryName,
              maketVal: `${(assetData[i].maketVal / 100000000).toFixed(1)}亿元`,
              categoryId: assetData[i].categoryId,
              holdRate: Number.parseFloat(assetData[i].holdRate),
            });
          }
        } else if (assetData[i].maketVal.toString().indexOf('.') !== -1) {
          // 小数
          const temp = assetData[i].maketVal.toString().replace('-', '').split('.');
          if (temp[0].length >= 1 && temp[0].length <= 4) {
            filteredData.push(
              {
                categoryName: assetData[i].categoryName,
                maketVal: `-${Number.parseFloat(temp[0]).toFixed(1)}元`,
                categoryId: assetData[i].categoryId,
                holdRate: Number.parseFloat(assetData[i].holdRate),
              });
          } else if (temp[0].length >= 5 && temp[0].length <= 8) {
            filteredData.push(
              {
                categoryName: assetData[i].categoryName,
                maketVal: `-${(Number.parseFloat(temp[0]) / 10000).toFixed(1)}万元`,
                categoryId: assetData[i].categoryId,
                holdRate: Number.parseFloat(assetData[i].holdRate),
              });
          } else if (temp[0].length >= 9) {
            filteredData.push({
              categoryName: assetData[i].categoryName,
              maketVal: `-${(Number.parseFloat(temp[0]) / 100000000).toFixed(1)}亿元`,
              categoryId: assetData[i].categoryId,
              holdRate: Number.parseFloat(assetData[i].holdRate),
            });
          }
        } else if (assetData[i].maketVal.toString().replace('-', '').length >= 1
          && assetData[i].maketVal.toString().replace('-', '').length <= 4) {
          filteredData.push({
            categoryName: assetData[i].categoryName,
            maketVal: `${assetData[i].maketVal.toFixed(1)}元`,
            categoryId: assetData[i].categoryId,
            holdRate: Number.parseFloat(assetData[i].holdRate),
          });
        } else if (assetData[i].maketVal.toString().replace('-', '').length >= 5
          && assetData[i].maketVal.toString().replace('-', '').length <= 8) {
          filteredData.push({
            categoryName: assetData[i].categoryName,
            maketVal: `${(assetData[i].maketVal / 10000).toFixed(1)}万元`,
            categoryId: assetData[i].categoryId,
            holdRate: Number.parseFloat(assetData[i].holdRate),
          });
        } else if (assetData[i].maketVal.toString().length - 1 >= 9) {
          filteredData.push({
            categoryName: assetData[i].categoryName,
            maketVal: `${(assetData[i].maketVal / 100000000).toFixed(1)}亿元`,
            categoryId: assetData[i].categoryId,
            holdRate: Number.parseFloat(assetData[i].holdRate),
          });
        }
      }
    }

    let assetTotal = 0;
    let pureAssetDataArray = [];
    // 总资产
    for (let j = 0; j < filteredData.length; j++) {
      if (filteredData[j].categoryName.toString().indexOf('负债') === -1
        && filteredData[j].categoryName.toString().indexOf('衍生品') === -1) {
        assetTotal = this.filterData(filteredData[j].maketVal) + assetTotal;
        pureAssetDataArray.push({
          categoryName: filteredData[j].categoryName,
          maketVal: filteredData[j].maketVal,
          holdRate: filteredData[j].holdRate,
          categoryId: filteredData[j].categoryId,
        });
      }
    }

    // 按照资产总额降序排序
    pureAssetDataArray = this.sortAsset(pureAssetDataArray);

    // 资产百分比
    const percentArray = [];
    const pureLen = pureAssetDataArray.length;
    for (let k = 0; k < pureLen; k++) {
      percentArray.push(`${(pureAssetDataArray[k].holdRate * 100).toFixed(1)}%`);
    }

    const pieData = [];
    for (let m = 0; m < pureLen; m++) {
      pieData.push({
        name: pureAssetDataArray[m].categoryName,
        value: this.filterData(pureAssetDataArray[m].maketVal),
      });
    }

    const fuzhaiData = _.find(filteredData, item => (
      item.categoryName.toString().indexOf('负债') !== -1
    ));

    const yanshengpinData = _.find(filteredData, item => (
      item.categoryName.toString().indexOf('衍生品') !== -1
    ));

    const options = {
      title: {
        text: '资产',
      },
      width: PIE_HASDATA_WIDTH,
      height: PIE_HASDATA_HEIGHT,
      style: {
        minHeight: PIE_HASDATA_MIN_HEIGHT,
        maxHeight: PIE_HASDATA_MAX_HEIGHT,
      },
    };

    // 生成饼图右边展示的百分比说明
    const finalArrData = [];
    const colorArray = [];
    for (let n = 0; n < pureLen; n++) {
      if (pureAssetDataArray[n].maketVal && parseFloat(pureAssetDataArray[n].maketVal) !== 0) {
        if (pureAssetDataArray[n].categoryName.toString().indexOf('现金') !== -1) {
          colorArray.push('#7fabe9');
          finalArrData.push(<div key={pureAssetDataArray[n].categoryId} className="xianjin">
            <div className="xianjinCircle" />
            <span className="assetName">{pureAssetDataArray[n].categoryName}</span>
            <span className="assetValue">{pureAssetDataArray[n].maketVal}</span>
            <span className="xianjinPercent">{percentArray[n]}</span>
          </div>);
        } else if (pureAssetDataArray[n].categoryName.toString().indexOf('股票') !== -1) {
          colorArray.push('#795bc7');
          finalArrData.push(<div key={pureAssetDataArray[n].categoryId} className="gupiao">
            <div className="gupiaoCircle" />
            <span className="assetName">{pureAssetDataArray[n].categoryName}</span>
            <span className="assetValue">{pureAssetDataArray[n].maketVal}</span>
            <span className="gupiaoPercent">{percentArray[n]}</span>
          </div>);
        } else if (pureAssetDataArray[n].categoryName.toString().indexOf('理财') !== -1) {
          colorArray.push('#ea9790');
          finalArrData.push(<div key={pureAssetDataArray[n].categoryId} className="licai">
            <div className="licaiCircle" />
            <span className="assetName">理财</span>
            <span className="assetValue">{pureAssetDataArray[n].maketVal}</span>
            <span className="licaiPercent">{percentArray[n]}</span>
          </div>);
        } else if (pureAssetDataArray[n].categoryName.toString().indexOf('债券') !== -1) {
          colorArray.push('#f3d781');
          finalArrData.push(<div key={pureAssetDataArray[n].categoryId} className="zhaiquan">
            <div className="zhaiquanCircle" />
            <span className="assetName">{pureAssetDataArray[n].categoryName}</span>
            <span className="assetValue">{pureAssetDataArray[n].maketVal}</span>
            <span className="zhaiquanPercent">{percentArray[n]}</span>
          </div>);
        } else if (pureAssetDataArray[n].categoryName.toString().indexOf('权证') !== -1) {
          colorArray.push('#d75e49');
          finalArrData.push(<div key={pureAssetDataArray[n].categoryId} className="quanzheng">
            <div className="quanzhengCircle" />
            <span className="assetName">权证</span>
            <span className="assetValue">{pureAssetDataArray[n].maketVal}</span>
            <span className="quanzhengPercent">{percentArray[n]}</span>
          </div>);
        } else if (pureAssetDataArray[n].categoryName.toString().indexOf('基金') !== -1) {
          colorArray.push('#f0b14a');
          finalArrData.push(<div key={pureAssetDataArray[n].categoryId} className="kaifangjijin">
            <div className="kaifangjijinCircle" />
            <span className="assetName">基金</span>
            <span className="assetValue">{pureAssetDataArray[n].maketVal}</span>
            <span className="kaifangjijinPercent">{percentArray[n]}</span>
          </div>);
        } else if (pureAssetDataArray[n].categoryName.toString().indexOf('私募') !== -1) {
          colorArray.push('#b3aee5');
          finalArrData.push(<div key={pureAssetDataArray[n].categoryId} className="simu">
            <div className="simuCircle" />
            <span className="assetName">私募</span>
            <span className="assetValue">{pureAssetDataArray[n].maketVal}</span>
            <span className="simuPercent">{percentArray[n]}</span>
          </div>);
        } else if (pureAssetDataArray[n].categoryName.toString().indexOf('OTC') !== -1) {
          colorArray.push('#b0d3f3');
          finalArrData.push(<div key={pureAssetDataArray[n].categoryId} className="otc">
            <div className="otcCircle" />
            <span className="assetName">OTC</span>
            <span className="assetValue">{pureAssetDataArray[n].maketVal}</span>
            <span className="otcPercent">{percentArray[n]}</span>
          </div>);
        }
      }
    }

    const series = {
      name: '资产构成',
      type: 'pie',
      radius: ['40%', '60%'],
      center: ['50%', '50%'],
      label: {
        normal: {
          show: false,
        },
      },
      hoverAnimation: false,
      data: pieData,
      color: colorArray,
      silent: true, // 不响应鼠标事件
    };

    // 衍生品样式
    const yanshengpinClass = classnames({
      positiveYanshengpinContent: !_.isEmpty(yanshengpinData)
      && Number.parseFloat(yanshengpinData.maketVal) > 0,
      negativeYanshengpinContent: !_.isEmpty(yanshengpinData)
      && Number.parseFloat(yanshengpinData.maketVal) < 0,
      noneYanshengpinContent: _.isEmpty(yanshengpinData) ||
      Number.parseInt(yanshengpinData.maketVal, 10) === 0,
    });

    // 负债样式
    const fuzhaiClass = classnames({
      fuzhaiContent: !_.isEmpty(fuzhaiData) && Number.parseInt(fuzhaiData.maketVal, 10) !== 0,
      noneFuzhaiContent: _.isEmpty(fuzhaiData) ||
      Number.parseInt(fuzhaiData.maketVal, 10) === 0,
    });

    // 负债html
    const fuzhaiHtmlArray = [];
    /* eslint-disable */
    fuzhaiHtmlArray.push(<div key="fuzhai" className="fuzhai">
      <span className="fuzhaiLabel">负债</span>
      <span className={fuzhaiClass}>{`${!_.isEmpty(fuzhaiData)
        ? (Number.parseInt(fuzhaiData.maketVal, 10) === 0 ? '- -' : fuzhaiData.maketVal) : '- -'}`}</span>
    </div>);
    /* eslint-enable */

    // 衍生品html
    const yanshengpinHtmlArray = [];
    /* eslint-disable */
    yanshengpinHtmlArray.push(<div key="yanshengpin" className="yanshengpin">
      <span className="yanshengpinLabel">衍生品</span>
      <span className={yanshengpinClass}>{`${!_.isEmpty(yanshengpinData)
        ? (Number.parseInt(yanshengpinData.maketVal, 10) === 0 ? '--' : yanshengpinData.maketVal) : '- -'}`}</span>
    </div>);
    /* eslint-enable */

    // 是否展示负债和衍生品一横栏
    let showFuzhai = {};
    if ((fuzhaiData && Number.parseInt(fuzhaiData.maketVal, 10) !== 0) ||
      (yanshengpinData && Number.parseInt(yanshengpinData.maketVal, 10) !== 0)) {
      showFuzhai = classnames({
        displayNone: false,
        pieFooter: true,
      });
    } else {
      showFuzhai = classnames({
        displayNone: true,
        pieFooter: false,
      });
    }

    // 是否展示有数据饼图
    if (len === 0 || (len === 1 && assetData[0].categoryName.toString().indexOf('负债') !== -1) || assetTotal <= 0) {
      this.state.isShowPieData = false;
    } else {
      this.state.isShowPieData = true;
    }

    // 有数据饼图与无数据饼图样式
    let hasPieDataClass = {};
    let nonePieDataClass = {};
    if (this.state.isShowPieData === true) {
      hasPieDataClass = classnames({
        chartPieSection: true,
        displayBlock: true,
        displayNone: false,
      });
      nonePieDataClass = classnames({
        displayNone: true,
      });
    } else {
      nonePieDataClass = classnames({
        chartPieNoneSection: true,
        displayBlock: true,
        displayNone: false,
      });
      hasPieDataClass = classnames({
        displayNone: true,
      });
    }

    const nonePieOptions = {
      title: {
        text: '暂无数据',
        x: 'center',
        y: 'center',
      },
      height: PIE_NONEDATA_HEIGHT,
      width: PIE_NONEDATA_WIDTH,
    };

    const nonePieSeries = {
      name: '资产构成',
      type: 'pie',
      radius: ['40%', '60%'],
      center: ['50%', '50%'],
      label: {
        normal: {
          show: false,
        },
      },
      hoverAnimation: false,
      data: [
        {
          name: '暂无数据',
          value: 100,
        },
      ],
      color: ['#e6e5e5'],
      animation: false,
      // 不响应鼠标或触摸事件
      silent: true,
    };

    const nonePieArray = [];
    nonePieArray.push(
      <div key="noneData" className={nonePieDataClass}>
        <Chart {...nonePieOptions} className="chart-content">
          <Chart.Pie {...nonePieSeries} className="chart-pie" />
        </Chart>
      </div>,
    );

    const hasDataPieArray = [];
    hasDataPieArray.push(
      <div key="hasData" className={hasPieDataClass}>
        <Chart {...options} className="chart-content">
          <Chart.Pie {...series} className="chart-pie" />
        </Chart>
        <div className="assetDescription">
          {
            finalArrData
          }
        </div>
      </div>,
    );

    return (
      <div>
        <div>
          {hasDataPieArray}
          {nonePieArray}
          {this.state.isShowPieData ? '' : <div className="none-pie-data">暂无数据</div>}
        </div>
        <div className={showFuzhai}>
          {yanshengpinHtmlArray}
          {fuzhaiHtmlArray}
        </div>
      </div>
    );
  }
}
