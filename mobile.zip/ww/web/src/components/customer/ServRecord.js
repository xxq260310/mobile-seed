import React, { PropTypes } from 'react';
import { Picker, List, DatePicker, Modal } from 'antd-mobile';
import { autobind } from 'core-decorators';
import _ from 'lodash';
import moment from 'moment';
import 'moment/locale/zh-cn';
import './servRecord.less';

const DATE_FORMAT = 'YYYY年MM月DD日 HH:mm';

export default class ServRecord extends React.Component {
  static propTypes = {
    preContent: PropTypes.string,
    custName: PropTypes.string,
    actionType: PropTypes.string,
    serveDate: PropTypes.string, // 格式化后的日期字符串
    serviceRecord: PropTypes.string,
    serviceType: PropTypes.string,
    custFeedback: PropTypes.string,
    feedbackDetail: PropTypes.string,
    callDuration: PropTypes.string,
    serviceTypeOption: PropTypes.object,
    serveWay: PropTypes.array,
    changeForm: PropTypes.func.isRequired,
    push: PropTypes.func.isRequired,
    hasMission: PropTypes.bool,
    isDirectComplete: PropTypes.bool,
  };

  static defaultProps = {
    preContent: '',
    custName: '',
    actionType: '',
    serveDate: '',
    serviceRecord: '',
    serviceType: '',
    custFeedback: '',
    feedbackDetail: '',
    callDuration: '',
    serviceTypeOption: {},
    serveWay: [],
    isDirectComplete: false,
    hasMission: false,
  }

  constructor(props) {
    super(props);
    // props.serveDate： xxxx年xx月xx日 xx时xx分
    // moment('xxxx年xx月xx日 xx时xx分'): 得到的moment对象，是无效的
    // moment('xxxx年xx月xx日 xx时xx分', 'YYYY-MM-DD HH:mm'): 得到的moment对象，是有效的
    this.state = {
      serveDate: moment(props.serveDate, 'YYYY-MM-DD HH:mm').utcOffset(8),
      isShow: false,
    };

    const activityTypeOptions = [];
    _.forEach(
      props.serveWay,
      item => activityTypeOptions.push({
        label: item.value,
        value: item.key,
      }),
    );
    const typeOptions = this.parseOption(props.serviceTypeOption);
    this.options = { activityTypeOptions, ...typeOptions };
  }

  componentWillReceiveProps(nextProps) {
    const { serviceTypeOption } = nextProps;
    if (!!serviceTypeOption && serviceTypeOption !== this.props.serviceTypeOption) {
      const typeOptions = this.parseOption(serviceTypeOption);
      this.options = { ...this.options, ...typeOptions };
    }
  }

  parseOption(serviceTypeOption) {
    const { missionList = [] } = serviceTypeOption || {};
    const serviceOptions = [];
    let feedbackOptions = {};
    let detailOptions = {};
    _.forEach(
      missionList,
      (item) => {
        serviceOptions.push({
          label: item.parentClassName,
          value: `${item.id}`,
        });
        const feedbackArray = [];
        _.forEach(
          item.feedbackList,
          (feedback) => {
            feedbackArray.push({
              label: feedback.name,
              value: `${feedback.id}`,
            });
            const childArray = [];
            _.forEach(
              feedback.childList,
              (child) => {
                childArray.push({
                  label: child.name,
                  value: `${child.id}`,
                });
              },
            );
            detailOptions = { ...detailOptions, [feedback.id]: childArray };
          },
        );
        feedbackOptions = { ...feedbackOptions, [item.id]: feedbackArray };
      },
    );
    return { serviceOptions, feedbackOptions, detailOptions };
  }

  @autobind
  handleSelect(value, key) {
    const { serviceType, custFeedback, feedbackDetail, actionType } = this.props;
    const { detailOptions } = this.options;
    // 联动
    let selectItem = {};
    const selectValue = _.head(value);
    if (key === 'serviceType' && selectValue !== serviceType) {
      selectItem = { serviceType: selectValue, custFeedback: '', feedbackDetail: '' };
    } else if (key === 'custFeedback' && selectValue !== custFeedback) {
      selectItem = {
        custFeedback: selectValue,
        feedbackDetail: '',
        hasFeedbackDetail: !_.isEmpty(detailOptions[selectValue]),
      };
    } else if (key === 'feedbackDetail' && selectValue !== feedbackDetail) {
      selectItem = { feedbackDetail: selectValue };
    } else if (key === 'actionType' && selectValue !== actionType) {
      selectItem = { actionType: selectValue };
    }
    if (!_.isEmpty(selectItem)) {
      this.props.changeForm(selectItem);
    }
  }

  @autobind
  handleEdit() {
    const preContent = this.props.preContent || '';
    this.props.push(`/customer/recordEdit?editType=serviceRecord&&title=编辑服务记录&&preContent=${preContent}`);
  }

  @autobind
  handleServeDateChange(value) {
    this.setState({ serveDate: value });
    this.props.changeForm({
      serveDate: value.utcOffset(8).format(DATE_FORMAT),
    });
  }

  @autobind
  handleShowModal() {
    this.setState({ isShow: true });
  }

  @autobind
  handleModalClose() {
    this.setState({ isShow: false });
  }

  render() {
    const {
      preContent,
      custName,
      actionType,
      serveDate,
      serviceRecord,
      serviceType,
      custFeedback,
      feedbackDetail,
      hasMission,
      isDirectComplete,
    } = this.props;
    const {
      serviceOptions = [],
      activityTypeOptions = [],
      feedbackOptions = {},
      detailOptions = {},
    } = this.options || {};
    // 当前时间
    const nowDate = moment().locale('zh-cn').utcOffset(8);
    // 服务时间
    const formaterDate = isDirectComplete ? this.state.serveDate : serveDate;
    // 客户反馈
    const custFeedbackDom = _.isEmpty(feedbackOptions[serviceType]) ? (
      <List.Item arrow="horizontal" extra={'请选择'} onClick={this.handleShowModal}>客户反馈</List.Item>
    ) : (
      <Picker
        cols={1}
        extra="请选择"
        value={custFeedback ? [custFeedback] : []} // 如果为空，则赋值为空数组，酱紫，才会自动选择第一个
        data={feedbackOptions[serviceType] || []}
        onChange={(value) => { this.handleSelect(value, 'custFeedback'); }}
      >
        <List.Item arrow="horizontal">客户反馈</List.Item>
      </Picker>
    );
    return (
      <div>
        <List className="recordList">
          <List.Item extra={custName || '--'} className="noArrow">客户姓名</List.Item>
          {
            isDirectComplete ? (
              <Picker
                extra="请选择"
                cols={1}
                data={activityTypeOptions}
                value={actionType ? [actionType] : []} // 如果为空，则赋值为空数组，酱紫，才会自动选择第一个
                onOk={(value) => { this.handleSelect(value, 'actionType'); }}
              >
                <List.Item arrow="horizontal">服务方式</List.Item>
              </Picker>
            ) : (
              <List.Item extra={actionType || '--'} className="noArrow">服务方式</List.Item>
            )
          }
          {
            hasMission ? null : (
              <Picker
                extra="请选择"
                cols={1}
                data={serviceOptions}
                value={serviceType ? [serviceType] : []} // 如果为空，则赋值为空数组，酱紫，才会自动选择第一个
                onChange={(value) => { this.handleSelect(value, 'serviceType'); }}
              >
                <List.Item arrow="horizontal">服务类型</List.Item>
              </Picker>
            )
          }
          {
            isDirectComplete ? (
              <DatePicker
                mode="datetime"
                format={value => value.format(DATE_FORMAT)}
                onChange={this.handleServeDateChange}
                value={formaterDate}
                maxDate={nowDate}
              >
                <List.Item extra={formaterDate} arrow="horizontal">服务时间</List.Item>
              </DatePicker>
            ) : (
              <List.Item extra={formaterDate} className="noArrow">服务时间</List.Item>
            )
          }
          <List.Item arrow="horizontal" extra={`${preContent}${serviceRecord}` || '请填写'} onClick={this.handleEdit}>服务记录</List.Item>
          {
            !hasMission ? custFeedbackDom : null
          }
          {
            (!hasMission && !_.isEmpty(detailOptions[custFeedback])) ? (
              <Picker
                cols={1}
                extra="请选择"
                value={feedbackDetail ? [feedbackDetail] : []} // 如果为空，则赋值为空数组，酱紫，才会自动选择第一个
                data={detailOptions[custFeedback] || []}
                onChange={(value) => { this.handleSelect(value, 'feedbackDetail'); }}
              >
                <List.Item arrow="horizontal">反馈明细</List.Item>
              </Picker>
            ) : null
          }
        </List>
        <Modal
          title={'提示'}
          transparent
          maskClosable={false}
          visible={this.state.isShow}
          footer={[{ text: '确定', onPress: this.handleModalClose }]}
          onClose={this.handleModalClose}
        >
          <div>请先选择服务类型</div>
        </Modal>
      </div>
    );
  }
}
