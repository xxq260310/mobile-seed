
/**
 * @file customer/TaskListMenu.js
 * @author hongguangqing
 */

import React, { PropTypes, PureComponent } from 'react';
import ReactDOM from 'react-dom';
import { Flex, List, Checkbox, Button } from 'antd-mobile';
import _ from 'lodash';
import { autobind } from 'core-decorators';
import { connect } from 'react-redux';
import moment from 'moment';
import 'moment/locale/zh-cn';

import Toast from '../../components/common/Toast';
import { callPhone } from '../../utils/cordova';
import helper from '../../utils/helper';
import './taskListMenu.less';

const CheckboxItem = Checkbox.CheckboxItem;

const mapStateToProps = state => ({
  // 是否授权可以拨打电话
  canCall: state.global.canCall,
  empInfoData: state.global.empInfo,
  custMotList: state.customer.custMotList,
});

const mapDispatchToProps = {
  saveRecordPageNeedfulData: query => ({
    type: 'mission/saveRecordPageNeedfulDataSuccess',
    payload: query,
  }),
  saveBatchTaskMissionIdListSuccess: query => ({
    type: 'mission/saveBatchTaskMissionIdListSuccess',
    payload: query,
  }),
};

@connect(mapStateToProps, mapDispatchToProps)
export default class TaskListMenu extends PureComponent {
  static propTypes = {
    custMotList: PropTypes.object.isRequired,
    empInfoData: PropTypes.object.isRequired,
    title: PropTypes.object.isRequired,
    push: PropTypes.func.isRequired,
    checkAll: PropTypes.func.isRequired,
    itemAllCheck: PropTypes.bool.isRequired,
    location: PropTypes.object.isRequired,
    data: PropTypes.object.isRequired,
    isLoaded: PropTypes.bool.isRequired,
    checkedItems: PropTypes.array.isRequired,
    canCall: PropTypes.bool.isRequired,
    saveRecordPageNeedfulData: PropTypes.func.isRequired,
    saveBatchTaskMissionIdListSuccess: PropTypes.func.isRequired,
  };

  static defaultProps = {
    custMotList: {},
  };

  // 点击全选按钮
  @autobind
  onCheckAllChange(e) {
    const { checkAll } = this.props;
    const isChecked = e.target.checked;
    // 全选或者全不选传递函数
    checkAll(isChecked);
  }

  setHeight() {
    // 更新高度
    const rootElem = ReactDOM.findDOMNode(document.querySelectorAll('.freshable-container')[0]); // eslint-disable-line
    const height = Number.parseFloat(rootElem.clientHeight)
      - (1.6 * Number.parseFloat(document.documentElement.style.fontSize));
    rootElem.style.height = `${height}px`;
  }

  // 点击电话联系按钮
  @autobind
  handleTelephoneContactClick() {
    const { data: { cellphone } } = this.props;
    const { checkedItems, saveBatchTaskMissionIdListSuccess } = this.props;
    // 调用native发邮件
    if (!_.isEmpty(checkedItems)) {
      if (_.isEmpty(cellphone)) {
        Toast.fail('CRM系统中没有维护该客户的联系方式', 1);
        return;
      }
      // 将选中的任务mssnId组成一个数组
      const missionIdList = _.map(checkedItems, 'mssnId');
      // 将这个数组存在redux中用于刷新任务详情页面
      saveBatchTaskMissionIdListSuccess({ missionIdList });
      // 调用native拨打电话
      callPhone({ number: cellphone }, this.handleServiceRecord);
    } else {
      Toast.fail('您还未选择要处理的任务', 1);
    }
  }

  // 打完电话的回调，处理跳转服务记录相关数据等
  @autobind
  handleServiceRecord(callDuration) {
    const {
      push,
      location: { query: { custName, custId, custSor, custNumber, motTaskId } },
      saveRecordPageNeedfulData,
      checkedItems,
    } = this.props;
    // 批量选择的任务flowId数组
    const eventFlowIdList = _.map(checkedItems, 'flowId');
    // 服务时间
    this.zhNow = moment().locale('zh-cn').utcOffset(8);
    const serveDate = this.zhNow.format('YYYY年MM月DD日 HH:mm');
    // 保存服务记录页面所需要的数据到state中
    // serveWay: 服务方式,打电话就是电话，直接完成则服务方式在服务记录页面选择
    // serveDate: 服务日期，callDuration: 通话时长
    // eventFlowIdList: 有任务，传的任务flowId数组,无任务则不传
    saveRecordPageNeedfulData({
      custId,
      custType: custSor,
      custName,
      custNumber,
      serveWay: '电话',
      serveDate,
      callDuration,
      eventFlowIdList,
      motTaskId,
    });
    push({
      pathname: '/customer/Record',
      query: {
        custId,
        custType: custSor,
      },
    });
  }

  // 点击直接完成按钮
  @autobind
  handleDirectCompeletClick() {
    const { checkedItems } = this.props;
    const {
      push,
      location: { query: { custName, custId, custSor, custNumber, motTaskId } },
      saveRecordPageNeedfulData,
      saveBatchTaskMissionIdListSuccess,
    } = this.props;
    // 批量选择的任务flowId数组
    const eventFlowIdList = _.map(checkedItems, 'flowId');
    if (!_.isEmpty(checkedItems)) {
      // 将选中的任务mssnId组成一个数组
      const missionIdList = _.map(checkedItems, 'mssnId');
      // 将这个数组存在redux中用于刷新任务详情页面
      saveBatchTaskMissionIdListSuccess({ missionIdList });
      // 保存服务记录页面所需要的数据到state中
      // serveWay: 服务方式,直接完成则服务方式在服务记录页面选择
      // serveDate: 服务日期,击直接完成，取服务记录页面保存的时候日期
      // eventFlowIdList: 有任务，传的任务flowId数组,无任务则不传
      saveRecordPageNeedfulData({
        custId,
        custType: custSor,
        custName,
        custNumber,
        eventFlowIdList,
        motTaskId,
      });
      push({
        pathname: '/customer/Record',
        query: {
          custId,
          custType: custSor,
        },
      });
    } else {
      Toast.fail('您还未选择要处理的任务', 1);
    }
  }

  render() {
    const {
      isLoaded,
      canCall,
      title: { checkAllBtn, leftContent, rightContent },
    } = this.props;
    const isAndorid = helper.isAndorid();
    let completeBtnClassName = 'completeItem';
    // 授权并且是安卓用户才能显示电话联系按钮
    if (canCall && isAndorid) {
      completeBtnClassName = 'completeItem canCall';
    }
    return isLoaded
      ? (
        <Flex
          direction="row"
          justify="start"
          align="center"
          wrap="nowrap"
          className="taskListMenu"
        >
          <List>
            <CheckboxItem
              className="checkAll"
              checked={this.props.itemAllCheck}
              onChange={this.onCheckAllChange}
            >
              {checkAllBtn}
            </CheckboxItem>
          </List>
          <Button
            className={completeBtnClassName}
            type="primary"
            size="small"
            onClick={this.handleDirectCompeletClick}
          >
            {rightContent}
          </Button>
          {
            canCall && isAndorid
            ? <Button
              className="phoneItem"
              type="ghost"
              size="small"
              onClick={this.handleTelephoneContactClick}
            >
              {leftContent}
            </Button>
            : null
          }
        </Flex>
      )
      : null;
  }
}
