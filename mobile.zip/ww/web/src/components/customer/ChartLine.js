/**
 * @file customer/ChartLine.js
 *
 * @author xuxiaoqin
 */

import React, { PureComponent, PropTypes } from 'react';
import { autobind } from 'core-decorators';
import classnames from 'classnames';
import _ from 'lodash';
import Chart from '../chart';
import './chartLine.less';
import helper from '../../utils/helper';

// 测算出图表区域真是的范围
let LINE_HEIGHT = 0;
if (window.navigator.userAgent.toString().toLowerCase().indexOf('android') !== -1) {
  LINE_HEIGHT = `${helper.getRealSize(375).toString()}px`;
} else {
  LINE_HEIGHT = `${helper.getRealSize(315).toString()}px`;
}
// const LINE_HEIGHT = helper.getRealSize(315);
const LINE_WIDTH = '100%';
const PAINT_LINE_WIDTH = helper.getRealSize(1);
const AXIS_LABEL_FONT_SIZE = helper.getRealSize(14);
const YAXIS_LABEL_FONT_SIZE = helper.getRealSize(14);
const YAXIS_LABEL_MARGIN_NO_DATA = helper.getRealSize(-8);
const YAXIS_LABEL_MARGIN_HAS_DATA = helper.getRealSize(-16);

// y轴通用配置项
const yAxisOptions = {
  type: 'value',
  max: 1,
  min: -1,
  interval: 0.5,
  boundaryGap: false,
  axisLine: {
    show: false,
    onZero: false,
  },
  axisTick: {
    show: false,
  },
  axisLabel: {
    show: true,
    inside: true,
    margin: YAXIS_LABEL_MARGIN_HAS_DATA,
    textStyle: {
      color: '#666',
      fontSize: YAXIS_LABEL_FONT_SIZE,
    },
  },
  splitLine: {
    show: true,
    lineStyle: {
      color: ['#efefef'],
      width: PAINT_LINE_WIDTH,
    },
  },
};

// x轴通用配置项
const xAxisOptions = {
  type: 'category',
  boundaryGap: false,
  axisLine: {
    show: true,
    onZero: false,
    lineStyle: {
      color: '#efefef',
      width: PAINT_LINE_WIDTH,
    },
  },
  splitLine: {
    show: true,
    lineStyle: {
      color: ['#efefef'],
    },
  },
  axisTick: {
    show: false,
  },
  axisLabel: {
    show: true,
    textStyle: {
      color: '#999',
      fontSize: AXIS_LABEL_FONT_SIZE,
    },
    formatter: '{value}月',
  },
};

export default class ChartLineWidget extends PureComponent {

  static propTypes = {
    chartData: PropTypes.array,
  }

  static defaultProps = {
    chartData: [],
  }

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  @autobind
  rateFilter(val) {
    let value = val;
    if (value && value !== undefined) {
      if (value > 0) {
        value = `+${parseFloat(value).toFixed(2)}%`;
      } else {
        value = `${parseFloat(value).toFixed(2)}%`;
      }
      return value;
    } else if (value === 0) {
      return '0.00%';
    }
    return '--';
  }

  @autobind
  profitFilter(val) {
    let value = val;
    if (value && value !== undefined) {
      value = parseFloat(value).toFixed(2);
      let result = '';
      let counter = 0;
      value = (value || 0).toString();
      const numList = value.split('.');
      const intPart = numList[0].toString();
      for (let i = intPart.length - 1; i >= 0; i--) {
        counter++;
        result = intPart.charAt(i) + result;
        if (!(counter % 3) && i !== 0) { result = `,${result}`; }
      }
      result = result.replace('-,', '-');
      if (numList[1]) {
        if (value >= 0) {
          value = `+${result}.${numList[1]}`;
        } else {
          value = `${result}.${numList[1]}`;
        }
      } else {
        value = `${result}.00`;
      }
      return value;
    } else if (value === 0) {
      return '0.00';
    }
    return '--';
  }

  render() {
    let { chartData = [] } = this.props;
    const assetProfits = [];
    let minAssetProfit = 0 - 1;
    let maxAssetProfit = 1;
    let assetProfitInterval = 0.5;

    const assetProfitRates = [];
    let minAssetProfitRate = 0 - 1;
    let maxAssetProfitRate = 1;
    let assetProfitRateInterval = 0.5;

    let chartDataIsEmpty = false;
    // 如果是空数据的情况
    if (_.isEmpty(chartData)) {
      chartDataIsEmpty = true;
      chartData = [];
      const year = new Date().getFullYear();
      const month = new Date().getMonth() + 1;
      // 设置在无数据情况下的假数据
      const defaultChartItem = {
        assetProfit: 0,
        assetProfitRate: 0,
      };
      for (let i = 0; i < 6; i++) {
        let monthFullValue = '';
        let monthValue = 0;
        // 因为处理的时候，只需要展示月份，而不需要展示年份，
        // 因此只需要看月份数值是否是1，2,3,4,5
        // 其余6,7,8,9,10,11,12不需要处理
        if (month < 6 && (month - i) <= 0) {
          monthValue = ((month - i) + 12) < 10 ? `0${(month - i) + 12}` : (month - i) + 12;
        } else {
          monthValue = (month - i) < 10 ? `0${month - i}` : month - i;
        }
        monthFullValue = `${year}${monthValue}`;
        chartData.unshift(Object.assign({ month: monthFullValue }, defaultChartItem));
      }
    }

    // 1.从chartData中提取所有的收益数字
    // 2.从chartData中提取所有的收益率数字
    for (let i = 0; i < chartData.length; i++) {
      assetProfits.push(chartData[i].assetProfit);
      assetProfitRates.push(chartData[i].assetProfitRate);
    }
    // 提取出最大收益和最小收益
    maxAssetProfit = Math.max(...assetProfits);
    minAssetProfit = Math.min(...assetProfits);
    // 提取出最大收益率和最小收益率
    maxAssetProfitRate = Math.max(...assetProfitRates);
    minAssetProfitRate = Math.min(...assetProfitRates);

    // TODO: 此处需要对无数据的情况下进行处理,
    // 以及当所有月份的数字都是是0
    let chartItemProfitAllIsZero = false;
    if (chartDataIsEmpty) {
      chartItemProfitAllIsZero = true;
    }
    if (!chartDataIsEmpty) {
      let hasZeroNumber = 0;
      for (let i = 0; i < chartData.length; i++) {
        if (Object.is(chartData[i].assetProfit, 0)) {
          hasZeroNumber++;
        }
      }
      if (hasZeroNumber === 6) {
        chartItemProfitAllIsZero = true;
      }
    }

    if (chartDataIsEmpty || chartItemProfitAllIsZero) {
      maxAssetProfit = 1.00;
      minAssetProfit = -1.00;
      maxAssetProfitRate = 1.00;
      minAssetProfitRate = -1.00;
    }
    // 计算出最大收益和最小收益的与其中间值的间隔
    // 因为背景上需要有4个格子,所以计算间隔的时候需要除以4
    assetProfitInterval = (maxAssetProfit - minAssetProfit) / 4;
    // 计算出最大收益率和最小收益率与其中间值的间隔
    // TODO对在收益率都是0的情况下进行了除错设置
    if (maxAssetProfitRate === 0 && minAssetProfitRate === 0) {
      maxAssetProfitRate = 1.00;
      minAssetProfitRate = -1.00;
    }
    assetProfitRateInterval = (maxAssetProfitRate - minAssetProfitRate) / 4;

    // 新增一个配置项Margin
    // 目前需要靠左，靠右
    let firstYAxisLabel = YAXIS_LABEL_MARGIN_HAS_DATA;
    let secondYAxisLabel = YAXIS_LABEL_MARGIN_HAS_DATA;
    if (chartItemProfitAllIsZero) {
      // 无数据时候第一条Y轴上只有1位数
      // 目前根据新的要求进行修改
      firstYAxisLabel = YAXIS_LABEL_MARGIN_NO_DATA;
      secondYAxisLabel = YAXIS_LABEL_MARGIN_NO_DATA;
    }
    firstYAxisLabel = 0;
    secondYAxisLabel = 0;

    // 图表配置
    const options = {
      title: {
        text: '近6个月收益图',
      },
      grid: {
        bottom: '20%',
        top: '14%',
      },
      xAxis: {
        ...xAxisOptions,
        data: chartData.map(item => Number.parseInt(item.month.toString().substr(4, 2), 10)),
      },
      yAxis: [
        {
          ...yAxisOptions,
          min: minAssetProfit,
          max: maxAssetProfit,
          interval: assetProfitInterval,
          axisLabel: {
            ...yAxisOptions.axisLabel,
            formatter(value, index) {
              if (index === 1 || index === 3) {
                return '';
              }
              return parseFloat(value).toFixed(2);
            },
          },
        },
        {
          ...yAxisOptions,
          splitLine: {
            show: false,
          },
          axisLabel: {
            ...yAxisOptions.axisLabel,
            formatter(value, index) {
              if (index === 1 || index === 3) {
                return '';
              }
              if (value >= 0) {
                return `+${parseFloat(value).toFixed(2)}%`;
              }
              return `${parseFloat(value).toFixed(2)}%`;
            },
          },
          min: minAssetProfitRate,
          max: maxAssetProfitRate,
          interval: assetProfitRateInterval,
        },
      ],
      height: LINE_HEIGHT,
      width: LINE_WIDTH,
    };

    const seriesAreaStyle = {
      areaStyle: {
        normal: {
          color: '#ef9e49',
          opacity: '0.1',
        },
      },
    };

    // 图表数据显示配置
    const series = {
      name: '收益',
      type: 'line',
      smooth: true,
      data: chartData.map(item => item.assetProfit),
      lineStyle: {
        normal: {
          color: '#f8cc6d',
          width: helper.getRealSize(1),
        },
      },
      itemStyle: {
        normal: {
          opacity: 0,
        },
      },
    };

    // 如果无数据
    // 或者所有数据都是0,则图表上显示一条横线
    // 只需要判断数据中的是否全部为0
    // 现在又不需要了
    // if (!chartItemProfitAllIsZero) {
    _.defaultsDeep(series, seriesAreaStyle);
    // }
    // 对Options中的Y轴上的刻度进行位置偏移
    options.yAxis[0].axisLabel.margin = firstYAxisLabel;
    options.yAxis[1].axisLabel.margin = secondYAxisLabel;

    // 当月的收益以及收益率
    const thisMonthAssetProfitRate =
      this.rateFilter(chartData[chartData.length - 1].assetProfitRate);
    const thisMonthAssetProfit =
      this.profitFilter(chartData[chartData.length - 1].assetProfit);

    const assetProfitValue = classnames({
      monthNum: true,
      loss: !_.isEmpty(thisMonthAssetProfit) &&
        Number.parseFloat(thisMonthAssetProfit.replace('%', '')) < 0,
    });
    const assetProfitPercent = classnames({
      monthPercent: true,
      loss: !_.isEmpty(thisMonthAssetProfitRate) &&
        Number.parseFloat(thisMonthAssetProfitRate.replace('%', '')) < 0,
    });

    return (
      <div className="chart-line-section">
        <div className="infoNum">
          <div className={assetProfitPercent}>
            <div className="number">{thisMonthAssetProfitRate}</div>
            <div className="label">本月收益率</div>
          </div>
          <div className={assetProfitValue}>
            <div className="number">{thisMonthAssetProfit}</div>
            <div className="label">本月收益（元）</div>
          </div>
        </div>
        <Chart {...options} className="chart-content">
          <Chart.Line {...series} className="chart-line" />
        </Chart>
      </div>
    );
  }
}
