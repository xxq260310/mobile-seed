/**
 * @file customer/BasicList.js
 * @author liutingting(3171214926@qq.com)
 */

import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import { connect } from 'react-redux';
import moment from 'moment';
import 'moment/locale/zh-cn';
import { callPhone } from '../../utils/cordova';
import helper from '../../utils/helper';
import './contactItem.less';

const mapStateToProps = state => ({
  // 是否授权可以拨打电话
  canCall: state.global.canCall,
});

const mapDispatchToProps = {
  saveRecordPageNeedfulData: query => ({
    type: 'mission/saveRecordPageNeedfulDataSuccess',
    payload: query,
  }),
};

@connect(mapStateToProps, mapDispatchToProps)
export default class ContactItem extends PureComponent {

  static propTypes = {
    type: PropTypes.string.isRequired,
    data: PropTypes.array.isRequired,
    location: PropTypes.object.isRequired,
    empInfoData: PropTypes.object.isRequired,
    push: PropTypes.func.isRequired,
    canCall: PropTypes.bool.isRequired,
    saveRecordPageNeedfulData: PropTypes.func.isRequired,
  };

  static defaultProps = {
    type: '',
    data: [],
  };

  // 电话联系组件
  @autobind
  handleTelephoneContactClick(contactValue) {
    const { type, canCall } = this.props;
    const isAndorid = helper.isAndorid();
    // type为tel表示是电话，授权而且安卓手机才能拨打电话
    if (type === 'tel' && canCall && isAndorid) {
      // 调用native拨打电话
      callPhone({ number: contactValue }, this.handleServiceRecord);
    }
  }

  // 打完电话的回调，处理跳转服务记录相关数据等
  @autobind
  handleServiceRecord(callDuration) {
    const {
      push,
      location: { query: { custId, custName, custSor, custNumber } },
      saveRecordPageNeedfulData,
    } = this.props;
    // 服务时间
    this.zhNow = moment().locale('zh-cn').utcOffset(8);
    const serveDate = this.zhNow.format('YYYY年MM月DD日 HH:mm');
    // 保存服务记录页面所需要的数据到state中
    // serveWay: 服务方式,打电话就是电话，直接完成则服务方式在服务记录页面选择
    // serveDate: 服务日期，callDuration: 通话时长
    // eventFlowIdList: 无任务则不传
    saveRecordPageNeedfulData({
      custId,
      custType: custSor,
      custName,
      custNumber,
      serveWay: '电话',
      serveDate,
      callDuration,
    });
    push({
      pathname: '/customer/Record',
      query: {
        custId,
        custType: custSor,
      },
    });
  }

  render() {
    const { type, data: arr, canCall } = this.props;
    let contactTypeClassName = `info-item ${type}`;
    const isAndorid = helper.isAndorid();
    // 授权并且是安卓用户电话显示为蓝色可拨号状态，否则为灰色状态
    if (canCall && isAndorid) {
      contactTypeClassName = `info-item ${type} can-call`;
    }
    const rowItem = arr.map((item, index) => {
      if (this.props.type === 'address') {
        return (
          <li key={`${type}-${index + 1}`}>
            <p className={`info-item ${type}`}>
              <span>{`${(!item.province) ? '' : item.province}${(!item.city || item.city === item.province) ? '' : item.city}${(!item.address) ? '' : item.address}`}</span>
              <span>{`${(item.mainFlag === true) ? '(主要)' : ''}`}</span>
            </p>
          </li>);
      } else if (this.props.type === 'email') {
        return (
          <li key={`${type}-${index + 1}`}>
            <p className={`info-item ${type}`}>
              <span>{`${item.contactValue}${(item.mainFlag === true) ? '(主要)' : ''}`}</span>
            </p>
          </li>
        );
      }
      return (
        <li key={`${type}-${index + 1}`}>
          <p
            className={contactTypeClassName}
            onClick={() => this.handleTelephoneContactClick(item.contactValue)}
          >
            <span>{`${item.contactValue}${(item.mainFlag === true) ? '(主要)' : ''}`}</span>
          </p>
        </li>
      );
    });

    return (
      <ul className="item-list">
        { rowItem }
      </ul>
    );
  }
}
