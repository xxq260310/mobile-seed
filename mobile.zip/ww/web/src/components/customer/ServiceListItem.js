import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import moment from 'moment';
import 'moment/locale/zh-cn';

import Icon from '../common/Icon';

export default class ServiceItem extends PureComponent {

  static propTypes = {
    push: PropTypes.func,
    data: PropTypes.object,
  };

  static defaultProps = {
    push: () => { },
    data: {},
  }

  @autobind
  handleClick(rowId) {
    const { push, data: { custId } } = this.props;
    push({
      pathname: '/customer/serviceListDetail',
      query: {
        custId,
        rowId,
      },
    });
  }

  render() {
    const {
      subtypeCd = '--',
      serveTime = '--',
      serveOrigin = '--',
      rowID,
    } = this.props.data;
    const formatServeTime = moment(serveTime).utcOffset(8).format('YYYY年MM月DD日 HH:mm');
    const more = {
      className: 'moreIcon',
      type: 'more',
    };

    return (
      <div
        className="list-item"
        onClick={() => { this.handleClick(rowID); }}
      >
        <div className="list-item-head">
          <div className="head-content">
            <span>{subtypeCd}</span>
          </div>
          <div className="head-more">
            <Icon {...more} />
          </div>
        </div>
        <div className="list-item-main">
          <div className="main-left-content">
            <span>{formatServeTime}</span>
          </div>
          <div className="main-right-content">
            <span>{serveOrigin}</span>
          </div>
        </div>
      </div>
    );
  }
}
