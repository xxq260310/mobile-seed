/**
 * @file customer/EditDetail.js
 * @author xuxiaoqin
 */

import React, { PropTypes, PureComponent } from 'react';
import { createForm } from 'rc-form';
import { autobind } from 'core-decorators';
import { Checkbox } from 'antd-mobile';
import _ from 'lodash';
import { localConst } from '../../config';
import NavBar from '../common/NavBar';
import Icon from '../../components/common/Icon';
import preventDefaultAction from '../../components/common/preventDefaultAction';
import './editDetail.less';

const CheckboxItem = Checkbox.CheckboxItem;

const more = {
  className: 'more',
  type: 'more',
};

const EMPTY_OBJECT = {};
const TEL_TYPE = _.keys(localConst.TEL_TYPE_MAP);
const ADDRESS_TYPE = _.keys(localConst.ADDRESS_TYPE_MAP);

const EDIT_PER_CONTACT_DETAIL_ROUTE = '/customer/editPerContactDetail';

const PUSH_EDIT_TYPE_ROUTE = {
  pathname: '/customer/CustBasicEdit',
  query: {
    seltype: 'selRadio',
    navStyle: true,
  },
};

@createForm()
@preventDefaultAction()
export default class EditDetail extends PureComponent {

  static propTypes = {
    data: PropTypes.object,
    push: PropTypes.func.isRequired,
    type: PropTypes.string.isRequired,
    location: PropTypes.object.isRequired,
    form: PropTypes.object,
    title: PropTypes.string,
    leftClick: PropTypes.func,
    rightClick: PropTypes.func,
    global: PropTypes.object,
    replace: PropTypes.func,
    goBack: PropTypes.func.isRequired,
    updateGoBackLevel: PropTypes.func.isRequired,
    goBackCount: PropTypes.number,
    saveDataFunction: PropTypes.object.isRequired,
  }

  static defaultProps = {
    data: {},
    form: {},
    title: '',
    leftClick: () => { },
    rightClick: () => { },
    global: {},
    replace: () => { },
    goBackCount: 1,
  }

  constructor(props) {
    super(props);

    const { data } = props;

    this.state = {
      isLoading: false,
      isChecked: false,
      dataSource: data,
      isShowCheckBoxNode: false,
      telValue: data.telValue || '',
      addressValue: data.addressValue || '',
    };
  }

  componentWillReceiveProps(nextProps) {
    const { location: { query: preQuery } } = nextProps;
    const { location: { query } } = this.props;
    if (query !== preQuery) {
      const { editType = '', addressType = '', telType = '', province = '',
        city = '',
        provinceCd = '',
        cityCd = '',
        telValue = '' } = query;
      const { telValue: preTelValue } = preQuery;
      const { dataSource } = this.state;
      if (editType === 'addressType') {
        this.setState({
          dataSource: {
            ...dataSource,
            addressType,
          },
        });
      } else if (editType === 'telType') {
        this.setState({
          dataSource: {
            ...dataSource,
            telType,
          },
        });
      } else if (editType === 'address') {
        this.setState({
          dataSource: {
            ...dataSource,
            province,
            city,
            provinceCd,
            cityCd,
          },
        });
      } else if (telValue !== preTelValue) {
        this.setState({
          dataSource: {
            ...dataSource,
            telValue: preTelValue,
          },
        });
      }
    }
  }

  @autobind
  onCheckChange() {
    this.setState({
      isChecked: !this.state.isChecked,
    });
  }

  @autobind
  handleTelTypeClick(rowId, telType) {
    const { push } = this.props;

    const editTypeRoute = _.merge(PUSH_EDIT_TYPE_ROUTE, {
      query: {
        titleName: '编辑电话类型',
        editType: 'telType',
      },
      state: {
        selectValue: telType,
        options: TEL_TYPE,
        onSave: this.saveCallback,
      },
    });
    push(editTypeRoute);
  }

  @autobind
  handleAddresssClick(rowId, province, city, cityCd, provinceCd) {
    const { push } = this.props;

    const editTypeRoute = _.merge(PUSH_EDIT_TYPE_ROUTE, {
      query: {
        titleName: '编辑地址',
        editType: 'address',
      },
      state: {
        selectValue: {
          cityCd,
          provinceCd,
          province,
          city,
        },
        onSave: this.saveCallback,
      },
    });

    push(editTypeRoute);
  }


  @autobind
  handleAddressTypeClick(rowId, addressType) {
    const { push } = this.props;

    const editTypeRoute = _.merge(PUSH_EDIT_TYPE_ROUTE, {
      query: {
        titleName: '编辑地址类型',
        editType: 'addressType',
      },
      state: {
        selectValue: addressType,
        options: ADDRESS_TYPE,
        onSave: this.saveCallback,
      },
    });
    push(editTypeRoute);
  }

  /**
   * 保存的回调
   * @param {*} data
   */
  @autobind
  saveCallback(data) {
    const { selectValue, editType } = data || EMPTY_OBJECT;
    const { replace, location: { query: preQuery, state: preState }, goBack,
      updateGoBackLevel, saveDataFunction } = this.props;
    const commonQuery = {
      pathname: EDIT_PER_CONTACT_DETAIL_ROUTE,
      state: preState || saveDataFunction,
    };

    if (editType === 'addressType') {
      const { dataSource: { addressType } } = this.state;
      if (addressType !== selectValue) {
        replace({
          ...commonQuery,
          query: {
            ...preQuery,
            addressType: selectValue,
            editType,
          },
        });
        // 返回level +1
        updateGoBackLevel({ count: this.props.goBackCount + 1 });
      } else {
        goBack();
      }
    } else if (editType === 'telType') {
      const { dataSource: { telType } } = this.state;
      if (telType !== selectValue) {
        replace({
          ...commonQuery,
          query: {
            ...preQuery,
            telType: selectValue,
            editType,
          },
        });
        // 返回level +1
        updateGoBackLevel({ count: this.props.goBackCount + 1 });
      } else {
        goBack();
      }
    } else if (editType === 'address') {
      const { dataSource: {
        province: prevProvince,
        city: prevCity } } = this.state;
      const { province, city, cityCd, provinceCd } = selectValue;
      if (prevProvince !== province || prevCity !== city) {
        replace({
          ...commonQuery,
          query: {
            ...preQuery,
            province,
            city,
            provinceCd,
            cityCd,
            editType,
          },
        });
        // 返回level +1
        updateGoBackLevel({ count: this.props.goBackCount + 1 });
      } else {
        goBack();
      }
    }
  }

  @autobind
  handleNavBarClick(clickType) {
    const { leftClick, rightClick, location: { query: { custId,
      custNumber, custSor } } } = this.props;
    const { dataSource, isShowCheckBoxNode, isChecked, telValue, addressValue } = this.state;
    const newTelValue = telValue || '';
    const newAddressValue = addressValue || '';
    const {
      // 编辑类型
      type = '',
      rowId,
      // 电话类型
      telType = '',
      // 省
      province = '',
      // 市
      city = '',
      // 地址类型
      addressType = '',
      // 市代码
      cityCd,
      // 省代码
      provinceCd,
      // 原先的修改类型
      originType,
      // 是否是新增
      isAdd,
     } = dataSource || EMPTY_OBJECT;

    if (clickType === 'left') {
      leftClick({
        telType,
        telValue: newTelValue,
        addressType,
        addressValue: newAddressValue,
        province,
        provinceCd,
        city,
        cityCd,
        rowId,
        type,
        custId,
        custNumber,
        custSor,
        originType,
        goBackCount: this.props.goBackCount,
      });
    } else {
      let dataObject = {
        telType,
        telValue: newTelValue,
        addressType,
        addressValue: newAddressValue,
        province,
        provinceCd,
        city,
        cityCd,
        rowId,
        isAdd,
        originType,
        type,
        custId,
        custNumber,
        custSor,
        goBackCount: this.props.goBackCount,
      };
      if (isShowCheckBoxNode && isAdd === 'Y') {
        dataObject = {
          ...dataObject,
          mainFlag: isChecked,
        };
      }
      rightClick(
        dataObject,
      );
    }
  }

  @autobind
  handleInputBlur(type, event) {
    const value = event.target.value;
    const { replace, location: { query: preQuery, state: preState } } = this.props;
    const commonQuery = {
      pathname: EDIT_PER_CONTACT_DETAIL_ROUTE,
      state: preState,
    };
    const { dataSource: { telValue, addressValue } } = this.state;
    if (type === 'tel' && telValue !== value) {
      replace({
        ...commonQuery,
        query: {
          ...preQuery,
          telValue: value,
        },
      });
    }
    if (type === 'address' && addressValue !== value) {
      replace({
        ...commonQuery,
        query: {
          ...preQuery,
          addressValue: value,
        },
      });
    }
    // 返回level 不用+1
    // 因为replace route与当前route一样
    // updateGoBackLevel({ count: this.props.goBackCount + 1 });
  }

  /**
   * 处理电话输入框的change事件
   * @param {*} event
   */
  @autobind
  telInputChange(event) {
    const { dataSource: { telType } } = this.state;
    // 设置电话号码最大长度
    let maxLen = 20;
    if (telType === '手机') {
      maxLen = 11;
    } else if (telType === '住宅' || telType === '单位') {
      maxLen = 12;
    } else {
      maxLen = 20;
    }
    const telRegxp = new RegExp(`^[0-9]{0,${maxLen}}$`); //eslint-disable-line
    const value = event.target.value;

    if (!value) {
      this.setState({
        telValue: '',
      });
    } else if (telRegxp.test(value)) {
      this.setState({
        telValue: value,
      });
    }
  }

  @autobind
  addressInputChange(event) {
    // 设置地址最大长度
    const maxLen = 50;
    const value = event.target.value;

    if (!value) {
      this.setState({
        addressValue: '',
      });
    } else if (value.length <= maxLen) {
      this.setState({
        addressValue: value,
      });
    }
  }

  /**
   * 格式化城市
   * @param {*} province
   * @param {*} provinceCd
   * @param {*} city
   */
  formatCity(province, provinceCd, city) {
    const specialProvinceCdArray = ['DF02', 'DF03', 'DF18', 'DF24', 'DF28', 'DF29', 'DF30'];
    return `${province}${_.includes(specialProvinceCdArray, provinceCd) ? '' : city}`;
  }

  renderNode() {
    const { type } = this.props;
    const { dataSource, telValue, addressValue } = this.state;

    if (type === 'tel') {
      return (
        <div className="tel-section">
          <div className="type">
            <div className="left-section">电话类型</div>
            <div className="right-section" onClick={() => this.handleTelTypeClick(dataSource.rowId, dataSource.telType)}>
              <div>{dataSource.telType || '请选择'}</div>
              <Icon {...more} />
            </div>
          </div>
          <div className="solid-separator" />
          <div className="content">
            <div className="left-section">电话号码</div>
            <div className="right-section">
              <input
                type="tel"
                placeholder="请填写"
                onBlur={event => this.handleInputBlur('tel', event)}
                onChange={event => this.telInputChange(event)}
                value={telValue || ''}
                autoFocus
              />
            </div>
          </div>
          <div className="solid-separator" />
        </div>
      );
    }

    if (type === 'address') {
      return (
        <div className="address-section">
          <div className="type-section">
            <div className="left-section">地址类型</div>
            <div onClick={() => this.handleAddressTypeClick(dataSource.rowId, dataSource.addressType)} className="right-section">
              <div ref={ref => (this.addressTypeElem = ref)}>{dataSource.addressType || '请选择类型'}</div>
              <Icon {...more} />
            </div>
          </div>
          <div className="city-section">
            <div className="left-section">所在城市</div>
            <div
              className="right-section"
              onClick={() =>
                this.handleAddresssClick(
                  dataSource.rowId,
                  dataSource.province,
                  dataSource.city,
                  dataSource.cityCd,
                  dataSource.provinceCd)}
            >
              <div>{this.formatCity(dataSource.province, dataSource.provinceCd, dataSource.city) || '请选择城市'}</div>
              <Icon {...more} />
            </div>
          </div>
          <div className="detail-section">
            <div className="left-section">街道</div>
            <div className="right-section">
              <input
                placeholder="请输入详细地址"
                onBlur={event => this.handleInputBlur('address', event)}
                onChange={event => this.addressInputChange(event)}
                value={addressValue || ''}
                autoFocus
              />
            </div>
          </div>
        </div>
      );
    }
    return null;
  }

  render() {
    const { type, title } = this.props;
    const { isShowCheckBoxNode, isChecked, dataSource, dataSource: { isAdd } } = this.state;
    if (!type || !dataSource) {
      return null;
    }

    return (
      <div>
        <NavBar
          iconName={false}
          leftContent={<div className="left" onClick={() => this.handleNavBarClick('left')}>取消</div>}
          rightContent={<div className="right-btn" onClick={() => this.handleNavBarClick('right')}>保存</div>}
        >{title}
        </NavBar>

        <div className="edit-contact-detail-section">
          {this.renderNode()}
          {isShowCheckBoxNode && isAdd === 'Y' ? <div className="radioSection">
            <CheckboxItem
              checked={isChecked}
              onClick={() => this.onCheckChange()}
            >
              {'设为主要'}
            </CheckboxItem>
          </div> : null}
        </div>
      </div>
    );
  }
}
