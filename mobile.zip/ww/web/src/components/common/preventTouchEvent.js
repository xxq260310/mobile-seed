/**
 * @file common/preventTouchEvent.js
 *  解决SwipeAction横向滑动的时候，纵向也滑动的问题
 * @author maoquan(maoquan@htsc.com)
 */

import React, { PureComponent } from 'react';
import { autobind } from 'core-decorators';
import _ from 'lodash';

export default (options = {}) => (ComposedComponent) => {
  const { container = '.swipe-container' } = options;

  class HOCComponent extends PureComponent {

    componentDidMount() {
      this.bindTouchEvents();
    }

    componentDidUpdate() {
      this.bindTouchEvents();
    }

    componentWillUnmount() {
      this.unbindTouchEvents();
    }

    bindTouchEvents() {
      const elem = document.querySelector(container);
      if (elem && !this.boundEvents) {
        // 确保只绑定一次
        this.boundEvents = true;
        elem.addEventListener(
          'touchstart',
          this.handleTouchStart,
          false,
        );
        elem.addEventListener(
          'touchmove',
          this.handleTouchMove,
          false,
        );
      }
    }

    unbindTouchEvents() {
      const elem = document.querySelector(container);
      if (elem) {
        elem.removeEventListener(
          'touchstart',
          this.handleTouchStart,
          false,
        );
        elem.removeEventListener(
          'touchmove',
          this.handleTouchMove,
          false,
        );
      }
    }

    shouldPreventTouchEvent() {
      const isSwiping = _.some(
        document.querySelectorAll('.am-swipe-actions'),
        elem => parseInt(elem.style.width, 10) > 0,
      );
      return isSwiping;
    }

    @autobind
    handleTouchStart(e) {
      if (this.shouldPreventTouchEvent()) {
        e.stopPropagation();
        e.preventDefault();
        return false;
      }
      return true;
    }

    @autobind
    handleTouchMove(e) {
      if (this.shouldPreventTouchEvent()) {
        e.stopPropagation();
        e.preventDefault();
        return false;
      }
      return true;
    }

    render() {
      return (
        <ComposedComponent {...this.props} />
      );
    }
  }

  return HOCComponent;
};
