import React, { PureComponent, PropTypes } from 'react';
import { autobind } from 'core-decorators';
import classnames from 'classnames';
import _ from 'lodash';
import './inputComponent.less';

class InputComponent extends PureComponent {

  static propTypes = {
    placeholder: PropTypes.string,
    type: PropTypes.string,
    clear: PropTypes.bool,
    autoFocus: PropTypes.bool,
    value: PropTypes.string.isRequired,
    getInputValue: PropTypes.func.isRequired,
  }

  static defaultProps = {
    placeholder: '',
    type: 'text',
    clear: false,
    autoFocus: false,
  };

  constructor(props) {
    super(props);
    this.state = {
      value: props.value || '',
      isFocus: false,
      isShowClear: props.clear,
    };
  }

  componentDidMount() {
    const { autoFocus, getInputValue } = this.props;
    if (autoFocus) {
      this.inputItem.focus();
    }
    getInputValue(this.state.value);
  }

  componentWillUnmount() {
    if (this.debounceTimeout) {
      clearTimeout(this.debounceTimeout);
      this.debounceTimeout = null;
    }
  }

  @autobind
  handleChange(e) {
    const value = e.target.value;
    const { getInputValue, type } = this.props;
    if (type && _.includes(['tel', 'number'], type) && /\D/.test(value)) {
      return;
    }
    this.setState({
      value,
    }, () => {
      getInputValue(this.state.value);
    });
  }

  @autobind
  handleClear() {
    console.log('clear');
    const { getInputValue } = this.props;
    this.setState({
      value: '',
    }, () => {
      getInputValue(this.state.value);
    });
  }

  @autobind
  handleFocus() {
    if (this.debounceTimeout) {
      clearTimeout(this.debounceTimeout);
      this.debounceTimeout = null;
    }
    this.setState({
      isFocus: true,
    });
  }

  @autobind
  handleBlur() {
    this.debounceTimeout = setTimeout(() => {
      this.setState({
        isFocus: false,
      });
    }, 200);
  }

  render() {
    const { placeholder, type } = this.props;
    const { value, isShowClear, isFocus } = this.state;
    const clearClass = classnames({
      'am-input-clear': true,
      block: isShowClear && isFocus && value,
    });

    return (
      <div className="am-list-item am-input-item">
        <div className="am-input-control">
          <input
            ref={ref => (this.inputItem = ref)}
            type={type}
            value={value}
            placeholder={placeholder}
            onChange={this.handleChange}
            onFocus={this.handleFocus}
            onBlur={this.handleBlur}
          />
        </div>
        <div
          className={clearClass}
          onClick={this.handleClear}
        />
      </div>
    );
  }
}

export default InputComponent;
