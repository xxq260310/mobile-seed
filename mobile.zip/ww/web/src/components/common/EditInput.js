/**
 * @file customer/Edit.js
 *
 * 修改页面中url中传入的参数：
 *             defaultValue >>> 修改时传的输入框中默认值    title >>> 顶部导航显示的标题文字
 *             type >>> 输入框的类型，传入num时 <input type=num />  ,不传默认 text
 *
 * 添加页面中url穿的参数：
 *             option=add： 上一个页面是一个添加信息的页面，请求是在上一个页面发送
 *             opObj：从联系人姓名点击进入编辑页面，opObj=name, 用来区分回填信息的
 *             defaultValue >>> 修改时传的输入框中默认值    title >>> 顶部导航显示的标题文字
 *             type >>> 输入框的类型，传入num时 <input type=num />  ,不传默认 text
 *             noGobackHint  点击返回是否提示
 *
 * @author wangjunjun
 */

import React, { PureComponent, PropTypes } from 'react';
import { Modal } from 'antd-mobile';
import { autobind } from 'core-decorators';
import { createForm } from 'rc-form';

import InputComponent from './InputComponent';
import NavBar from './NavBar';
import Toast from './Toast';
import Icon from './Icon';

import './editinput.less';

const alert = Modal.alert;

function showMessage(msg) {
  Toast.show(msg, 1);
}

@createForm()
export default class EditInput extends PureComponent {

  static propTypes = {
    goBack: PropTypes.func.isRequired,
    push: PropTypes.func.isRequired,
    form: PropTypes.object.isRequired,
    location: PropTypes.object.isRequired,
    rightClick: PropTypes.func,
  }

  static defaultProps = {
    rightClick: () => { },
  }

  constructor(props) {
    super(props);
    this.state = {
      value: '',
    };
  }

  @autobind
  getInputValue(value) {
    console.log('getInputValue', value);
    this.setState({
      value,
    });
  }

  @autobind
  handleLeftClick() {
    const { value } = this.state;
    const {
      location: { query: { defaultValue, noGobackHint } },
      goBack,
    } = this.props;
    if (decodeURIComponent(defaultValue) === value) {
      goBack();
      return;
    }
    if (noGobackHint === 'true') {
      goBack();
      return;
    }
    alert('提示', '确认放弃本次编辑内容？', [
      { text: '否', onPress: () => console.log('cancel') },
      { text: '是', onPress: () => goBack() },
    ]);
  }

  @autobind
  handleRightClick() {
    const { value } = this.state;
    const {
      rightClick,
    } = this.props;
    console.log('rightClick', value);
    if (!value) {
      showMessage('不能为空');
      return;
    }
    rightClick(value);
  }

  renderEntryNode() {
    const {
      location: { query: { type, defaultValue } },
    } = this.props;
    let node;
    switch (type) {
      case 'text':
        node = (
          <InputComponent
            getInputValue={this.getInputValue}
            value={decodeURIComponent(defaultValue)}
            autoFocus
            clear
          />
        );
        break;
      case 'tel':
        node = (
          <InputComponent
            getInputValue={this.getInputValue}
            value={decodeURIComponent(defaultValue)}
            type="tel"
            autoFocus
            clear
          />
        );
        break;
      default:
        node = (
          <InputComponent
            getInputValue={this.getInputValue}
            value={decodeURIComponent(defaultValue)}
            autoFocus
            clear
          />
        );
    }
    return node;
  }

  render() {
    const {
      location: {
        query: { title, option, noGobackHint },
      },
    } = this.props;

    return (
      <div className="page-editInput">
        <NavBar
          iconName={false}
          leftContent={
            noGobackHint === 'true' ?
              <Icon type={'fanhui'} onClick={this.handleLeftClick} />
              :
              <div className="btn-cancel" onClick={this.handleLeftClick}>取消</div>
          }
          rightContent={
            <div className="btn-save" onClick={this.handleRightClick}>
              {option === 'add' ? '完成' : '保存'}
            </div>
          }
        >
          {decodeURIComponent(title)}
        </NavBar>
        <div style={{ marginTop: '0' }}>{this.renderEntryNode()}</div>
      </div>
    );
  }
}
