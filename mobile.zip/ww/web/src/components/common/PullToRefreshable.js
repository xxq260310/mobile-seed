/**
 * @file common/PullToRefreshable.js
 *  下拉刷新修饰组件
 * @author maoquan(maoquan@htsc.com)
 */

import React, { PropTypes, PureComponent } from 'react';
import { autobind } from 'core-decorators';
import events from 'events';
import cordova from '../../utils/cordova';
import helper from '../../utils/helper';
import PullToRefresh from './PullToRefresh';
import Message from '../message';
import Icon from '../common/Icon';

const PREFIX_CLS = 'am-refresh-control';
const DISTANCE_TO_REFRESH = helper.getRealSize(100);

export const renderIcon = () => (
  <div>
    <div className={`${PREFIX_CLS}-pull`}>
      <Icon type="xiajiantou" /> 下拉刷新
    </div>
    <div className={`${PREFIX_CLS}-release`}>
      <Icon type="shangjiantou" /> 释放更新
    </div>
  </div>
);

export const renderLoading = () => (
  <div>
    <Icon type="loading" />
    <span>加载中...</span>
  </div>
);

// 设置下拉触发的距离
export const distanceToRefresh = DISTANCE_TO_REFRESH;

export default (ComposedComponent) => {
  const EventEmitter = events;
  // new一个事件监听，用来发射刷新事件
  const refreshEmitter = new EventEmitter();

  class RefreshableComponent extends PureComponent {

    static propTypes = {
      // 刷新方法
      refresh: PropTypes.func,
      // 控制loading状态显示
      isLoading: PropTypes.bool,
      location: PropTypes.object,
      refreshData: PropTypes.object,
    }

    static defaultProps = {
      isLoading: false,
      location: {},
      refresh: () => { },
      refreshData: undefined,
    }

    @autobind
    loadingFunction() {
      const { location: { query }, refresh, refreshData } = this.props;
      refresh(refreshData || query, false);
      // 上报刷新页面log
      refreshEmitter.emit('reportRefresh');
    }

    render() {
      const { isLoading } = this.props;
      const isConnected = cordova.isConnected();

      return (
        <PullToRefresh
          prefixCls={PREFIX_CLS}
          loadingFunction={this.loadingFunction}
          isLoading={isLoading}
          icon={renderIcon()}
          loading={renderLoading()}
          distanceToRefresh={DISTANCE_TO_REFRESH}
          className="freshable-container"
          contentClassName="freshable"
          ref={ref => (this.ptr = ref)}
        >
          {!isConnected ? (
            <Message
              type={'network'}
              height={helper.getAvailableHeight()}
            />
          ) : (
            <ComposedComponent
              {...this.props}
              refreshControl={this.ptr}
              eventEmitter={refreshEmitter}
            />
            )}
        </PullToRefresh>
      );
    }
  }

  return RefreshableComponent;
};
