/**
 * components/common/Toast.js
 * @author maoquan(maoquan@htsc.com)
 */
import { Toast } from 'antd-mobile';

Toast.fail = Toast.offline;

export default Toast;
