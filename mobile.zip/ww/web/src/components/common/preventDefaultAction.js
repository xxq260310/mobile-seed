/**
 * 解决ios机器下，键盘弹起来的时候，滑动页面，页面会触发滚动现象
 */
import React, { PureComponent } from 'react';
import { autobind } from 'core-decorators';
import { hideKeyboard } from '../../utils/helper';

export default (options = {}) => (ComposedComponent) => {
  const { container = 'body' } = options;
  const bodyElem = document.querySelector(container);
  class HOCComponent extends PureComponent {
    componentDidMount() {
      bodyElem.addEventListener('touchstart', hideKeyboard, false);

      // 阻止冒泡和默认事件，不然手指放在input上，然后往上滑动
      // 依旧可以滑动，因为冒泡了，导致input所在的父容器失去控制，
      // 随着touchmove往上移动
      bodyElem.addEventListener('touchmove', this.preventDefaultAction, false);
    }

    componentWillUnmount() {
      bodyElem.removeEventListener('touchmove', this.preventDefaultAction, false);
      bodyElem.removeEventListener('touchstart', hideKeyboard, false);
    }

    @autobind
    preventDefaultAction(event) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
    }

    render() {
      return (
        <ComposedComponent {...this.props} />
      );
    }
  }

  return HOCComponent;
};
