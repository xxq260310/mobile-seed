/**
 * @fileOverview common/PopMask.js
 * @author sunweibin
 */
import React, { PropTypes } from 'react';

function PopMask(props) {
  const { height, show } = props;

  return (
    <div
      id="select-pop-mask"
      className="pop-mask"
      style={{
        position: 'absolute',
        zIndex: 1,
        backgroundColor: 'rgba(0,0,0,0.5)',
        width: '100%',
        height: show ? height : '0',
      }}
    />
  );
}

PopMask.propTypes = {
  height: PropTypes.number.isRequired,
  show: PropTypes.bool,
};

PopMask.defaultProps = {
  height: '1000px',
  show: false,
};

export default PopMask;
