/**
 th* @file common/NavBarable.js
 *  导航条修饰组件
 * @author maoquan(maoquan@htsc.com)
 */

import React, { PropTypes, PureComponent } from 'react';
import ReactDOM from 'react-dom';
import { autobind } from 'core-decorators';
import classnames from 'classnames';

import NavBar from './NavBar';
import helper from '../../utils/helper';
import './withNavBar.less';

export default options => (ComposedComponent) => {
  const { title, hasBack, backUrl, layout = true, isHidden = false } = options;
  class NavBarComponent extends PureComponent {
    static propTypes = {
      title: React.PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.object,
      ]),
      queryData: PropTypes.object,
      goLastPage: PropTypes.func,
    }

    static defaultProps = {
      title: '',
      queryData: {},
      goLastPage: () => { },
    }

    static contextTypes = {
      router: PropTypes.object.isRequired,
    }

    componentDidMount() {
      this.layout();
    }

    componentDidUpdate() {
      this.layout();
    }

    @autobind
    handleLeftClick() {
      const { queryData: { isHasHistory = 'Y' }, goLastPage } = this.props;
      const { router } = this.context;
      if (isHasHistory === 'N') {
        goLastPage();
        return;
      }

      // 根据我们业务场景(从推送通知直接跳转到某个页面)
      // 暂时只支持没有历史记录情况下的backUrl
      if (backUrl && (window.history.length === 1)) {
        router.push(backUrl);
      } else {
        router.goBack();
      }
    }

    layout() {
      if (this.navBar && this.container && layout) {
        const navBar = ReactDOM.findDOMNode(this.navBar); // eslint-disable-line
        const container = ReactDOM.findDOMNode(this.container); // eslint-disable-line
        const tabBarElem = document.querySelector('.am-tab-bar-bar');
        const menuElem = document.querySelector('.taskMenu');
        let tabBarHeight = 0;
        if (tabBarElem) {
          tabBarHeight = helper.hasClass(tabBarElem, 'am-tab-bar-bar-hidden')
            ? 0 : tabBarElem.offsetHeight;
        }
        let menuHeight = 0;
        if (menuElem) {
          menuHeight = menuElem.offsetHeight;
        }
        container.style.height = `
          ${document.documentElement.clientHeight - navBar.offsetHeight - tabBarHeight - menuHeight}px
        `;
      }
    }

    render() {
      const { title: propsTitle, queryData: { isShowNavBar } } = this.props;
      const isHiddenClass = classnames({
        hidden: isHidden && isShowNavBar !== 'Y',
        navbar: true,
      });
      return (
        <div>
          <NavBar
            className={isHiddenClass}
            ref={ref => (this.navBar = ref)}
            iconName={hasBack ? 'iconfontfanhui2' : false}
            onLeftClick={hasBack ? this.handleLeftClick : () => { }}
          >{propsTitle || title}</NavBar>
          <ComposedComponent
            ref={ref => (this.container = ref)}
            {...this.props}
          />
        </div>
      );
    }
  }
  return NavBarComponent;
};
