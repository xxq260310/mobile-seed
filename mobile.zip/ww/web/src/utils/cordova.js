/**
 * @file utils/cordova.js
 *  封装app提供的cordova相关方法
 * @author maoquan(maoquan@htsc.com)
 */

import { routerRedux } from 'dva/router';
import helper from './helper';

const isAndorid = helper.isAndorid();

function exec(method, ...args) {
  try {
    MCRMCordovaPlugin[method].apply(null, args);
  } catch (e) {
    console.log(e);
  }
}

const androidBackBtnDispatchers = [];
let hasRegisteredBackBtnListener = false;

function recoverBackBtnDefault() {
  if (isAndorid) {
    hasRegisteredBackBtnListener = false;
    if (navigator.app && navigator.app.overrideBackbutton) {
      navigator.app.overrideBackbutton(false);
    }
  }
}

/**
 * 全局处理返回键
 */
function handleBackbutton() {
  if (isAndorid) {
    if (location.pathname.split('/').length <= 2) {
      exec('exitApp');
    }
    recoverBackBtnDefault();
  }
}
// 必须添加全局的返回键处理
androidBackBtnDispatchers.push(handleBackbutton);

function triggerBackBtn() {
  if (isAndorid) {
    let dispatcher = null;
    const len = androidBackBtnDispatchers.length;
    if (len > 1) {
      dispatcher = androidBackBtnDispatchers.pop();
    } else {
      dispatcher = androidBackBtnDispatchers[0];
    }
    dispatcher();
  }
}

function registerBackBtnListener() {
  // 此处需要对Andorid机器进行处理
  if (isAndorid) {
    if (navigator.app && navigator.app.overrideBackbutton) {
      navigator.app.overrideBackbutton(true);
    }
    document.addEventListener('backbutton', triggerBackBtn, false);
    hasRegisteredBackBtnListener = true;
  }
}

function addBackBtnDispatcher(fn) {
  // 在需要修改backBtn行为时候，需要重新注册
  // 如果已经注册，防止多次注册
  if (isAndorid) {
    if (!hasRegisteredBackBtnListener) {
      registerBackBtnListener();
    }
    androidBackBtnDispatchers.push(fn);
  }
}

function removeBackBtnDispatcher() {
  if (isAndorid) {
    const len = androidBackBtnDispatchers.length;
    if (len > 1) {
      androidBackBtnDispatchers.splice(-1, 1);
    }
  }
}


const cordova = {
  navToLogin() {
    exec('navToLogin');
  },
  sendEmail(args) {
    exec('sendEmail', args);
  },
  processMotTask(args) {
    exec('processMotTask', args);
  },
  nativeGoBack(args) {
    exec('nativeGoBack', args);
  },
  setNothing(args) {
    exec('setSoftInputModeAdjustNothing', args);
  },
  setResize(args) {
    exec('setSoftInputModeAdjustResize', args);
  },
  setGestureEnable(args) {
    exec('setGestureEnable', args);
  },
  getGestureEnable(callback) {
    exec('getGestureEnable', undefined, (obj) => {
      const { gestureSwitch, hasGesture } = obj;
      callback({
        // native传入的是字符串
        gestureSwitch: gestureSwitch === 'true',
        hasGesture: hasGesture === 'true',
      });
    });
  },
  resetGesture(args) {
    exec('resetGesture', args);
  },
  callPhone(args, callback) {
    exec('callPhone', args, callDuration => callback(callDuration));
  },
  /**
   * 使用native webview打开新页面
   */
  openUrl(args) {
    exec('openUrl', args);
  },

  /**
   * 退出APP，仅安卓有效
   * @return {[type]} [description]
   */
  // exitApp() {
  //   exec('exitApp');
  // },

  /**
   * 初始化暴露给native的方法
   * @param  {object} store app.store
   */
  initNativeMethod(store) {
    window.navToUrl = (url) => {
      store.dispatch(routerRedux.push(url));
    };
    window.dispatch = (action) => {
      store.dispatch(action);
    };
    window.go = (num) => {
      store.dispatch(routerRedux.go(num));
    };
    window.getState = () => (store.getState());
  },

  /**
   * 判断网络是否可用
   * @return {Boolean} 网络是否可用
   */
  isConnected() {
    const connection = navigator.connection || {};
    return connection.type !== 'none';
  },

  addBackbuttonListener: addBackBtnDispatcher,

  removeBackbuttonListener: removeBackBtnDispatcher,

  registerBackBtnListener,
  // addBackbuttonListener() {
  //   // 安卓返回键
  //   document.addEventListener('backbutton', triggerBackBtn, false);
  // },

  // removeBackbuttonListener() {
  //   // 安卓返回键
  //   document.removeEventListener('backbutton', handleBackbutton, false);
  // },
};


export default cordova;
