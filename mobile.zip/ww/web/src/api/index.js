import apiCreator from '../utils/apiCreator';

const api = apiCreator();

export default {

  /**
   * 暴露api上的几个底层方法: get / post / setAuthInfo
   */
  ...api,

  /**
   * 获取系统常量
   */
  getSystemConst: () => api.post('/groovy/common/codeMatch'),

  /**
   * 获取我的首页业绩
   */
  getMineAchievement: query => api.post('/groovy/emp/mine', query),

  /**
   * 保存服务实施的记录
   */
  saveServiceImplementRecord: query => api.post('/groovy/emp/processMot', query),

  /**
   * 添加服务记录中 服务类型
   */
  getServiceType: query => api.post('/groovynoauth/fsp/campaign/mot/queryMissionList2', query),
  /**
   * 添加服务记录
   */
  addCommonServeRecord: query => api.post('/groovynoauth/cust/saveBatchedServiceRecords', query),
  /**
   * 获取服务记录列表
   */
  getServiceRecordList: query => api.post('/groovynoauth/fsp/cust/service/queryAllChannelServiceRecord', query),

  /**
   * 获取字典信息
   */
  getDictionary: query => api.post('/groovynoauth/fsp/dictionary', query),
  /**
   * 获取用户信息
   */
  getEmpInfo: () => api.post('/groovy/emp/empInfo'),

  /**
   * 获取产品详情
   */
  getProductDetail: ({ productId, productCode, categoryCode, directoryCode }) => api.post('/groovy/product/productDetail', { productId, productCode, categoryCode, directoryCode }),

  /**
   * 获取客户详细信息
   * { keywords, page, custQueryType }
   */
  searchCustomer: query => api.post('/groovy/cust/custList', query),

  /**
   * 查询客户基本信息
   */
  getCustBasic: ({ custNumber, custSor, custId }) => api.post('/groovy/cust/custBaseInfo', { custNumber, custSor, custId }),

  /**
   * 修改客户基本信息
   */
  updateCustBasic: ({ degreeCode, merriageCode, custId }) => api.post('/groovy/cust/updateCustBaseInfo', { degreeCode, merriageCode, custId }),

  /**
   * 更新客户个人联系方式
   */
  addOrUpdateContactPer: query => api.post('/groovy/cust/addOrUpdateContactPer', query),

  /**
   * 查询客户联系方式
   */
  getCustCotact: ({ custNumber, custSor, custId }) => api.post('/groovy/cust/custContact', { custNumber, custSor, custId }),

  /**
   * 获取客户信息
   */
  getCustomerInfo: () => api.post('/groovy/emp/home'),

  /**
   * 获取客户列表
   */
  getCustomerList: query => api.post('/groovy/cust/custList', query),

  /**
   * 获取客户详细信息
   */
  getCustomerDetail: ({ custNumber, custSor, custId }) => api.post('/groovy/cust/custDetail', { custNumber, custSor, custId }),

  /**
   * 忽略推荐产品
   */
  ignoreProduct: ({ clientIdSign, productCode, directoryCode, source }) => api.post('/groovy/product/ignoreProduct', { clientIdSign, productCode, directoryCode, source }),

  /**
   * 给客户发送邮件
   */
  sendProductEmail: ({ clientIdSign, clientName, productCode, directoryCode }) => api.post('/groovy/product/sendProductEmail', { clientIdSign, clientName, productCode, directoryCode }),

  /**
   * 查看目标客户
   */
  targetCusts: ({ directoryCode, productCode, pageNum }) => api.post('/groovy/product/targetCusts', { directoryCode, productCode, pageNum }),

  /**
   * 获取客户简要通讯信息
   */
  getCustBrifeContact: ({ custNumber, custSor }) => api.post('/groovy/cust/custBrifeContact', { custNumber, custSor }),

  /**
   * 获取服务记录列表
   */
  getServiceList: ({ custSor, custId }) => api.post('/groovy/cust/custServiceRecord', { custSor, custId }),

  /**
   * 获取任务详情
   */
  getMotDetail: ({ motTaskId, pageNum, pageSize }) => api.post('/groovy/emp/motDetail', { motTaskId, pageNum, pageSize }),

    /**
   * 获取客户待办任务列表
   */
  getCustMotList: ({ custId, custNumber, pageNum, pageSize }) => api.post('/groovy/emp/motTaskOfCust', { custId, custNumber, pageNum, pageSize }),

   /**
   * 查询客户待办任务数量
   */
  motTaskOfCustCount: ({ custNumber, custId }) => api.post('/groovy/emp/motTaskOfCustCount', { custNumber, custId }),

  /**
   * 获取客户信息
   */
  getMissionCenter: () => api.post('/groovy/emp/motList'),

  /**
   * 获取产品列表
   */
  getProductList: query => api.post('/groovy/product/productList', query),

  /**
   * 获取服务记录活动内容选项
   */
  getServiceContentOpts: query => api.post('/mobile/queryCustActionActiveContent', query),

  /**
   * 新增服务记录
   */
  addServiceRecord: query => api.post('/groovy/cust/addOrUpdateServiceRecord', query),

  /**
   * 登出
   * {}
   */
  logout: query => api.post('/mobile/logout', query),

  /**
   * 发送验证码
   */
  sendSmsCheckCode: ({ empId }) => api.post('/mobile/sendSmsCheckCode', { empId }),

  /**
   * 登录
   */
  login: ({ deviceId, empId }) => api.post(
    '/mobile/login',
    {
      deviceId,
      empId,
      checkCode: '123456',
      password: 'Ht123456',
    },
  ),

  /**
   * 发送邮件
   * { receiverAddress, subject, content }
   */
  sendMail: query => api.post('/groovy/common/sendMail', query),

  /**
   * 发送邮件页面获取收件人邮箱地址
   */
  getReceiverMailAddr: query => api.post('/groovy/cust/custBrifeContact', query),
  /**
   * 搜索产品
   * { keywords, page }
   */
  searchProduct: query => api.post('/groovy/product/productList', query),
  /**
   * 已开通业务
   */
  getCustBusinessInfo: query => api.post('/groovy/cust/custBusinessInfo', query),
  /**
   * 机构客户信息增删改接口
   */
  updatePersonnelInfo: query => api.post('/groovy/cust/addOrUpdateContactOrg', query),
};
