export default {
  // 列表分页
  pageSize: 50,
  // 列表初始渲染数量，滚动条恢复和初始性能折中，
  initialListSize: 50,
  // 网络超时时间
  timeout: 15000,
  // 涨乐产品地址
  zlUrl: 'mcrm/zl/s1/zlcftajax/sc',
  // 适用native版本
  nativeVersion: '>=1.16.1',
  upgradeTip: `您当前使用的移动理财平台版本较老，为确保最佳使用体验，请升级至最新版。
    您可以通过扫描PC版理财工作平台左下方二维码升级最新版本。感谢您使用！`,
  // 任务详情引导页展示的次数
  showCount: 3,
};
