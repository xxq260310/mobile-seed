/**
 * @file config/log.js
 *  神策数据收集相关配置
 * @author maoquan(maoquan@htsc.com)
 */

const config = {
  url: '/log/sa',
  interval: 1 * 60 * 1000,
  enable: true,
  projectName: location.hostname.indexOf('htsc.com.cn') > -1
    ? 'MCRM_1_0' : 'DEV_TEST',
  blacklist: [
    '@@DVA_LOADING/HIDE',
    '@@DVA_LOADING/SHOW',
    '@@HT_LOADING/SHOW_ACTIVITY_INDICATOR',
    '@@HT_LOADING/HIDE_ACTIVITY_INDICATOR',
    'persist/REHYDRATE',
  ],
  whitelist: [],
  eventPropertyMap: {
    // 获取当前登录用户信息
    'global/getEmpInfoSuccess': {
      values: [
        'empInfo',
      ],
    },
    // 页面pv
    '@@router/LOCATION_CHANGE': {
      values: [
        'pathname',
        'query',
      ],
    },
    // 获取客户详情
    'customer/fetchCustDetailSuccess': {
      values: [
        'custSor',
        'response.resultData.custBaseInfo',
      ],
    },
    // 任务详情
    'mission/reportDetail': {
      values: [
        '*', // *表示payload所有第一层字段
      ],
    },
    // 产品详情
    'product/reportDetail': {
      values: [
        '*',
      ],
    },
    // 左滑任务详情
    'mission/swipeAction': {
      values: [
        '*',
      ],
    },
    // 页面下拉刷新
    'global/refreshPage': {
      value: [
        '*',
      ],
    },
    // 产品中心打开筛选
    'product/openFilter': {
      value: [
        '*',
      ],
    },
    // 客户中心打开筛选
    'customer/openFilter': {
      value: [
        '*',
      ],
    },
    // 任务中心打开筛选
    'mission/openFilter': {
      value: [
        '*',
      ],
    },
  },
  // 神策系统保留属性，未避免冲突，对这些属性+后缀处理
  // 如 time ==> time_0
  mapFiledList: [
    'time',
    'date',
    'datetime',
    'distinct_id',
    'event',
    'events',
    'first_id',
    'id',
    'original_id',
    'device_id',
    'properties',
    'second_id',
    'time',
    'user_id',
    'users',
  ],
};

export default config;
