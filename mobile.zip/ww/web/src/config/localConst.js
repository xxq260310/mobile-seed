/**
 * @file config/localConst.js
 * 本地字典
 * @author hongguangqing(1757912135@qq.com)
 */

const localConst = {
  // 服务实施方式的字典
  SERVICEIMPLEMENT_ICONS: [
    { icon: 'phone', serviceName: '电话', value: 0, word: 'Phone' },
    { icon: 'weixin', serviceName: '微信', value: 1, word: 'wx' },
    { icon: 'email', serviceName: '邮件', value: 2, word: 'Email' },
    { icon: 'duanxin', serviceName: '短信', value: 3, word: 'SMS' },
    { icon: 'service', serviceName: '面谈', value: 4, word: 'Interview' },
    { icon: 'other', serviceName: '其他', value: 5, word: 'Others' },
  ],
  // 个人客户标签列表
  perLabelArr: [
    { type: 'custAge', name: '年龄', value: '', key: 0 },
    { type: 'custGrade', name: '客户等级', value: '', key: 0 },
    { type: 'idType', name: '证件类型', value: '', key: 0 },
    { type: 'job', name: '职业', value: '', key: 0 },
    { type: 'degree', name: '学历', value: '', key: 0, arrow: 'horizontal' },
    { type: 'merriage', name: '婚姻状况', value: '', key: 0, arrow: 'horizontal' },
    { type: 'hobits', name: '爱好', value: '', key: 0 },
    { type: 'acctStatus', name: '账户状态', value: '', key: 0 },
    { type: 'openTime', name: '开户时间', value: '', key: 0 },
    { type: 'priSalesTeam', name: '服务经理', value: '', key: 0 },
    { type: 'lastCommission', name: '最近一次服务时间', value: '', key: 0 },
  ],
  // 机构客户标签列表
  orgLabelArr: [
    { type: 'acctType', name: '机构类型', value: '', key: 0 },
    { type: 'custGrade', name: '客户等级', value: '', key: 0 },
    { type: 'idType', name: '证件类型', value: '', key: 0 },
    { type: 'industry', name: '所属行业', value: '', key: 0 },
    { type: 'regAsset', name: '注册资金（万元）', value: '', key: 0 },
    { type: 'regAddress', name: '注册地点', value: '', key: 0 },
    { type: 'foundTime', name: '成立时间', value: '', key: 0 },
    { type: 'busiArea', name: '经营范围', value: '', key: 0 },
    { type: 'acctStatus', name: '账户状态', value: '', key: 0 },
    { type: 'openTime', name: '开户时间', value: '', key: 0 },
    { type: 'priSalesTeam', name: '服务经理', value: '', key: 0 },
    { type: 'lastCommission', name: '最近一次服务时间', value: '', key: 0 },
  ],
  // 客户联系方式
  LIST_KEY_ARR: [
    {
      label: 'tel',
      name: '电话',
      icon: 'phone',
      child: ['cellPhones', 'workTels', 'homeTels', 'otherTels'],
      childname: ['手机', '单位', '住宅', '其他'],
    },
    {
      label: 'email',
      name: '邮箱',
      icon: 'email',
      child: ['emailAddresses'],
      childname: [''],
    },
    {
      label: 'address',
      name: '地址',
      icon: 'map',
      child: ['idAddress', 'homeAddresses', 'workAddresses', 'otherAddresses'],
      childname: ['身份证地址', '家庭住址', '单位地址', '其他地址'],
    },
    {
      label: 'qq',
      name: 'QQ',
      icon: 'qq',
      child: ['qqNumbers'],
      childname: [''],
    },
    {
      label: 'wechat',
      name: '微信',
      icon: 'weixin',
      child: ['wechatNumbers'],
      childname: [''],
    },
  ],
  // 电话方式
  TEL_TYPE_MAP: {
    手机: 'cellPhones',
    住宅: 'homeTels',
    单位: 'workTels',
    其他: 'otherTels',
  },
  // 地址方式
  ADDRESS_TYPE_MAP: {
    家庭地址: 'homeAddresses',
    身份证地址: 'idAddress',
    单位地址: 'workAddresses',
    其他地址: 'otherAddresses',
  },
  COMMON_TYPE_MAP: {
    email: 'emailAddresses',
    qq: 'qqNumbers',
    wechat: 'wechatNumbers',
  },
  COMMON_TITLE_MAP: {
    email: '邮箱',
    qq: 'QQ',
    wechat: '微信',
  },
  // 搜索
  SHOW_MODE: {
    NORMAL: 'NORMAL',
    SEARCHING: 'SEARCHING',
  },
  // 客户下拉种类
  SELECT_OPTIONS: [
    {
      text: '我的客户',
      value: 'PERSONAL',
    },
    {
      text: '我团队的客户',
      value: 'TEAM',
    },
  ],
  // 服务记录状态
  recordStatus: [
    {
      value: 'New',
      label: '新建',
    }, {
      value: 'Done',
      label: '完成',
    }, {
      value: 'Suspend',
      label: '搁置',
    }, {
      value: 'HTSC Booking',
      label: '预约下次',
    }, {
      value: 'Open',
      label: '正在进行',
    }, {
      value: 'HTSC Not Closed',
      label: '未完成',
    }, {
      value: 'Failed',
      label: '失败',
    },
  ],
  // 服务记录类型
  recordType: [
    {
      value: 'Customer Infor Verify',
      label: '客户信息核实',
    },
    {
      value: 'TG New Customer Visit',
      label: '投顾新客户回访',
    }, {
      value: 'Campaign Action',
      label: '服务营销',
    }, {
      value: 'Fins Su',
      label: '理财建议',
    }, {
      value: 'System Alert',
      label: '通知提醒',
    }, {
      value: 'New Customer Visit',
      label: '新客户回访',
    }, {
      value: 'Old Customer Visit',
      label: '存量客户回访',
    }, {
      value: 'Diff Confirm',
      label: '异动确认',
    }, {
      value: 'Margin Trading',
      label: '新开融资融券客户回访',
    }, {
      value: 'Warm Care',
      label: '温馨关怀',
    }, {
      value: 'Cancellation Tracking',
      label: '销户跟踪',
    }, {
      value: 'Complaints Dealing',
      label: '投诉处理',
    }, {
      value: 'Sales Action',
      label: '销售活动',
    }, {
      value: 'MOT Action',
      label: 'MOT服务记录',
    }, {
      value: 'Resp',
      label: '体征服务回访',
    }, {
      value: 'Trust Products Sale',
      label: '信托产品销售回访',
    }, {
      value: 'TG Exists Custotmer Visit',
      label: '投顾存量客户回访',
    },
  ],
  // 服务记录结果
  recordResult: [
    {
      value: 'Illegal Visit',
      label: '不合规回访',
    },
    {
      value: 'Address Error',
      label: '地址错误',
    },
    {
      value: 'HTSC Non-Resident Account',
      label: '境外户',
    },
    {
      value: 'HTSC Comments',
      label: '备注',
    },
    {
      value: 'HTSC Complete',
      label: '完整完成',
    },
    {
      value: 'Customer Decline',
      label: '客户拒绝',
    },
    {
      value: 'HTSC Power Off',
      label: '已关机',
    },
    {
      value: 'HTSC Cancellation',
      label: '已销户',
    },
    {
      value: 'HTSC Abnormal Desc',
      label: '异常情况说明',
    },
    {
      value: 'HGXQ',
      label: '很感兴趣',
    },
    {
      value: 'TDBMQ',
      label: '态度不明确',
    },
    {
      value: 'YYJYBGT',
      label: '愿意进一步沟通',
    },
    {
      value: 'HTSC No Answer',
      label: '无人接听（或无法接通）',
    },
    {
      value: 'HTSC Invalid Phone',
      label: '无效电话（停机、空号等）',
    },
    {
      value: 'HTSC Account',
      label: '机构客户',
    },
    {
      value: 'BJFG',
      label: '比较反感',
    },
    {
      value: 'HTSC No One Risk Tip',
      label: '没有专人讲解合同内容和揭示风险',
    },
    {
      value: 'Phone Error',
      label: '电话有误',
    },
    {
      value: 'QRCJ',
      label: '确认参加',
    },
    {
      value: 'HTSC Partly Completed',
      label: '部分完成',
    },
    {
      value: 'HTSC Other Speaking',
      label: '非本人接听',
    },
    {
      value: 'HTSC Booking',
      label: '预约下次',
    },
  ],
};
export default localConst;
