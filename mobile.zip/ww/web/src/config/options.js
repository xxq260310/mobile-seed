/**
 * @fileOverview config/options.js
 * @author sunweibin
 * @description 用于存放下拉框选项的配置
 */

const options = {
  custTypeOptions: [
    {
      value: 'all',
      label: '所有客户',
    },
    {
      value: 'per',
      label: '个人客户',
    },
    {
      value: 'org',
      label: '机构客户',
    },
    {
      value: 'prod',
      label: '产品客户',
    },
  ],
  custLevelOptions: [
    {
      value: 'all',
      label: '所有等级',
    },
    {
      value: '805010',
      label: '钻石卡',
    },
    {
      value: '805015',
      label: '白金卡',
    },
    {
      value: '805020',
      label: '金卡',
    },
    {
      value: '805025',
      label: '银卡',
    },
    {
      value: '805030',
      label: '理财卡',
    },
    {
      value: '805040',
      label: '空',
    },
  ],
  statusOptions: [
    {
      value: 'all',
      label: '全部状态',
    },
    {
      value: '1',
      label: '在售',
    },
    {
      value: '2',
      label: '预售',
    },
  ],
  sortOptions: [
    {
      value: 'init',
      label: '期限由高到低',
    },
    {
      value: 'sort2',
      label: '期限由低到高',
    },
    {
      value: 'sort3',
      label: '起购金额由高到低',
    },
    {
      value: 'sort4',
      label: '起购金额由低到高',
    },
  ],
  productOptions: [
    {
      value: 'all',
      label: '全部类型',
      isLeaf: true,
    },
    {
      value: 'XE020000',
      label: '公募基金产品',
      children: [
        {
          label: '全部公募基金产品',
          value: 'XE020000',
          text: '公募基金产品',
        },
        {
          label: '货币基金',
          value: 'XE020000001',
        },
        {
          label: 'QDII基金',
          value: 'XE020000002',
        },
        {
          label: '债券基金',
          value: 'XE020000003',
        },
        {
          label: '分级基金',
          value: 'XE020000004',
        },
        {
          label: '混合基金',
          value: 'XE020000005',
        },
        {
          label: '股票基金',
          value: 'XE020000006',
        },
        {
          label: '其他基金',
          value: 'XE020000007',
        },
        {
          label: 'FOF基金',
          value: 'XE020000008',
        },
      ],
    },
    {
      value: 'XE040000',
      label: '券商理财产品',
      children: [
        {
          label: '全部券商理财产品',
          value: 'XE040000',
          text: '券商理财产品',
        },
        {
          label: '大集合',
          value: 'XE040000001',
        },
        {
          label: '小集合',
          value: 'XE040000002',
        },
        {
          label: '专项计划',
          value: 'XE040000003',
        },
      ],
    },
    {
      value: 'XE070000',
      label: '证券投资类私募',
      children: [
        {
          label: '全部证券投资类私募',
          value: 'XE070000',
          text: '证券投资类私募',
        },
        {
          label: '基金公司专户',
          value: 'XE070000001',
        },
        {
          label: '基金子公司专项计划',
          value: 'XE070000002',
        },
        {
          label: '私募管理人产品',
          value: 'XE070000003',
        },
        {
          label: '其他私募产品',
          value: 'XE070000004',
        },
        {
          label: '证券投资类信托',
          value: 'XE070000005',
        },
      ],
    },
    {
      value: 'XE080000',
      label: '非证券投资类私募',
      children: [
        {
          label: '全部非证券投资类私募',
          value: 'XE080000',
          text: '非证券投资类私募',
        },
        {
          label: '基金公司专户',
          value: 'XE080000001',
        },
        {
          label: '基金子公司专项计划',
          value: 'XE080000002',
        },
        {
          label: '私募管理人产品',
          value: 'XE080000003',
        },
        {
          label: '其他私募产品',
          value: 'XE080000004',
        },
        {
          label: '非证券投资类信托',
          value: 'XE080000005',
        },
      ],
    },
  ],
};

export default options;
