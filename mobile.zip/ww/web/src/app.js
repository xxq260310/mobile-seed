/**
 * @file app.js
 * @author maoquan(maoquan@htsc.com)
 */

import dva from 'dva';
import { browserHistory } from 'dva/router';
import createLoading from 'dva-loading';
import createLogger from 'redux-logger';
import { persistStore, autoRehydrate } from 'redux-persist';
import _ from 'lodash';
import { Modal } from 'antd-mobile';

import Toast from './components/common/Toast';
import createSensorsLogger from './middlewares/sensorsLogger';
import createActivityIndicator from './middlewares/createActivityIndicator';
import routerConfig from './router';
import { persist as persistConfig, constants } from './config';
import FastClick from './utils/fastclick';
import { getQuery, checkVersion } from './utils/helper';
import {
  navToLogin,
  initNativeMethod,
  registerBackBtnListener,
} from './utils/cordova';
import api from './api';

// 存储empId, deviceId, token等授权信息
const query = getQuery(location.search);
const authInfo = _.pick(query, 'empId', 'deviceId', 'token');
api.setAuthInfo(authInfo);

const extraEnhancers = [];
if (persistConfig.active) {
  extraEnhancers.push(autoRehydrate());
}

// 各平台出错信息不一样
// 貌似也没有status code
const NETWORK_ERROR_MESSAGE = [
  'Failed to fetch',
  'Network request failed',
];

const getMessage = (message) => {
  if (_.includes(NETWORK_ERROR_MESSAGE, message)) {
    return '网络异常';
  }
  // 解决 toast 只有苦脸，没文字问题。默认文字为‘网络异常’
  if (!/[\u4E00-\u9FCB]+/.test(message)) {
    return process.env.NODE_ENV === 'development' ? message : '网络异常';
  }
  return message;
};

// 默认一个dispatch函数
// app初始化后会赋值为store上的dispatch
let dispatch = () => {};
// 设置全局的bool变量，用于控制弹框出现时，有且只有一个。
let isShowModal = false;
// 弹出升级提示框
const showUpgradeDialog = () => {
  if (!isShowModal) {
    // 统计升级框弹出
    dispatch({
      type: 'upgrade/showDialog',
      immediate: true,
    });
    isShowModal = true;
    Modal.alert(
    '提示',
      constants.upgradeTip,
      [{
        text: '确定',
        onPress: () => {
          // 统计升级框被用户触发关闭
          dispatch({
            type: 'upgrade/confirmDialog',
            immediate: true,
          });
          isShowModal = false;
          navToLogin();
        },
        style: 'default',
      }],
    );
  }
};

// 错误处理
const onError = (e) => {
  const { message } = e;
  if (message === 'MAG0010') {
    Toast.fail(
      '登录超时，请重新登录！',
      1,
      navToLogin,
    );
  } else if (message === 'ERROR_VERSION_NOT_MATCH') {
    showUpgradeDialog();
  } else if (message) {
    Toast.fail(getMessage(message), 1);
  }
};

// 1. Initialize
const app = dva({
  history: browserHistory,
  onAction: [createLogger(), createSensorsLogger()],
  extraEnhancers,
  onError,
});

// 2. Plugins
app.use(createLoading({ effects: true }));
app.use(createActivityIndicator());

// 3. Model
app.model(require('./models/product'));
app.model(require('./models/global'));
app.model(require('./models/customer'));
app.model(require('./models/mission'));
app.model(require('./models/search'));
app.model(require('./models/status'));
app.model(require('./models/profile'));

// 4. Router
app.router(routerConfig);

// 5. Start
app.start('#app');

// 6. redux-persist
if (persistConfig.active) {
  persistStore(app._store, persistConfig); // eslint-disable-line
}

dispatch = app._store.dispatch; // eslint-disable-line

// 获取客户信息
dispatch({
  type: 'global/getEmpInfo',
  loading: false,
});

// fastclick
FastClick.attach(document.body);

// cordova
// 初始化给cordova提供的代码，挂在全局变量
initNativeMethod(app._store); // eslint-disable-line

// deviceready之前native version字段可能不可用，这里再检查一下
document.addEventListener('deviceready', () => {
  if (!isShowModal && !checkVersion()) {
    showUpgradeDialog();
  }
}, false);

// 安卓返回键处理
// addBackbuttonListener();
registerBackBtnListener();
// 更新管理
// appUpdate.initialize();
