// 占位文件
// 在app中运行时，由native拦截

var MCRMCordovaPlugin = {
  nav2Login: function () {
    console.log('nav2Login');
  },
  downloadLatestVersion: function () {
    console.log('downloadLatestVersion');
  },
  sendEmail: function () {
    console.log('sendEmail');
  },
  processMotTask: function () {
    console.log('processMotTask');
  },
  openUrl: function () {
    console.log('openUrl');
  },
  exitApp: function () {
    console.log('exitApp');
  },
  nativeGoBack: function () {
    console.log('nativeGoBack');
  },
  setGesture: function () {
    console.log('setGesture');
  },
  callPhone: function () {
    console.log('callPhone');
  },
};