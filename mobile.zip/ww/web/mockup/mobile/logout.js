exports.response = function (req, res) {
  return {
    code: '0',
    msg: 'OK',
    resultData: null
  };
}
