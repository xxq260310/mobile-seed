exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": {
      "page": {
        "pageSize": 1,
        "curPageNum": 10,
        "totalPageNum": 1,
        "totalRecordNum": 5,
      },
      "motTaskOfCust": [
        {
          "contents": "恭喜客户中新股，提醒客户新股上市，要关注行情变化，尽可能获得最大收益。",
          "custId": "1-3AB90H2",
          "detailContent": " 【新股上市提醒】您申购的崇达技术002815，今天上市交易。请告知客户。",
          "empNum": null,
          "eventName": "新规_新股上市提醒",
          "executeType": "Chance",
          "executeTypeName": "选做",
          "flowId": null,
          "mssnId": "363161012120",
          "processTime": "2017-06-20 00:00:00",
          "triggerTime": "2016-10-12 00:00:00"
        },
        {
          "contents": "恭喜客户中新股，提醒客户新股上市，要关注行情变化，尽可能获得最大收益。",
          "custId": null,
          "detailContent": " 【新股上市提醒】您申购的崇达技术002815，今天上市交易。请告知客户。",
          "empNum": null,
          "eventName": "新规_新股上市提醒",
          "executeType": "Chance",
          "executeTypeName": "选做",
          "flowId": null,
          "mssnId": "363161012121",
          "processTime": "2017-06-20 00:00:00",
          "triggerTime": "2016-10-12 00:00:00"
        },
        {
          "contents": "恭喜客户中新股，提醒客户新股上市，要关注行情变化，尽可能获得最大收益。",
          "custId": null,
          "detailContent": " 【新股上市提醒】您申购的崇达技术002815，今天上市交易。请告知客户。",
          "empNum": null,
          "eventName": "新规_新股上市提醒",
          "executeType": "Chance",
          "executeTypeName": "选做",
          "flowId": null,
          "mssnId": "363161012122",
          "processTime": "2017-06-20 00:00:00",
          "triggerTime": "2016-10-12 00:00:00"
        },
        {
          "contents": "恭喜客户中新股，提醒客户新股上市，要关注行情变化，尽可能获得最大收益。",
          "custId": null,
          "detailContent": " 【新股上市提醒】您申购的崇达技术002815，今天上市交易。请告知客户。",
          "empNum": null,
          "eventName": "新规_新股上市提醒",
          "executeType": "Chance",
          "executeTypeName": "选做",
          "flowId": null,
          "mssnId": "363161012123",
          "processTime": "2017-06-20 00:00:00",
          "triggerTime": "2016-10-12 00:00:00"
        },
        {
          "contents": "恭喜客户中新股，提醒客户新股上市，要关注行情变化，尽可能获得最大收益。",
          "custId": null,
          "detailContent": " 【新股上市提醒】您申购的崇达技术002815，今天上市交易。请告知客户。",
          "empNum": null,
          "eventName": "新规_新股上市提醒",
          "executeType": "Chance",
          "executeTypeName": "选做",
          "flowId": null,
          "mssnId": "363161012124",
          "processTime": "2017-06-20 00:00:00",
          "triggerTime": "2016-10-12 00:00:00"
        },
      ],
    }
  } 
}
