exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": {
      "taskId": "1-VS-4517"
    }
  };
}
