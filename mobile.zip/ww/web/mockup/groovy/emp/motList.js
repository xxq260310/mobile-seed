exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": {
      "endTodayCount": 10,
      "totalCount": 260,
      "motTaskList": [
        {
          "motTaskId": "119160908081",
          "motTaskCreatedTime": "2016-09-08 12:00:00",
          "motTaskName": "新开户(高净值)客户提醒",
          "motTaskExecuteType": "Mission",
          "motTaskExecuteTypeName": "必做",
          "motTaskExpireTime": "2017-02-21",
          "motTaskAccRate": 0,
          "processedCusts": 0,
          "totalCusts": 1,
          "motTaskProcessingItems": 1
        }
      ]
    }
  } 
}
