exports.response = function (req, res) {
    return {
        code: "0",
        msg: "OK",
        resultData: {
            //未开通业务列表
            notOpenedServiceList: [
                {
                    qualifiedFlag: "Y",
                    reason: "<null>",
                    serviceCode: "817010",
                    serviceName: "\U521b\U4e1a\U677f\U6743\U9650",
                },
                {
                    qualifiedFlag: "Y",
                    reason: "<null>",
                    serviceCode: "817170",
                    serviceName: "\U6da8\U4e50\U8d22\U5bcc\U901a",
                },
                {
                    qualifiedFlag: "Y",
                    reason: "<null>",
                    serviceCode: "817240",
                    serviceName: "OTC\U67dc\U53f0\U4e1a\U52a1",
                },
                {
                    qualifiedFlag: "N",
                    reason: "<null>",
                    serviceCode: "817030",
                    serviceName: "\U878d\U8d44\U878d\U5238\U6743\U9650\U878d\U8d44\U878d\U5238\U6743\U9650",
                },
                {
                    qualifiedFlag: "N",
                    reason: "<null>",
                    serviceCode: "817200",
                    serviceName: "\U6caa\U6e2f\U901a",
                },
                {
                    qualifiedFlag: "N",
                    reason: "<null>",
                    serviceCode: "817260",
                    serviceName: "\U65b0\U4e09\U677f",
                },
                {
                    qualifiedFlag: "N",
                    reason: "<null>",
                    serviceCode: "817270",
                    serviceName: "\U4e2a\U80a1\U671f\U6743",
                },
                {
                    qualifiedFlag: "N",
                    reason: "<null>",
                    serviceCode: "817450",
                    serviceName: "IPO\U7f51\U4e0b\U914d\U552e",
                }
            ],
            openedServiceList: [
                {
                    openingDate: "20140929",
                    serviceCode: "817180",
                    serviceName: "\U878d\U8d44\U6253\U65b0",
                },
                {
                    openingDate: "20140612",
                    serviceCode: "817050",
                    serviceName: "\U5929\U5929\U53d1";
                },
                {
                    openingDate: "20140611",
                    serviceCode: "817100",
                    serviceName: "\U6df1\U5e02\U80a1\U4e1c",
                },
                {
                    openingDate: "20140611",
                    serviceCode: "817090",
                    serviceName: "\U6caa\U5e02\U80a1\U4e1c",
                },
                {
                    openingDate: " ",
                    serviceCode: "817040",
                    serviceName: "\U7535\U5b50\U7b7e\U540d\U7b7e\U7f72\U6807\U5fd7",
                },
                {
                    openingDate: " ",
                    serviceCode: "817060",
                    serviceName: "\U5929\U5929\U53d1\U81ea\U52a8\U7533\U8d2d",
                },
                {
                    openingDate: " ",
                    serviceCode: "817070",
                    serviceName: "\U6caa\U5e02TA",
                },
                {
                    openingDate: " ",
                    serviceCode: "817150",
                    serviceName: "\U80a1\U7968\U8d28\U62bc",
                }
            ],
        }
    }
}