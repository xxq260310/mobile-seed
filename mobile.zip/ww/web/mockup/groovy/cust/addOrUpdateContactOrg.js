exports.response = function (req, res) {
  return {
    "code": "0", 
    "msg": "OK", 
    "resultData": {
      "serviceRecords": [
        {
          "category": "通知提醒", 
          "comments": "comment", 
          "desp": "desp", 
          "startTime": "2017-01-09 02:20:22", 
          "endTime": "2017-01-09 02:20:22", 
          "ownerId": "1-OXZ5", 
          "priority": null, 
          "status": "完成", 
          "type": "软件产品到期提醒", 
          "ani": null, 
          "actionChannel": "电话联系", 
          "serviceChannel": null, 
          "serviceType": null, 
          "serviceContent": null, 
          "serviceRecord": null, 
          "eventFlowId": null, 
          "doneFlag": "N"
        }
      ]
    }
  }
}