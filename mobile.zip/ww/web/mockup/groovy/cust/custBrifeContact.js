exports.response = function (req, res) {
  return {
    code: "0",
    msg: "OK",
    resultData: {
      "custId": "02067735",
      "custSor": "102010",
      "email": "lztest1@126.com.cn",
      "cellphone": "13938245031"
    }
  };
}
