exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": {
      "customerContactInfo": {
        "custId": "1-33SWAPQ",
        "custSor": "per",
        "custNumber": "666600340482",
        "custType": null,
        "name": null,
        "custRelaCd": null,
        "custRela": null,
        "rowId": null,
        "mainFlag": null,
        "validFlag": null,
        "gender": null,
        "idAddress": {
          "mainFlag": true,
          "validFlag": true,
          "contactType": "117119",
          "nation": "中国",
          "nationCd": "111156",
          "province": "江苏省",
          "provinceCd": "DF15",
          "city": "无锡市",
          "cityCd": "DF1502",
          "address": "龙华大道",
          "zip": "",
          "rowId": "ADDRI-20170515-03942215896"
        },
        "homeAddresses": null,
        "workAddresses": null,
        "otherAddresses": null,
        "cellPhones": null,
        "workTels": null,
        "homeTels": null,
        "otherTels": null,
        "emailAddresses": null,
        "qqNumbers": null,
        "wechatNumbers": null
      }
    }
  };
};
