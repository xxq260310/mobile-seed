exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": {
      "pageSize": 10,
      "totalRecords": 18,
      "totalPages": 2,
      "pageNum": 1,
      "beginIndex": 0,
      "clientlist": [
        {
          "clientIdSign": "F99897A1C973E4E80560E113315B91CA",// 客户加密id
          "clientId": "090200000127",// 客户id
          "clientName": "吕*",// 客户姓名
          "reason": "基于购买记录的潜在兴趣预测",// 推荐原因
          "clientPortraits": []
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
        {
          "clientIdSign": "C86182F9AA53973CCE9FAAD0460F1EC1",
          "clientId": "02020000",
          "clientName": "张*",
          "reason": "基于购买记录的潜在兴趣预测",
          "clientPortraits": [ // 客户标签
            {
              "tid": null,
              "name": "labels:kjlx", // 标签名
              "weight": null,
              "tvalue": "理财达人" // 标签值
            },
            {
              "tid": null,
              "name": "labels:txyl",
              "weight": null,
              "tvalue": "精英白领"
            },
            {
              "tid": null,
              "name": "labels:jrrs",
              "weight": null,
              "tvalue": "工人阶级"
            },
            {
              "tid": null,
              "name": "labels:qygg",
              "weight": null,
              "tvalue": "潜在大户"
            }
          ]
        },
      ]
    }
  }
};
