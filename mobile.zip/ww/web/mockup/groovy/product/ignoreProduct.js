exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": {
      "ignoreId": "1-3OSSZHD", //有值则成功
      "confirmCode": 1//有值则成功
    }
  };
};
