exports.response = function (req, res) {
  return {
    "code": "0",
    "msg": "OK",
    "resultData": "252121382@qq.com" //发送成功返回客户邮箱
  };
};
