exports.response = function (req, res) {
  return {
    code: '0',
    msg: 'OK',
    message: {
      global: "删除客户信息ok"
    },
    data: {
    }
  };
}