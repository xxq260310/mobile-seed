exports.response = function (req, res) {
  return {
    status: 0,
    message: {
      global: "保存客户信息失败"
    },
    data: {
    }
  };
}
